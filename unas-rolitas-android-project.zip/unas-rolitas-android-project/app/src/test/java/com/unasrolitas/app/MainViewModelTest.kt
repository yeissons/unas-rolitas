package com.unasrolitas.app

import com.unasrolitas.app.data.model.LibraryTab
import com.unasrolitas.app.data.model.Song
import com.unasrolitas.app.data.model.SortOption
import com.unasrolitas.app.viewmodel.MainViewModel
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class MainViewModelTest {

    private lateinit var viewModel: MainViewModel

    @Before
    fun setUp() {
        viewModel = MainViewModel(audioRepository = null)
    }

    @Test
    fun testInitialState() {
        val state = viewModel.uiState.value
        assertEquals(0, state.selectedTab)
        assertEquals(LibraryTab.SONGS, state.selectedLibraryTab)
        assertFalse(state.isDrawerOpen)
    }

    @Test
    fun testSelectNavigationTab() {
        viewModel.selectNavigationTab(2)
        assertEquals(2, viewModel.uiState.value.selectedTab)
    }

    @Test
    fun testSetLibraryTab() {
        viewModel.setLibraryTab(LibraryTab.ARTISTS)
        assertEquals(LibraryTab.ARTISTS, viewModel.uiState.value.selectedLibraryTab)
    }

    @Test
    fun testTogglePlayPause() {
        val initial = viewModel.uiState.value.isPlaying
        viewModel.togglePlayPause()
        assertEquals(!initial, viewModel.uiState.value.isPlaying)
    }

    @Test
    fun testToggleFavoriteCurrent() {
        val current = viewModel.uiState.value.currentSong
        if (current != null) {
            val initialFav = current.isFavorite
            viewModel.toggleFavoriteCurrent()
            assertEquals(!initialFav, viewModel.uiState.value.currentSong?.isFavorite)
        }
    }

    @Test
    fun testCycleRepeatMode() {
        val initial = viewModel.uiState.value.repeatMode
        viewModel.cycleRepeatMode()
        assertNotEquals(initial, viewModel.uiState.value.repeatMode)
    }

    @Test
    fun testToggleShuffle() {
        val initial = viewModel.uiState.value.isShuffleActive
        viewModel.toggleShuffle()
        assertEquals(!initial, viewModel.uiState.value.isShuffleActive)
    }

    @Test
    fun testSearchQueryFiltering() {
        viewModel.setSearchQuery("Piel")
        val filtered = viewModel.uiState.value.filteredSongs
        assertTrue(filtered.all { it.title.contains("Piel", ignoreCase = true) || it.artist.contains("Piel", ignoreCase = true) })
    }

    @Test
    fun testSortOption() {
        viewModel.setSortOption(SortOption.TITLE_AZ)
        val songs = viewModel.uiState.value.filteredSongs
        if (songs.size > 1) {
            assertTrue(songs[0].title.lowercase() <= songs[1].title.lowercase())
        }
    }

    @Test
    fun testPlaySong() {
        val testSong = Song("99", "Test Title", "Test Artist", "Test Album", 180000, "uri")
        viewModel.playSong(testSong)
        assertEquals("99", viewModel.uiState.value.currentSong?.id)
        assertTrue(viewModel.uiState.value.isPlaying)
    }

    @Test
    fun testAddToQueue() {
        val initialQueueSize = viewModel.uiState.value.queue.size
        val newSong = Song("100", "Queue Song", "Artist", "Album", 200000, "uri")
        viewModel.addToQueue(newSong)
        assertEquals(initialQueueSize + 1, viewModel.uiState.value.queue.size)
        assertEquals("100", viewModel.uiState.value.queue.last().id)
    }

    @Test
    fun testToggleDrawer() {
        val initial = viewModel.uiState.value.isDrawerOpen
        viewModel.toggleDrawer()
        assertEquals(!initial, viewModel.uiState.value.isDrawerOpen)
    }
}
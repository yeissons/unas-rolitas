package com.unasrolitas.app.data.repository

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.unasrolitas.app.data.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

interface AudioRepository {
    val songsFlow: Flow<List<Song>>
    suspend fun scanDeviceAudio(context: Context): List<Song>
    fun toggleFavorite(songId: String)
}

class LocalAudioRepositoryImpl : AudioRepository {
    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    override val songsFlow: Flow<List<Song>> = _songs.asStateFlow()

    private val favoriteIds = mutableSetOf<String>()

    override suspend fun scanDeviceAudio(context: Context): List<Song> = withContext(Dispatchers.IO) {
        val audioList = mutableListOf<Song>()
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.ALBUM_ID
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 10000"

        try {
            context.contentResolver.query(
                collection,
                projection,
                selection,
                null,
                "${MediaStore.Audio.Media.TITLE} ASC"
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateAddedColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val mimeTypeColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val albumIdColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val title = cursor.getString(titleColumn) ?: "Desconocido"
                    val artist = cursor.getString(artistColumn) ?: "Artista Desconocido"
                    val album = cursor.getString(albumColumn) ?: "Álbum Desconocido"
                    val duration = cursor.getLong(durationColumn)
                    val size = cursor.getLong(sizeColumn)
                    val dateAdded = cursor.getLong(dateAddedColumn)
                    val mimeType = cursor.getString(mimeTypeColumn) ?: "audio/*"
                    val albumId = cursor.getLong(albumIdColumn)

                    val contentUri: Uri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    val albumArtUri = "content://media/external/audio/albumart/$albumId"

                    val format = when {
                        mimeType.contains("flac", ignoreCase = true) -> "FLAC"
                        mimeType.contains("mp3", ignoreCase = true) -> "MP3"
                        mimeType.contains("aac", ignoreCase = true) -> "AAC"
                        mimeType.contains("wav", ignoreCase = true) -> "WAV"
                        mimeType.contains("ogg", ignoreCase = true) -> "OGG"
                        mimeType.contains("m4a", ignoreCase = true) -> "M4A"
                        else -> mimeType.substringAfter("/").uppercase()
                    }

                    val estimatedBitrate = if (duration > 0) ((size * 8) / (duration / 1000) / 1000).toInt() else null

                    audioList.add(
                        Song(
                            id = id.toString(),
                            title = title,
                            artist = if (artist == "<unknown>") "Artista Desconocido" else artist,
                            album = if (album == "<unknown>") "Álbum Desconocido" else album,
                            durationMs = duration,
                            uri = contentUri.toString(),
                            albumArtUri = albumArtUri,
                            sizeBytes = size,
                            dateAddedSec = dateAdded,
                            mimeType = mimeType,
                            isFavorite = favoriteIds.contains(id.toString()),
                            format = format,
                            bitrateKbps = estimatedBitrate
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        _songs.value = audioList
        audioList
    }

    override fun toggleFavorite(songId: String) {
        if (favoriteIds.contains(songId)) {
            favoriteIds.remove(songId)
        } else {
            favoriteIds.add(songId)
        }
        _songs.value = _songs.value.map { song ->
            if (song.id == songId) {
                song.copy(isFavorite = favoriteIds.contains(songId))
            } else song
        }
    }
}
package com.unasrolitas.app.data.model

data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: String,
    val albumArtUri: String? = null,
    val genre: String? = null,
    val year: Int? = null,
    val sizeBytes: Long = 0L,
    val mimeType: String? = null,
    val dateAddedSec: Long = 0L,
    val isFavorite: Boolean = false,
    val playsCount: Int = 0,
    val format: String? = null,
    val bitrateKbps: Int? = null,
    val sampleRateHz: Int? = null,
    val bitDepth: Int? = null
)

enum class LibraryTab(val label: String) {
    SONGS("Canciones"),
    ALBUMS("Álbumes"),
    ARTISTS("Artistas"),
    PLAYLISTS("Listas"),
    GENRES("Géneros"),
    FOLDERS("Carpetas")
}

enum class SortOption(val label: String) {
    TITLE_AZ("Título (A-Z)"),
    TITLE_ZA("Título (Z-A)"),
    ARTIST("Artista"),
    ALBUM("Álbum"),
    DURATION("Duración"),
    DATE_ADDED("Fecha añadida")
}
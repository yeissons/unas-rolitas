package com.unasrolitas.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.unasrolitas.app.di.AppContainer
import com.unasrolitas.app.ui.theme.UnasRolitasTheme
import com.unasrolitas.app.viewmodel.MainViewModel
import com.unasrolitas.app.viewmodel.ViewModelFactory

class MainActivity : ComponentActivity() {

    private lateinit var appContainer: AppContainer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        appContainer = AppContainer()

        setContent {
            UnasRolitasTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val viewModel: MainViewModel = viewModel(
                        factory = ViewModelFactory(appContainer.audioRepository)
                    )

                    viewModel.connectMediaController(applicationContext)

                    UnasRolitasApp(viewModel = viewModel)
                }
            }
        }
    }
}
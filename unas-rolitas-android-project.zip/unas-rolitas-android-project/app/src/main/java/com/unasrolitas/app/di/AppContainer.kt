package com.unasrolitas.app.di

import com.unasrolitas.app.data.repository.AudioRepository
import com.unasrolitas.app.data.repository.LocalAudioRepositoryImpl

class AppContainer {
    val audioRepository: AudioRepository by lazy {
        LocalAudioRepositoryImpl()
    }
}
package com.unasrolitas.app.viewmodel

import android.content.ComponentName
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.unasrolitas.app.data.model.*
import com.unasrolitas.app.data.repository.AudioRepository
import com.unasrolitas.app.service.AudioPlaybackService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AppState(
    val selectedTab: Int = 0,
    val selectedLibraryTab: LibraryTab = LibraryTab.SONGS,
    val songs: List<Song> = emptyList(),
    val filteredSongs: List<Song> = emptyList(),
    val currentSong: Song? = null,
    val isPlaying: Boolean = false,
    val playbackPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val isShuffleActive: Boolean = false,
    val activeVisualizer: VisualizerType = VisualizerType.FREQUENCY_SPECTRUM,
    val isMiniDockOpen: Boolean = false,
    val isDrawerOpen: Boolean = false,
    val selectedSort: SortOption = SortOption.TITLE_AZ,
    val searchQuery: String = "",
    val queue: List<Song> = emptyList(),
    val lyricsText: String = "",
    val volume: Float = 0.85f,
    val playbackSpeed: Float = 1.0f,
    val isLoadingSongs: Boolean = false,
    val hasPermission: Boolean = false,
    val permissionRequested: Boolean = false
)

class MainViewModel(
    private val audioRepository: AudioRepository? = null
) : ViewModel() {

    private val _uiState = MutableStateFlow(AppState())
    val uiState: StateFlow<AppState> = _uiState.asStateFlow()

    private var mediaControllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    init {
        audioRepository?.let { repo ->
            viewModelScope.launch {
                repo.songsFlow.collect { songList ->
                    updateSongsList(songList)
                }
            }
        }
        startPositionTracker()
    }

    fun connectMediaController(context: Context) {
        try {
            val sessionToken = SessionToken(context, ComponentName(context, AudioPlaybackService::class.java))
            mediaControllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
            mediaControllerFuture?.addListener({
                try {
                    mediaController = mediaControllerFuture?.get()
                    mediaController?.addListener(object : Player.Listener {
                        override fun onIsPlayingChanged(isPlaying: Boolean) {
                            _uiState.value = _uiState.value.copy(isPlaying = isPlaying)
                        }

                        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                            val currentMediaId = mediaItem?.mediaId
                            val song = _uiState.value.songs.find { it.id == currentMediaId }
                            if (song != null) {
                                _uiState.value = _uiState.value.copy(
                                    currentSong = song,
                                    durationMs = song.durationMs
                                )
                            }
                        }

                        override fun onRepeatModeChanged(repeatMode: Int) {
                            _uiState.value = _uiState.value.copy(repeatMode = repeatMode)
                        }

                        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                            _uiState.value = _uiState.value.copy(isShuffleActive = shuffleModeEnabled)
                        }
                    })
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }, MoreExecutors.directExecutor())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun onPermissionGranted(context: Context) {
        _uiState.value = _uiState.value.copy(hasPermission = true, permissionRequested = true)
        scanSongs(context)
    }

    fun onPermissionDenied() {
        _uiState.value = _uiState.value.copy(hasPermission = false, permissionRequested = true)
        if (_uiState.value.songs.isEmpty()) {
            updateSongsList(getDemoSongs())
        }
    }

    fun scanSongs(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.value = _uiState.value.copy(isLoadingSongs = true)
            val scanned = audioRepository?.scanDeviceAudio(context) ?: emptyList()
            if (scanned.isEmpty()) {
                val demoSongs = getDemoSongs()
                updateSongsList(demoSongs)
            }
            _uiState.value = _uiState.value.copy(isLoadingSongs = false)
        }
    }

    private fun updateSongsList(songList: List<Song>) {
        val sorted = sortAndFilterSongs(songList, _uiState.value.searchQuery, _uiState.value.selectedSort)
        _uiState.value = _uiState.value.copy(
            songs = songList,
            filteredSongs = sorted,
            queue = if (_uiState.value.queue.isEmpty()) sorted else _uiState.value.queue,
            currentSong = _uiState.value.currentSong ?: sorted.firstOrNull()
        )
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
        val sorted = sortAndFilterSongs(_uiState.value.songs, query, _uiState.value.selectedSort)
        _uiState.value = _uiState.value.copy(filteredSongs = sorted)
    }

    fun setSortOption(sort: SortOption) {
        _uiState.value = _uiState.value.copy(selectedSort = sort)
        val sorted = sortAndFilterSongs(_uiState.value.songs, _uiState.value.searchQuery, sort)
        _uiState.value = _uiState.value.copy(filteredSongs = sorted)
    }

    private fun sortAndFilterSongs(list: List<Song>, query: String, sort: SortOption): List<Song> {
        val filtered = if (query.isBlank()) list else {
            list.filter {
                it.title.contains(query, ignoreCase = true) ||
                it.artist.contains(query, ignoreCase = true) ||
                it.album.contains(query, ignoreCase = true)
            }
        }
        return when (sort) {
            SortOption.TITLE_AZ -> filtered.sortedBy { it.title.lowercase() }
            SortOption.TITLE_ZA -> filtered.sortedByDescending { it.title.lowercase() }
            SortOption.ARTIST -> filtered.sortedBy { it.artist.lowercase() }
            SortOption.ALBUM -> filtered.sortedBy { it.album.lowercase() }
            SortOption.DURATION -> filtered.sortedByDescending { it.durationMs }
            SortOption.DATE_ADDED -> filtered.sortedByDescending { it.dateAddedSec }
        }
    }

    fun playSong(song: Song) {
        _uiState.value = _uiState.value.copy(
            currentSong = song,
            isPlaying = true,
            durationMs = song.durationMs,
            playbackPositionMs = 0L
        )

        mediaController?.let { controller ->
            val mediaItem = MediaItem.Builder()
                .setMediaId(song.id)
                .setUri(song.uri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(song.title)
                        .setArtist(song.artist)
                        .setAlbumTitle(song.album)
                        .build()
                )
                .build()
            controller.setMediaItem(mediaItem)
            controller.prepare()
            controller.play()
        }
    }

    fun selectNavigationTab(index: Int) {
        _uiState.value = _uiState.value.copy(selectedTab = index)
    }

    fun setLibraryTab(tab: LibraryTab) {
        _uiState.value = _uiState.value.copy(selectedLibraryTab = tab)
    }

    fun togglePlayPause() {
        val newIsPlaying = !_uiState.value.isPlaying
        _uiState.value = _uiState.value.copy(isPlaying = newIsPlaying)
        mediaController?.let { controller ->
            if (newIsPlaying) controller.play() else controller.pause()
        }
    }

    fun playNext() {
        val queue = _uiState.value.queue
        if (queue.isEmpty()) return
        val current = _uiState.value.currentSong
        val currentIndex = queue.indexOfFirst { it.id == current?.id }
        val nextIndex = if (currentIndex != -1 && currentIndex < queue.size - 1) currentIndex + 1 else 0
        playSong(queue[nextIndex])
    }

    fun playPrevious() {
        val queue = _uiState.value.queue
        if (queue.isEmpty()) return
        val current = _uiState.value.currentSong
        val currentIndex = queue.indexOfFirst { it.id == current?.id }
        val prevIndex = if (currentIndex > 0) currentIndex - 1 else queue.size - 1
        playSong(queue[prevIndex])
    }

    fun seekTo(positionMs: Long) {
        _uiState.value = _uiState.value.copy(playbackPositionMs = positionMs)
        mediaController?.seekTo(positionMs)
    }

    fun toggleFavoriteCurrent() {
        val current = _uiState.value.currentSong ?: return
        val updated = current.copy(isFavorite = !current.isFavorite)
        _uiState.value = _uiState.value.copy(currentSong = updated)
        audioRepository?.toggleFavorite(current.id)
    }

    fun addToQueue(song: Song) {
        val newQueue = _uiState.value.queue.toMutableList().apply { add(song) }
        _uiState.value = _uiState.value.copy(queue = newQueue)
    }

    fun playNextInQueue(song: Song) {
        val current = _uiState.value.currentSong
        val queue = _uiState.value.queue.toMutableList()
        val currentIndex = queue.indexOfFirst { it.id == current?.id }
        if (currentIndex != -1) {
            queue.add(currentIndex + 1, song)
        } else {
            queue.add(0, song)
        }
        _uiState.value = _uiState.value.copy(queue = queue)
    }

    fun cycleRepeatMode() {
        val nextMode = when (_uiState.value.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        _uiState.value = _uiState.value.copy(repeatMode = nextMode)
        mediaController?.repeatMode = nextMode
    }

    fun toggleShuffle() {
        val newShuffle = !_uiState.value.isShuffleActive
        _uiState.value = _uiState.value.copy(isShuffleActive = newShuffle)
        mediaController?.shuffleModeEnabled = newShuffle
        if (newShuffle) {
            val shuffled = _uiState.value.queue.shuffled()
            _uiState.value = _uiState.value.copy(queue = shuffled)
        }
    }

    fun cycleVisualizer() {
        val types = VisualizerType.values()
        val nextIdx = (types.indexOf(_uiState.value.activeVisualizer) + 1) % types.size
        _uiState.value = _uiState.value.copy(activeVisualizer = types[nextIdx])
    }

    fun toggleMiniDock() {
        _uiState.value = _uiState.value.copy(isMiniDockOpen = !_uiState.value.isMiniDockOpen)
    }

    fun toggleDrawer() {
        _uiState.value = _uiState.value.copy(isDrawerOpen = !_uiState.value.isDrawerOpen)
    }

    private fun startPositionTracker() {
        viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_uiState.value.isPlaying) {
                    val mc = mediaController
                    val newPos = if (mc != null && mc.isPlaying) {
                        mc.currentPosition
                    } else {
                        val currentPos = _uiState.value.playbackPositionMs
                        val dur = _uiState.value.durationMs.coerceAtLeast(1000L)
                        if (currentPos >= dur) 0L else currentPos + 1000L
                    }
                    _uiState.value = _uiState.value.copy(playbackPositionMs = newPos)
                }
            }
        }
    }

    override fun onCleared() {
        mediaControllerFuture?.let {
            MediaController.releaseFuture(it)
        }
        super.onCleared()
    }

    private fun getDemoSongs(): List<Song> = listOf(
        Song("1", "Piel Canela", "Los Roliteros", "Noches de Bohemia", 215000, "content://media/external/audio/media/1", genre = "Bolero Rock", format = "MP3", bitrateKbps = 320),
        Song("2", "Sabor a Mí", "Triana Beats", "Acústico En Vivo", 198000, "content://media/external/audio/media/2", genre = "Acústico", format = "FLAC", bitrateKbps = 900),
        Song("3", "Cielito Lindo (Lo-Fi)", "Onda Sonoras", "Chill & Rolitas", 240000, "content://media/external/audio/media/3", genre = "Lo-Fi", format = "AAC", bitrateKbps = 256),
        Song("4", "La Flaca", "Stereo Funk", "Noches de Bohemia", 210000, "content://media/external/audio/media/4", genre = "Funk Rock", format = "MP3", bitrateKbps = 320),
        Song("5", "Bésame Mucho", "Luna Nova", "Jazz In Midnight", 310000, "content://media/external/audio/media/5", genre = "Jazz", format = "WAV", bitrateKbps = 1411)
    )
}
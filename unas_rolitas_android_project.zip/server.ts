import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import JSZip from "jszip";

const app = express();
const PORT = 3000;

// Helper to scan directory for all project files (Web React App + Android Gradle App)
function getAndroidFilesList(): string[] {
  const files: string[] = [];
  
  function scanDir(dir: string) {
    if (!fs.existsSync(dir)) return;
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      const relPath = path.relative(".", fullPath);
      
      if (entry.isDirectory()) {
        if (
          entry.name === "build" ||
          entry.name === ".gradle" ||
          entry.name === ".idea" ||
          entry.name === "node_modules" ||
          entry.name === "dist" ||
          entry.name === ".git"
        ) {
          continue;
        }
        scanDir(fullPath);
      } else {
        files.push(relPath);
      }
    }
  }

  scanDir(".");
  return files;
}

// Helper to deduce language
function getLanguage(filePath: string): string {
  const ext = path.extname(filePath);
  if (ext === ".kt" || ext === ".kts") return "kotlin";
  if (ext === ".tsx" || ext === ".ts") return "typescript";
  if (ext === ".jsx" || ext === ".js") return "javascript";
  if (ext === ".json") return "json";
  if (ext === ".html") return "html";
  if (ext === ".css") return "css";
  if (ext === ".xml") return "xml";
  if (ext === ".properties") return "properties";
  return "text";
}

// Helper to get description
function getDefaultDescription(filePath: string): string {
  const name = path.basename(filePath);
  if (filePath.includes("App.tsx")) return "Componente principal de la interfaz Web React del reproductor.";
  if (filePath.includes("res/values/strings.xml")) return "Define cadenas de texto y localizaciones de la aplicación.";
  if (filePath.includes("res/values/colors.xml")) return "Paleta de colores del tema de la aplicación.";
  if (filePath.includes("res/values/themes.xml")) return "Estilos y tema base para Jetpack Compose.";
  if (filePath.includes("MainActivity.kt")) return "Punto de entrada principal de la aplicación Android.";
  if (filePath.includes("MainScreen.kt")) return "Interfaz de usuario principal en Jetpack Compose para Android (Inicio, Reproducción, Ajustes).";
  if (filePath.includes("MusicViewModel.kt")) return "ViewModel que expone el estado de reproducción y gestiona eventos de audio.";
  if (filePath.includes("PlaybackService.kt")) return "Servicio en primer foreground que maneja ExoPlayer y la sesión Media3.";
  if (filePath.endsWith(".kt")) return `Código fuente Kotlin: ${name}.`;
  if (filePath.endsWith(".tsx") || filePath.endsWith(".ts")) return `Código fuente TypeScript: ${name}.`;
  if (filePath.endsWith(".xml")) return `Recurso de diseño XML: ${name}.`;
  return `Archivo de configuración del proyecto: ${name}.`;
}

// 1. API: Get latest real-time files from disk
app.get("/api/android-files", (req, res) => {
  try {
    const filePaths = getAndroidFilesList();
    const files = filePaths.map((filePath) => {
      const content = fs.readFileSync(filePath, "utf-8");
      return {
        path: filePath,
        name: path.basename(filePath),
        language: getLanguage(filePath),
        description: getDefaultDescription(filePath),
        content,
      };
    });
    res.json({ files });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 2. API: Download real-time ZIP compilable with exact current files on disk
app.get("/api/download-zip", async (req, res) => {
  try {
    const filePaths = getAndroidFilesList();
    const zip = new JSZip();

    filePaths.forEach((filePath) => {
      const content = fs.readFileSync(filePath, "utf-8");
      zip.file(filePath, content);
    });

    const buffer = await zip.generateAsync({ type: "nodebuffer" });
    
    res.setHeader("Content-Disposition", "attachment; filename=unas_rolitas_android_project.zip");
    res.setHeader("Content-Type", "application/zip");
    res.send(buffer);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 3. Vite middleware for development
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();

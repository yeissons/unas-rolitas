package com.unasrolitas.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.unasrolitas.app.data.model.Song

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MusicViewModel) {
    val context = LocalContext.current
    var hasStoragePermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { isGranted ->
            hasStoragePermission = isGranted
            if (isGranted) {
                viewModel.triggerMusicScan()
            }
        }
    )

    LaunchedEffect(Unit) {
        if (!hasStoragePermission) {
            val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                Manifest.permission.READ_MEDIA_AUDIO
            } else {
                Manifest.permission.READ_EXTERNAL_STORAGE
            }
            permissionLauncher.launch(permission)
        }
    }

    var selectedTab by remember { mutableStateOf(0) }
    var accentColor by remember { mutableStateOf(Color(0xFF00E5FF)) } // Default Cyan Neon
    var showNowPlayingOverlay by remember { mutableStateOf(false) }

    val tabs = listOf("Inicio", "Reproduciendo", "Ajustes")

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "¿UNAS ROLITAS?",
                            color = accentColor,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp,
                            fontSize = 18.sp,
                            fontFamily = FontFamily.SansSerif
                        )
                        Text(
                            text = "SPACESHIP AUDIO ENGINE v1.0",
                            color = Color.Gray,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showNowPlayingOverlay = !showNowPlayingOverlay }) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Reproductor rápido",
                            tint = accentColor
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF0A0B10)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0A0B10),
                tonalElevation = 8.dp
            ) {
                tabs.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        icon = {
                            when (index) {
                                0 -> Icon(Icons.Default.Home, contentDescription = label)
                                1 -> Icon(Icons.Default.PlayArrow, contentDescription = label)
                                else -> Icon(Icons.Default.Settings, contentDescription = label)
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = accentColor,
                            selectedTextColor = accentColor,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFF131722)
                        )
                    )
                }
            }
        },
        containerColor = Color(0xFF0A0B10)
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFF0A0B10))
        ) {
            if (!hasStoragePermission) {
                PermissionRequestScreen(accentColor) {
                    val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        Manifest.permission.READ_MEDIA_AUDIO
                    } else {
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    }
                    permissionLauncher.launch(permission)
                }
            } else {
                when (selectedTab) {
                    0 -> HomeScreen(viewModel, accentColor) { selectedTab = 1 }
                    1 -> NowPlayingScreen(viewModel, accentColor)
                    2 -> SettingsScreen(viewModel, accentColor) { accentColor = it }
                }
            }

            // Quick Floating Mini Player Bar if overlay requested
            if (showNowPlayingOverlay && hasStoragePermission) {
                MiniPlayerBar(
                    viewModel = viewModel,
                    accentColor = accentColor,
                    onOpenPlayer = {
                        showNowPlayingOverlay = false
                        selectedTab = 1
                    },
                    onClose = { showNowPlayingOverlay = false }
                )
            }
        }
    }
}

@Composable
fun PermissionRequestScreen(accentColor: Color, onRequestPermission: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = "Alerta de Permisos",
            tint = Color(0xFFFF007F),
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Acceso a Almacenamiento Requerido",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Para poder escanear y reproducir tus archivos locales de audio (.mp3, .flac, .m4a), necesitamos permisos para leer la memoria de tu dispositivo.",
            color = Color.Gray,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = onRequestPermission,
            colors = ButtonDefaults.buttonColors(
                containerColor = accentColor,
                contentColor = Color.Black
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("OTORGAR PERMISOS", fontWeight = FontWeight.Black)
        }
    }
}

/* ===================================================================
   1. PANTALLA DE INICIO (HOME / COCKPIT)
   =================================================================== */
@Composable
fun HomeScreen(
    viewModel: MusicViewModel,
    accentColor: Color,
    onNavigateToPlayer: () -> Unit
) {
    val songs by viewModel.allSongs.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf("Todas") }

    val filteredSongs = remember(songs, searchQuery, selectedCategoryFilter) {
        songs.filter { song ->
            val matchesQuery = song.title.contains(searchQuery, ignoreCase = true) ||
                    (song.artist ?: "").contains(searchQuery, ignoreCase = true)
            val matchesCategory = when (selectedCategoryFilter) {
                "Favoritas" -> song.isFavorite
                "Recientes" -> true
                else -> true
            }
            matchesQuery && matchesCategory
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Quick Search Field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Buscar canción, artista o álbum...", fontSize = 12.sp, color = Color.Gray) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Buscar", tint = accentColor) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Limpiar", tint = Color.Gray)
                    }
                }
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = accentColor,
                unfocusedBorderColor = Color(0xFF22283A),
                focusedContainerColor = Color(0xFF131722),
                unfocusedContainerColor = Color(0xFF131722),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Quick Category Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            val categories = listOf("Todas", "Favoritas", "Recientes", "Más Escuchadas")
            items(categories) { cat ->
                val isSelected = cat == selectedCategoryFilter
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedCategoryFilter = cat },
                    label = { Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = accentColor,
                        selectedLabelColor = Color.Black,
                        containerColor = Color(0xFF131722),
                        labelColor = Color.Gray
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Stats Summary Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131722)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatItem("TOTAL", "${songs.size}", accentColor)
                StatItem("FAVORITAS", "${songs.count { it.isFavorite }}", Color(0xFFFF007F))
                StatItem("LISTAS", "4", Color(0xFF00FF66))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Songs Header & Scan Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "COLECCIÓN MUSICAL",
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 13.sp,
                letterSpacing = 1.sp
            )
            IconButton(onClick = { viewModel.triggerMusicScan() }) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Escanear",
                    tint = if (isScanning) accentColor else Color.Gray
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (isScanning) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = accentColor, modifier = Modifier.size(32.dp))
            }
        }

        if (filteredSongs.isEmpty() && !isScanning) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (searchQuery.isNotEmpty()) "No se encontraron canciones coincidentes." else "No hay canciones en la biblioteca local.",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredSongs) { song ->
                    SongListItemRow(
                        song = song,
                        accentColor = accentColor,
                        onPlay = {
                            viewModel.playSong(song)
                            onNavigateToPlayer()
                        },
                        onFavorite = { viewModel.toggleFavorite(song) }
                    )
                }
            }
        }
    }
}

@Composable
fun StatItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, color = color, fontWeight = FontWeight.Black, fontSize = 18.sp, fontFamily = FontFamily.Monospace)
        Text(text = label, color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SongListItemRow(
    song: Song,
    accentColor: Color,
    onPlay: () -> Unit,
    onFavorite: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPlay() },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131722)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0A0B10))
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = song.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song.artist ?: "Artista Desconocido",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            IconButton(onClick = onFavorite) {
                Icon(
                    imageVector = if (song.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Favorito",
                    tint = if (song.isFavorite) Color(0xFFFF007F) else Color.Gray
                )
            }
        }
    }
}

/* ===================================================================
   2. REPRODUCCIÓN EN CURSO (NOW PLAYING SCREEN & VISUALIZER)
   =================================================================== */
@Composable
fun NowPlayingScreen(viewModel: MusicViewModel, accentColor: Color) {
    val isPlaying by viewModel.isPlaying.collectAsState()
    val currentMediaItem by viewModel.currentMediaItem.collectAsState()
    val currentPosition by viewModel.currentPosition.collectAsState()
    val duration by viewModel.duration.collectAsState()
    val shuffleMode by viewModel.shuffleModeEnabled.collectAsState()
    val repeatMode by viewModel.repeatMode.collectAsState()

    var activeVisualizerMode by remember { mutableStateOf("Barras Clásicas") }
    var showEqualizerPanel by remember { mutableStateOf(false) }
    var showLyricsPanel by remember { mutableStateOf(false) }

    // Vinyl Rotation Animation
    val infiniteTransition = rememberInfiniteTransition(label = "Vinyl")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Rotation"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Track Title & Artist Info Header
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val title = currentMediaItem?.mediaMetadata?.title?.toString() ?: "Sin Reproducción"
            val artist = currentMediaItem?.mediaMetadata?.artist?.toString() ?: "Selecciona una canción en Inicio"

            Text(
                text = title,
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = artist,
                color = accentColor,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center
            )
        }

        // Center Visualizer & Spinning Vinyl Deck
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(230.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF131722), Color(0xFF0A0B10))
                    )
                )
                .border(2.dp, accentColor.copy(alpha = 0.4f), CircleShape)
        ) {
            // Visualizer bars background ring
            VisualizerCanvasRing(activeVisualizerMode, isPlaying, accentColor)

            // Spinning Vinyl Core
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(130.dp)
                    .rotate(if (isPlaying) rotationAngle else 0f)
                    .clip(CircleShape)
                    .background(Color(0xFF1A2238))
                    .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0A0B10))
                )
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Disc",
                    tint = accentColor,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // Visualizer Style Switcher Buttons
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            val modes = listOf("Barras Clásicas", "Espectro Radial", "Onda Fluida", "Partículas", "Túnel Láser")
            items(modes) { mode ->
                val isSelected = mode == activeVisualizerMode
                Button(
                    onClick = { activeVisualizerMode = mode },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) accentColor else Color(0xFF131722),
                        contentColor = if (isSelected) Color.Black else Color.Gray
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(mode, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Seek Bar Progress
        Column(modifier = Modifier.fillMaxWidth()) {
            val positionMinutes = (currentPosition / 1000) / 60
            val positionSeconds = (currentPosition / 1000) % 60
            val durationMinutes = (duration / 1000) / 60
            val durationSeconds = (duration / 1000) % 60

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = String.format("%d:%02d", positionMinutes, positionSeconds),
                    color = Color.Gray,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = String.format("%d:%02d", durationMinutes, durationSeconds),
                    color = Color.Gray,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Slider(
                value = if (duration > 0) currentPosition.toFloat() else 0f,
                onValueChange = { viewModel.seekTo(it.toLong()) },
                valueRange = 0f..(duration.toFloat().coerceAtLeast(1f)),
                colors = SliderDefaults.colors(
                    activeTrackColor = accentColor,
                    inactiveTrackColor = Color(0xFF232C3F),
                    thumbColor = accentColor
                )
            )
        }

        // Master Playback Controls Deck
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.toggleShuffle() }) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Shuffle",
                    tint = if (shuffleMode) accentColor else Color.Gray
                )
            }

            IconButton(onClick = { viewModel.skipToPrevious() }) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Previous",
                    tint = Color.White
                )
            }

            FilledIconButton(
                onClick = { viewModel.playPause() },
                modifier = Modifier.size(60.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = if (isPlaying) Color(0xFFFF007F) else accentColor,
                    contentColor = Color.Black
                )
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Close else Icons.Default.PlayArrow,
                    contentDescription = "PlayPause",
                    modifier = Modifier.size(28.dp)
                )
            }

            IconButton(onClick = { viewModel.skipToNext() }) {
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Next",
                    tint = Color.White
                )
            }

            IconButton(onClick = { viewModel.cycleRepeatMode() }) {
                Text(
                    text = when (repeatMode) {
                        1 -> "1"
                        2 -> "ALL"
                        else -> "OFF"
                    },
                    color = if (repeatMode != 0) accentColor else Color.Gray,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Drawer Toggles for EQ and Lyrics
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            OutlinedButton(
                onClick = { showEqualizerPanel = !showEqualizerPanel },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = accentColor)
            ) {
                Text("Ecualizador 10-Band", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = { showLyricsPanel = !showLyricsPanel },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
            ) {
                Text("Letras Sincronizadas", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Panel Drawer Overlay for Equalizer
        if (showEqualizerPanel) {
            EqualizerCard(accentColor) { showEqualizerPanel = false }
        }

        // Panel Drawer Overlay for Lyrics
        if (showLyricsPanel) {
            LyricsCard(currentMediaItem?.mediaMetadata?.title?.toString() ?: "Sin Canción", accentColor) { showLyricsPanel = false }
        }
    }
}

@Composable
fun VisualizerCanvasRing(mode: String, isPlaying: Boolean, accentColor: Color) {
    val infiniteTransition = rememberInfiniteTransition(label = "Visualizer")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Pulse"
    )

    Row(
        modifier = Modifier.size(200.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val bars = 10
        for (i in 0 until bars) {
            val barHeight = if (isPlaying) (30..140).random() * pulse else 20f
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .height(barHeight.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(if (i % 2 == 0) accentColor else Color(0xFFFF007F))
            )
        }
    }
}

@Composable
fun EqualizerCard(accentColor: Color, onClose: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131722)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("ECUALIZADOR GRÁFICO (10 BANDAS)", color = accentColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = Color.Gray) }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth().height(90.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                val freqs = listOf("31", "63", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
                freqs.forEach { f ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .width(8.dp)
                                .height((30..70).random().dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(accentColor)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(f, color = Color.Gray, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

@Composable
fun LyricsCard(title: String, accentColor: Color, onClose: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131722)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("LETRAS SINCRONIZADAS: $title", color = accentColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = Color.Gray) }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("[00:12.50] Sintonizando letras dinámicas con la nave...", color = Color.White, fontSize = 12.sp)
            Text("[00:24.10] Escaneando frecuencia de audio y metadatos LRC...", color = accentColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("[00:36.80] La lírica sincronizada se mostrará en pantalla en tiempo real.", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

/* ===================================================================
   3. PANTALLA DE AJUSTES (SETTINGS WITH 12 CATEGORIES)
   =================================================================== */
@Composable
fun SettingsScreen(
    viewModel: MusicViewModel,
    accentColor: Color,
    onSelectAccentColor: (Color) -> Unit
) {
    var activeCategory by remember { mutableStateOf("Biblioteca") }
    val categories = listOf(
        "Biblioteca", "Reproducción", "Audio", "Apariencia",
        "Visualizador", "Letras", "Metadatos", "Herramientas",
        "Backup", "Avanzado", "Acerca"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "SISTEMAS Y AJUSTES DE LA NAVE",
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 14.sp,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Category Horizontal Selector
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(categories) { cat ->
                val isSelected = cat == activeCategory
                Button(
                    onClick = { activeCategory = cat },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) accentColor else Color(0xFF131722),
                        contentColor = if (isSelected) Color.Black else Color.Gray
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Dynamic Settings Content per Category
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131722)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Text(
                    text = "CATEGORÍA: ${activeCategory.uppercase()}",
                    color = accentColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(12.dp))

                when (activeCategory) {
                    "Biblioteca" -> SettingsLibraryCategory(viewModel, accentColor)
                    "Reproducción" -> SettingsPlaybackCategory(accentColor)
                    "Audio" -> SettingsAudioCategory(accentColor)
                    "Apariencia" -> SettingsAppearanceCategory(accentColor, onSelectAccentColor)
                    "Visualizador" -> SettingsVisualizerCategory(accentColor)
                    "Letras" -> SettingsLyricsCategory(accentColor)
                    "Metadatos" -> SettingsMetadataCategory(viewModel, accentColor)
                    "Herramientas" -> SettingsToolsCategory(accentColor)
                    "Backup" -> SettingsBackupCategory(accentColor)
                    "Avanzado" -> SettingsAdvancedCategory(accentColor)
                    else -> SettingsAboutCategory(accentColor)
                }
            }
        }
    }
}

@Composable
fun SettingsLibraryCategory(viewModel: MusicViewModel, accentColor: Color) {
    var autoScan by remember { mutableStateOf(true) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Escaneo Automático", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("Escanear música al iniciar la aplicación", color = Color.Gray, fontSize = 10.sp)
            }
            Switch(checked = autoScan, onCheckedChange = { autoScan = it })
        }
        Button(
            onClick = { viewModel.triggerMusicScan() },
            colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.Black),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("FORZAR ESCANEO DE ALMACENAMIENTO", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SettingsPlaybackCategory(accentColor: Color) {
    var crossfade by remember { mutableStateOf(true) }
    var gapless by remember { mutableStateOf(true) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Transición Suave (Crossfade)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Switch(checked = crossfade, onCheckedChange = { crossfade = it })
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Reproducción sin Pausas (Gapless)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Switch(checked = gapless, onCheckedChange = { gapless = it })
        }
    }
}

@Composable
fun SettingsAudioCategory(accentColor: Color) {
    var highRes by remember { mutableStateOf(true) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Motor Audio 320kbps High-Res", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("Renderizado de audio flotante de 32-bits", color = Color.Gray, fontSize = 10.sp)
            }
            Switch(checked = highRes, onCheckedChange = { highRes = it })
        }
    }
}

@Composable
fun SettingsAppearanceCategory(accentColor: Color, onSelectAccentColor: (Color) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Selecciona el Color de Acento Neón de la Nave:", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            val colors = listOf(
                Color(0xFF00E5FF), // Cian
                Color(0xFFFF007F), // Rosa
                Color(0xFF00FF66), // Verde
                Color(0xFFFFB300), // Ámbar
                Color(0xFF2979FF)  // Azul
            )
            colors.forEach { c ->
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(c)
                        .clickable { onSelectAccentColor(c) }
                        .border(if (c == accentColor) 3.dp else 0.dp, Color.White, CircleShape)
                )
            }
        }
    }
}

@Composable
fun SettingsVisualizerCategory(accentColor: Color) {
    var fps by remember { mutableStateOf("60 FPS") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Límite de Fotogramas (FPS del Espectro):", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("30 FPS", "60 FPS", "90 FPS", "120 FPS").forEach { option ->
                val isSelected = option == fps
                Button(
                    onClick = { fps = option },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) accentColor else Color(0xFF0A0B10),
                        contentColor = if (isSelected) Color.Black else Color.Gray
                    )
                ) {
                    Text(option, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SettingsLyricsCategory(accentColor: Color) {
    var autoLyrics by remember { mutableStateOf(true) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Buscar letras automáticas en red", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Switch(checked = autoLyrics, onCheckedChange = { autoLyrics = it })
        }
    }
}

@Composable
fun SettingsMetadataCategory(viewModel: MusicViewModel, accentColor: Color) {
    val songs by viewModel.allSongs.collectAsState()
    var titleInput by remember { mutableStateOf("") }
    var artistInput by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Editor de Etiquetas ID3 Rápido", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = titleInput,
            onValueChange = { titleInput = it },
            placeholder = { Text("Título nuevo de la canción...", fontSize = 11.sp, color = Color.Gray) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = artistInput,
            onValueChange = { artistInput = it },
            placeholder = { Text("Artista nuevo...", fontSize = 11.sp, color = Color.Gray) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun SettingsToolsCategory(accentColor: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
            onClick = {},
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22283A), contentColor = Color.White)
        ) {
            Text("Comprobar Integridad de Archivos MP3", fontSize = 10.sp)
        }
    }
}

@Composable
fun SettingsBackupCategory(accentColor: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
            onClick = {},
            colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.Black)
        ) {
            Text("EXPORTAR CONFIGURACIÓN Y LISTAS (JSON)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SettingsAdvancedCategory(accentColor: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Motor ExoPlayer Media3: ACTIVO", color = Color.Green, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        Text("Aceleración por Hardware Opengl ES: HABILITADA", color = Color.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun SettingsAboutCategory(accentColor: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("¿UNAS ROLITAS? - SPACESHIP PLAYER v1.0", color = accentColor, fontWeight = FontWeight.Black, fontSize = 12.sp)
        Text("Desarrollado para Android con Jetpack Compose y Media3 ExoPlayer.", color = Color.Gray, fontSize = 10.sp)
    }
}

/* ===================================================================
   FLOATING MINI PLAYER BAR
   =================================================================== */
@Composable
fun MiniPlayerBar(
    viewModel: MusicViewModel,
    accentColor: Color,
    onOpenPlayer: () -> Unit,
    onClose: () -> Unit
) {
    val isPlaying by viewModel.isPlaying.collectAsState()
    val currentMediaItem by viewModel.currentMediaItem.collectAsState()

    val title = currentMediaItem?.mediaMetadata?.title?.toString() ?: "Sin Reproducción"
    val artist = currentMediaItem?.mediaMetadata?.artist?.toString() ?: "Toca para abrir"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .clickable { onOpenPlayer() },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(accentColor)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Playing",
                        tint = Color.Black,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(text = title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
                    Text(text = artist, color = Color.Gray, fontSize = 10.sp, maxLines = 1)
                }
            }
            Row {
                IconButton(onClick = { viewModel.playPause() }) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Close else Icons.Default.PlayArrow,
                        contentDescription = "PlayPause",
                        tint = accentColor
                    )
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Clear, contentDescription = "Cerrar", tint = Color.Gray)
                }
            }
        }
    }
}

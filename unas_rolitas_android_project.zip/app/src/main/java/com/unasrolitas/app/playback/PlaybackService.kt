package com.unasrolitas.app.playback

import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {

    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null

    @OptIn(UnstableApi::class)
    override fun onCreate() {
        super.onCreate()
        
        // Initialize ExoPlayer with standard performance configurations
        player = ExoPlayer.Builder(this)
            .setHandleAudioBecomingNoisy(true) // Pauses automatically when headphones are unplugged
            .setWakeMode(1) // Keep CPU awake during active playback
            .build()

        // Create the MediaSession associated with this Player
        player?.let { activePlayer ->
            mediaSession = MediaSession.Builder(this, activePlayer)
                .build()
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onDestroy() {
        // Safe release of resources
        mediaSession?.let { session ->
            session.player.release()
            session.release()
            mediaSession = null
        }
        player = null
        super.onDestroy()
    }
}

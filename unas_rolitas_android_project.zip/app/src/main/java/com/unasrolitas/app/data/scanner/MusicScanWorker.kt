package com.unasrolitas.app.data.scanner

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.unasrolitas.app.data.local.MusicDatabase
import com.unasrolitas.app.data.repository.MusicRepository

class MusicScanWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val database = MusicDatabase.getDatabase(applicationContext)
        val repository = MusicRepository(database.songDao())
        val scanner = MusicScanner(applicationContext)

        return try {
            val localSongs = scanner.scanLocalMusic()
            if (localSongs.isNotEmpty()) {
                repository.insertSongs(localSongs)
            }
            Result.success()
        } catch (e: Exception) {
            Result.failure()
        }
    }
}

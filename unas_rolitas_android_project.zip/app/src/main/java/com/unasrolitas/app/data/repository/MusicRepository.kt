package com.unasrolitas.app.data.repository

import com.unasrolitas.app.data.local.SongDao
import com.unasrolitas.app.data.model.Song
import kotlinx.coroutines.flow.Flow

class MusicRepository(private val songDao: SongDao) {

    val allSongs: Flow<List<Song>> = songDao.getAllSongs()
    val favoriteSongs: Flow<List<Song>> = songDao.getFavoriteSongs()

    suspend fun getSongById(id: String): Song? {
        return songDao.getSongById(id)
    }

    suspend fun insertSongs(songs: List<Song>) {
        songDao.insertSongs(songs)
    }

    suspend fun toggleFavorite(id: String, isFavorite: Boolean) {
        songDao.updateFavoriteStatus(id, isFavorite)
    }

    suspend fun updateArtwork(id: String, artworkUrl: String) {
        songDao.updateArtwork(id, artworkUrl)
    }

    suspend fun updateLyrics(id: String, lyrics: String) {
        songDao.updateLyrics(id, lyrics)
    }

    suspend fun clearAll() {
        songDao.clearDatabase()
    }
}

package com.unasrolitas.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.unasrolitas.app.data.local.MusicDatabase
import com.unasrolitas.app.data.model.Song
import com.unasrolitas.app.data.repository.MusicRepository
import com.unasrolitas.app.data.scanner.MusicScanWorker
import com.unasrolitas.app.playback.MusicServiceConnection
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MusicViewModel(application: Application) : AndroidViewModel(application) {

    private val database = MusicDatabase.getDatabase(application)
    private val repository = MusicRepository(database.songDao())

    // Media3 Connection
    private val musicServiceConnection = MusicServiceConnection(application)

    // Expose Service connection state to Compose UI
    val isPlaying: StateFlow<Boolean> = musicServiceConnection.isPlaying
    val currentMediaItem = musicServiceConnection.currentMediaItem
    val playbackState = musicServiceConnection.playbackState
    val currentPosition: StateFlow<Long> = musicServiceConnection.currentPosition
    val duration: StateFlow<Long> = musicServiceConnection.duration
    val shuffleModeEnabled: StateFlow<Boolean> = musicServiceConnection.shuffleModeEnabled
    val repeatMode: StateFlow<Int> = musicServiceConnection.repeatMode

    // All songs from database
    val allSongs: StateFlow<List<Song>> = repository.allSongs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Favorite songs from database
    val favoriteSongs: StateFlow<List<Song>> = repository.favoriteSongs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Scanning status indicator
    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    init {
        // Run initial storage scan on launch
        triggerMusicScan()
    }

    fun triggerMusicScan() {
        viewModelScope.launch {
            _isScanning.value = true
            try {
                val workRequest = OneTimeWorkRequestBuilder<MusicScanWorker>().build()
                WorkManager.getInstance(getApplication()).enqueue(workRequest)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isScanning.value = false
            }
        }
    }

    // Playback functions
    fun playSong(song: Song) {
        val currentQueue = allSongs.value
        if (currentQueue.isNotEmpty()) {
            musicServiceConnection.playSong(song, currentQueue)
        }
    }

    fun playPause() {
        musicServiceConnection.playPause()
    }

    fun skipToNext() {
        musicServiceConnection.skipToNext()
    }

    fun skipToPrevious() {
        musicServiceConnection.skipToPrevious()
    }

    fun seekTo(positionMs: Long) {
        musicServiceConnection.seekTo(positionMs)
    }

    fun toggleShuffle() {
        musicServiceConnection.toggleShuffle()
    }

    fun cycleRepeatMode() {
        musicServiceConnection.cycleRepeatMode()
    }

    fun toggleFavorite(song: Song) {
        viewModelScope.launch {
            repository.toggleFavorite(song.id, !song.isFavorite)
        }
    }

    fun addExternalLyrics(songId: String, lyrics: String) {
        viewModelScope.launch {
            repository.updateLyrics(songId, lyrics)
        }
    }

    fun updateExternalArtwork(songId: String, artworkUrl: String) {
        viewModelScope.launch {
            repository.updateArtwork(songId, artworkUrl)
        }
    }

    override fun onCleared() {
        super.onCleared()
        musicServiceConnection.release()
    }
}

package com.unasrolitas.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "songs")
data class Song(
    @PrimaryKey val id: String, // Typically the path or a hash of the path
    val title: String,
    val artist: String?,
    val album: String?,
    val durationMs: Long,
    val path: String,
    val mimeType: String?,
    val trackNumber: Int?,
    val year: Int?,
    val genre: String?,
    val isFavorite: Boolean = false,
    val externalArtworkUrl: String? = null,
    val externalLyrics: String? = null
)

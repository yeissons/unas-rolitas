import * as fs from "fs";
import * as path from "path";
// Import the existing files to preserve descriptions
import { androidFiles as existingFiles } from "../src/data/androidFiles";

interface CodeFile {
  path: string;
  name: string;
  language: string;
  content: string;
  description: string;
}

// Map file path to its existing metadata
const existingMap = new Map<string, { name: string; language: string; description: string }>();
existingFiles.forEach((file) => {
  existingMap.set(file.path, {
    name: file.name,
    language: file.language,
    description: file.description,
  });
});

const filesToInclude: string[] = [];

// Helper to recursively find files
function scanDir(dir: string) {
  if (!fs.existsSync(dir)) return;
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    // Relative path from project root
    const relPath = path.relative(".", fullPath);
    
    // Ignore build, .gradle, .idea, etc.
    if (entry.isDirectory()) {
      if (
        entry.name === "build" ||
        entry.name === ".gradle" ||
        entry.name === ".idea" ||
        entry.name === "node_modules" ||
        entry.name === "dist"
      ) {
        continue;
      }
      scanDir(fullPath);
    } else {
      filesToInclude.push(relPath);
    }
  }
}

// Scan files under app folder and root gradle files
scanDir("./app");
if (fs.existsSync("./settings.gradle.kts")) filesToInclude.push("settings.gradle.kts");
if (fs.existsSync("./build.gradle.kts")) filesToInclude.push("build.gradle.kts");
if (fs.existsSync("./gradle.properties")) filesToInclude.push("gradle.properties");

// Deduce language from extension
function getLanguage(filePath: string): string {
  const ext = path.extname(filePath);
  if (ext === ".kt" || ext === ".kts") return "kotlin";
  if (ext === ".xml") return "xml";
  if (ext === ".properties") return "properties";
  return "text";
}

// Generate nice default descriptions for new files
function getDefaultDescription(filePath: string): string {
  const name = path.basename(filePath);
  if (filePath.includes("res/values/strings.xml")) return "Define cadenas de texto y localizaciones de la aplicación.";
  if (filePath.includes("res/values/colors.xml")) return "Paleta de colores del tema de la aplicación.";
  if (filePath.includes("res/values/themes.xml")) return "Estilos y tema base para Jetpack Compose.";
  if (filePath.includes("MainActivity.kt")) return "Punto de entrada principal de la aplicación Android.";
  if (filePath.includes("MusicViewModel.kt")) return "ViewModel que expone el estado de reproducción y gestiona eventos de audio.";
  if (filePath.includes("PlaybackService.kt")) return "Servicio en primer plano que maneja ExoPlayer y la sesión de reproducción de audio.";
  if (filePath.endsWith(".kt")) return `Código fuente Kotlin: ${name}.`;
  if (filePath.endsWith(".xml")) return `Recurso de diseño XML: ${name}.`;
  return `Archivo de configuración del proyecto: ${name}.`;
}

const updatedFiles: CodeFile[] = [];

for (const relPath of filesToInclude) {
  try {
    const content = fs.readFileSync(relPath, "utf-8");
    const existing = existingMap.get(relPath);
    
    updatedFiles.push({
      path: relPath,
      name: existing?.name || path.basename(relPath),
      language: existing?.language || getLanguage(relPath),
      description: existing?.description || getDefaultDescription(relPath),
      content,
    });
  } catch (err) {
    console.error(`Error reading file ${relPath}:`, err);
  }
}

// Helper to escape contents for template literals safely
function escapeForTemplateLiteral(str: string): string {
  return str
    .replace(/\\/g, "\\\\")
    .replace(/`/g, "\\`")
    .replace(/\$/g, "\\$");
}

// Build the content of the generated file
let fileContent = `export interface CodeFile {
  path: string;
  name: string;
  language: string;
  content: string;
  description: string;
}

export const androidFiles: CodeFile[] = [`;

updatedFiles.forEach((file, index) => {
  const escapedContent = escapeForTemplateLiteral(file.content);
  fileContent += `
  {
    path: ${JSON.stringify(file.path)},
    name: ${JSON.stringify(file.name)},
    language: ${JSON.stringify(file.language)},
    description: ${JSON.stringify(file.description)},
    content: \`${escapedContent}\`
  }${index < updatedFiles.length - 1 ? "," : ""}`;
});

fileContent += `\n];\n`;

// Write back to the target file
const targetPath = "./src/data/androidFiles.ts";
fs.writeFileSync(targetPath, fileContent, "utf-8");
console.log(`Successfully synced ${updatedFiles.length} files to ${targetPath}`);

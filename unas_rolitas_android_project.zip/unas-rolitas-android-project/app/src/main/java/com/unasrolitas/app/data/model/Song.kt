package com.unasrolitas.app.data.model

data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: String,
    val albumArtUri: String? = null,
    val genre: String = "Desconocido",
    val year: Int = 2026,
    val isFavorite: Boolean = false,
    val playsCount: Int = 0,
    val format: String = "FLAC",
    val bitrateKbps: Int = 1411,
    val sampleRateHz: Int = 96000,
    val bitDepth: Int = 24
)
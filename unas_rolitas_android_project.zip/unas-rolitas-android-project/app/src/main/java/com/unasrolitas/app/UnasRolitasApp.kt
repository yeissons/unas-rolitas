package com.unasrolitas.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.unasrolitas.app.ui.components.BottomNavBar
import com.unasrolitas.app.ui.screens.*
import com.unasrolitas.app.ui.theme.*
import com.unasrolitas.app.viewmodel.MainViewModel

@Composable
fun UnasRolitasApp(
    viewModel: MainViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    ModalNavigationDrawer(
        drawerState = rememberDrawerState(
            initialValue = if (uiState.isDrawerOpen) DrawerValue.Open else DrawerValue.Closed
        ),
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = DarkSurface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(280.dp)
                        .padding(20.dp)
                ) {
                    Text(
                        text = "¿Unas Rolitas?",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp,
                        color = RosePrimary
                    )
                    Text(
                        text = "Reproductor Audiófilo Nativo v2.4",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    DrawerItem(icon = Icons.Default.LibraryMusic, title = "Biblioteca") {
                        viewModel.selectNavigationTab(0)
                        viewModel.toggleDrawer()
                    }
                    DrawerItem(icon = Icons.Default.PlayCircle, title = "Reproductor") {
                        viewModel.selectNavigationTab(1)
                        viewModel.toggleDrawer()
                    }
                    DrawerItem(icon = Icons.Default.GraphicEq, title = "Ecualizador & DSP") {
                        viewModel.selectNavigationTab(2)
                        viewModel.toggleDrawer()
                    }
                    DrawerItem(icon = Icons.Default.Build, title = "Herramientas de Audio") {
                        viewModel.selectNavigationTab(3)
                        viewModel.toggleDrawer()
                    }
                    DrawerItem(icon = Icons.Default.Settings, title = "Ajustes & Control") {
                        viewModel.selectNavigationTab(4)
                        viewModel.toggleDrawer()
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkBackground),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("⚡ Android 14+ Ready", color = AccentCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Media3 / ExoPlayer 1.2.0 • High Fidelity DSP", color = TextSecondary, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            bottomBar = {
                BottomNavBar(
                    selectedTab = uiState.selectedTab,
                    onTabSelected = { viewModel.selectNavigationTab(it) }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (uiState.selectedTab) {
                    0 -> LibraryScreen(viewModel = viewModel)
                    1 -> PlayerScreen(viewModel = viewModel)
                    2 -> EqualizerScreen(viewModel = viewModel)
                    3 -> ToolsScreen(viewModel = viewModel)
                    4 -> ControlCenterScreen(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun DrawerItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = title, tint = TextPrimary, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Text(text = title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}
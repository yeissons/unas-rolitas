import React, { useEffect, useRef, useState } from "react";
import { 
  ChevronDown, 
  MoreVertical, 
  Activity, 
  Disc, 
  Music, 
  Trash2, 
  Sliders, 
  Globe, 
  VolumeX, 
  Volume2, 
  Timer, 
  Heart, 
  Zap, 
  Shuffle, 
  SkipBack, 
  Pause, 
  Play, 
  SkipForward, 
  Repeat, 
  Repeat1,
  Search,
  BookOpen,
  Check,
  Eye,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Type,
  FileText,
  Share2,
  Copy,
  Info
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export interface Track {
  title: string;
  artist: string;
  album: string;
  duration: string;
  durationSec: number;
  genre: string;
  size: string;
  lyrics: string[];
  composer?: string;
  year?: string;
  plays?: number;
  dateAdded?: string;
  folder?: string;
  coverColor?: string;
}

const getTrackColors = (track: any) => {
  if (!track) return { bg: "from-cyan-950 via-slate-950 to-black", glow: "#00E5FF", text: "text-cyan-400" };
  
  if (track.coverColor) {
    switch (track.coverColor) {
      case "violeta":
        return { bg: "from-purple-950/40 via-neutral-950 to-neutral-950", glow: "#a855f7", text: "text-purple-400" };
      case "esmeralda":
        return { bg: "from-emerald-950/40 via-neutral-950 to-neutral-950", glow: "#10b981", text: "text-emerald-400" };
      case "dorado":
        return { bg: "from-yellow-950/40 via-neutral-950 to-neutral-950", glow: "#eab308", text: "text-yellow-400" };
      case "cian":
        return { bg: "from-cyan-950/40 via-neutral-950 to-neutral-950", glow: "#06b6d4", text: "text-cyan-400" };
      case "rosa":
        return { bg: "from-pink-950/40 via-neutral-950 to-neutral-950", glow: "#ec4899", text: "text-pink-400" };
      case "coral":
        return { bg: "from-orange-950/40 via-neutral-950 to-neutral-950", glow: "#f97316", text: "text-orange-400" };
      case "ambar":
        return { bg: "from-amber-950/40 via-neutral-950 to-neutral-950", glow: "#f59e0b", text: "text-amber-400" };
    }
  }

  switch (track.title) {
    case "Luna de Octubre":
      return { bg: "from-amber-950/40 via-neutral-950 to-neutral-950", glow: "#f59e0b", text: "text-amber-400" };
    case "Ecos del Silencio":
      return { bg: "from-teal-950/40 via-neutral-950 to-neutral-950", glow: "#14b8a6", text: "text-teal-400" };
    case "Atardecer":
      return { bg: "from-rose-950/40 via-neutral-950 to-neutral-950", glow: "#f43f5e", text: "text-rose-400" };
    case "Vuelo Libre":
      return { bg: "from-cyan-950/40 via-neutral-950 to-neutral-950", glow: "#06b6d4", text: "text-cyan-400" };
    case "Ritmo Urbano":
      return { bg: "from-fuchsia-950/40 via-neutral-950 to-neutral-950", glow: "#d946ef", text: "text-fuchsia-400" };
    default:
      return { bg: "from-blue-950/40 via-neutral-950 to-neutral-950", glow: "#3b82f6", text: "text-blue-400" };
  }
};

interface FullPlayerProps {
  currentTrack: Track;
  isPlaying: boolean;
  setIsPlaying: (playing: boolean) => void;
  currentTime: number;
  setCurrentTime: (time: number) => void;
  playbackQueue: Track[];
  setPlaybackQueue: (queue: Track[]) => void;
  currentQueueIndex: number;
  setCurrentQueueIndex: (index: number) => void;
  shuffleOn: boolean;
  setShuffleOn: (on: boolean) => void;
  repeatMode: "none" | "one" | "all";
  setRepeatMode: (mode: "none" | "one" | "all") => void;
  isFullPlayerExpanded: boolean;
  setIsFullPlayerExpanded: (expanded: boolean) => void;
  fullPlayerSubTab: "reproductor" | "cola" | "letras";
  setFullPlayerSubTab: (tab: "reproductor" | "cola" | "letras") => void;
  playerViewMode: "cover" | "visualizer";
  setPlayerViewMode: (mode: "cover" | "visualizer") => void;
  visualizerStyle: "barras" | "espectro" | "ondas" | "particulas" | "lineas" | "luces";
  setVisualizerStyle: (style: "barras" | "espectro" | "ondas" | "particulas" | "lineas" | "luces") => void;
  isQuickActionsExpanded: boolean;
  setIsQuickActionsExpanded: (expanded: boolean) => void;
  playbackVolume: number;
  setPlaybackVolume: (volume: number) => void;
  sleepTimer: number | null;
  setSleepTimer: (timer: number | null) => void;
  sleepTimerPreset: "Off" | "5m" | "15m" | "30m" | "60m";
  setSleepTimerPreset: (preset: "Off" | "5m" | "15m" | "30m" | "60m") => void;
  playbackSpeed: number;
  setPlaybackSpeed: (speed: number) => void;
  abRepeat: { a: number | null; b: number | null };
  setAbRepeat: (ab: { a: number | null; b: number | null }) => void;
  timeFormatLeft: "elapsed" | "remaining" | "total";
  setTimeFormatLeft: (format: "elapsed" | "remaining" | "total") => void;
  timeFormatRight: "elapsed" | "remaining" | "total";
  setTimeFormatRight: (format: "elapsed" | "remaining" | "total") => void;
  lyricsSearchQuery: string;
  setLyricsSearchQuery: (query: string) => void;
  isLyricsSearching: boolean;
  setIsLyricsSearching: (searching: boolean) => void;
  lyricsSyncOffset: number;
  setLyricsSyncOffset: (offset: number) => void;
  lyricsTranslationEnabled: boolean;
  setLyricsTranslationEnabled: (enabled: boolean) => void;
  lyricsTextSize: "sm" | "md" | "lg" | "xl";
  setLyricsTextSize: (size: "sm" | "md" | "lg" | "xl") => void;
  lyricsAlignment: "left" | "center" | "right";
  setLyricsAlignment: (alignment: "left" | "center" | "right") => void;
  lyricsTheme: "neon" | "classic" | "warm" | "dark";
  setLyricsTheme: (theme: "neon" | "classic" | "warm" | "dark") => void;
  lyricsKaraokeEnabled: boolean;
  setLyricsKaraokeEnabled: (enabled: boolean) => void;
  lyricsAutoScrollEnabled: boolean;
  setLyricsAutoScrollEnabled: (enabled: boolean) => void;
  isLyricsSettingsOpen: boolean;
  setIsLyricsSettingsOpen: (open: boolean) => void;
  customLyricsMap: { [songTitle: string]: string[] };
  setCustomLyricsMap: (map: { [songTitle: string]: string[] }) => void;
  isSaveQueueModalOpen: boolean;
  setIsSaveQueueModalOpen: (open: boolean) => void;
  isLoadQueueModalOpen: boolean;
  setIsLoadQueueModalOpen: (open: boolean) => void;
  newPlaylistNameInput: string;
  setNewPlaylistNameInput: (input: string) => void;
  isLyricsModalOpen: boolean;
  setIsLyricsModalOpen: (open: boolean) => void;
  lyricsModalTitle: string;
  setLyricsModalTitle: (title: string) => void;
  lyricsModalContent: string;
  setLyricsModalContent: (content: string) => void;
  lyricsModalType: "import" | "export" | "share" | "copy";
  setLyricsModalType: (type: "import" | "export" | "share" | "copy") => void;
  lyricsImportInput: string;
  setLyricsImportInput: (input: string) => void;
  blacklistedSongs: string[];
  setBlacklistedSongs: (songs: string[]) => void;
  hiddenSongs: string[];
  setHiddenSongs: (songs: string[]) => void;
  playlists: { [name: string]: string[] };
  setPlaylists: (playlists: { [name: string]: string[] }) => void;
  libraryTab: string;
  setLibraryTab: (tab: string) => void;
  activePlaylistName: string | null;
  setActivePlaylistName: (name: string | null) => void;
  sortBy: string;
  setSortBy: (sort: string) => void;
  isSortDropdownOpen: boolean;
  setIsSortDropdownOpen: (open: boolean) => void;
  isDrawerOpen: boolean;
  setIsDrawerOpen: (open: boolean) => void;
  isSearching: boolean;
  setIsSearching: (searching: boolean) => void;
  activeOptionsTrack: Track | null;
  setActiveOptionsTrack: (track: Track | null) => void;
  expandedCategory: string | null;
  setExpandedCategory: (category: string | null) => void;
  isMobileLightMode: boolean;
  setIsMobileLightMode: (mode: boolean) => void;
  playSynthBeep: (freq: number, duration: number, type?: OscillatorType) => void;
  showToast: (msg: string) => void;
  addLiveLog: (log: string) => void;
  handlePrevTrack: () => void;
  handleNextTrack: () => void;
  toggleFavorite: (title: string) => void;
  eqPreset: "Bass Boost" | "Vocal Boost" | "Clásico" | "Plano";
  setEqPreset: (preset: "Bass Boost" | "Vocal Boost" | "Clásico" | "Plano") => void;
  eqBands: number[];
  setEqBands: (bands: number[]) => void;
  shuffleQueue: () => void;
  clearQueue: () => void;
  handleSaveQueueToPlaylist: (name: string) => void;
  loadPlaylistIntoQueue: (name: string) => void;
  moveQueueTrackUp: (index: number) => void;
  moveQueueTrackDown: (index: number) => void;
  removeQueueTrack: (index: number) => void;
  favoriteSongs: string[];
  draggedQueueIndex: number | null;
  setDraggedQueueIndex: (index: number | null) => void;
  handleQueueDragStart: (index: number) => void;
  handleQueueDragOver: (e: React.DragEvent, index: number) => void;
  handleQueueDrop: (index: number) => void;
  handleGestureStart: (clientX: number, clientY: number) => void;
  handleGestureEnd: (clientX: number, clientY: number) => void;
  activeLyricsIndex: number;
}

export const FullPlayer: React.FC<FullPlayerProps> = ({
  currentTrack,
  isPlaying,
  setIsPlaying,
  currentTime,
  setCurrentTime,
  playbackQueue,
  setPlaybackQueue,
  currentQueueIndex,
  setCurrentQueueIndex,
  shuffleOn,
  setShuffleOn,
  repeatMode,
  setRepeatMode,
  isFullPlayerExpanded,
  setIsFullPlayerExpanded,
  fullPlayerSubTab,
  setFullPlayerSubTab,
  playerViewMode,
  setPlayerViewMode,
  visualizerStyle,
  setVisualizerStyle,
  isQuickActionsExpanded,
  setIsQuickActionsExpanded,
  playbackVolume,
  setPlaybackVolume,
  sleepTimer,
  setSleepTimer,
  sleepTimerPreset,
  setSleepTimerPreset,
  playbackSpeed,
  setPlaybackSpeed,
  abRepeat,
  setAbRepeat,
  timeFormatLeft,
  setTimeFormatLeft,
  timeFormatRight,
  setTimeFormatRight,
  lyricsSearchQuery,
  setLyricsSearchQuery,
  isLyricsSearching,
  setIsLyricsSearching,
  lyricsSyncOffset,
  setLyricsSyncOffset,
  lyricsTranslationEnabled,
  setLyricsTranslationEnabled,
  lyricsTextSize,
  setLyricsTextSize,
  lyricsAlignment,
  setLyricsAlignment,
  lyricsTheme,
  setLyricsTheme,
  lyricsKaraokeEnabled,
  setLyricsKaraokeEnabled,
  lyricsAutoScrollEnabled,
  setLyricsAutoScrollEnabled,
  isLyricsSettingsOpen,
  setIsLyricsSettingsOpen,
  customLyricsMap,
  setCustomLyricsMap,
  isSaveQueueModalOpen,
  setIsSaveQueueModalOpen,
  isLoadQueueModalOpen,
  setIsLoadQueueModalOpen,
  newPlaylistNameInput,
  setNewPlaylistNameInput,
  isLyricsModalOpen,
  setIsLyricsModalOpen,
  lyricsModalTitle,
  setLyricsModalTitle,
  lyricsModalContent,
  setLyricsModalContent,
  lyricsModalType,
  setLyricsModalType,
  lyricsImportInput,
  setLyricsImportInput,
  blacklistedSongs,
  setBlacklistedSongs,
  hiddenSongs,
  setHiddenSongs,
  playlists,
  setPlaylists,
  libraryTab,
  setLibraryTab,
  activePlaylistName,
  setActivePlaylistName,
  sortBy,
  setSortBy,
  isSortDropdownOpen,
  setIsSortDropdownOpen,
  isDrawerOpen,
  setIsDrawerOpen,
  isSearching,
  setIsSearching,
  activeOptionsTrack,
  setActiveOptionsTrack,
  expandedCategory,
  setExpandedCategory,
  isMobileLightMode,
  setIsMobileLightMode,
  playSynthBeep,
  showToast,
  addLiveLog,
  handlePrevTrack,
  handleNextTrack,
  toggleFavorite,
  eqPreset,
  setEqPreset,
  eqBands,
  setEqBands,
  shuffleQueue,
  clearQueue,
  handleSaveQueueToPlaylist,
  loadPlaylistIntoQueue,
  moveQueueTrackUp,
  moveQueueTrackDown,
  removeQueueTrack,
  favoriteSongs,
  draggedQueueIndex,
  setDraggedQueueIndex,
  handleQueueDragStart,
  handleQueueDragOver,
  handleQueueDrop,
  handleGestureStart,
  handleGestureEnd,
  activeLyricsIndex
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const lyricsContainerRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll inside FullPlayer
  useEffect(() => {
    if (fullPlayerSubTab === "letras" && lyricsAutoScrollEnabled) {
      const activeEl = document.getElementById(`lyric-line-${activeLyricsIndex}`);
      if (activeEl && lyricsContainerRef.current) {
        lyricsContainerRef.current.scrollTo({
          top: activeEl.offsetTop - (lyricsContainerRef.current.clientHeight / 2) + (activeEl.clientHeight / 2),
          behavior: "smooth"
        });
      }
    }
  }, [activeLyricsIndex, fullPlayerSubTab, lyricsAutoScrollEnabled]);

  // Formatter for seek times
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? "0" : ""}${s}`;
  };

  const getFormattedTimeForLabel = (current: number, duration: number, format: "elapsed" | "remaining" | "total") => {
    if (format === "elapsed") {
      return formatTime(current);
    } else if (format === "remaining") {
      return "-" + formatTime(Math.max(0, duration - current));
    } else {
      return formatTime(duration);
    }
  };

  // Re-link the visualizer drawing loop internally for high-performance canvas updates
  useEffect(() => {
    let animationFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    let time = 0;
    const barCount = 32;
    const bars: number[] = Array(barCount).fill(0).map(() => Math.random() * 20);
    const targetBars: number[] = Array(barCount).fill(0);
    
    const particleCount = 45;
    const particles = Array(particleCount).fill(0).map(() => ({
      x: width / 2,
      y: height / 2,
      angle: Math.random() * Math.PI * 2,
      speed: 0.5 + Math.random() * 2,
      size: 1 + Math.random() * 3,
      alpha: 0.2 + Math.random() * 0.8
    }));

    const render = () => {
      ctx.fillStyle = isMobileLightMode ? "rgba(245, 247, 250, 0.15)" : "rgba(4, 5, 8, 0.15)";
      ctx.fillRect(0, 0, width, height);

      time += isPlaying ? 0.05 : 0.01;

      const trackColors = getTrackColors(currentTrack);
      const glowColor = trackColors.glow;

      for (let i = 0; i < barCount; i++) {
        if (isPlaying) {
          const wave1 = Math.sin(time + i * 0.2) * 15;
          const wave2 = Math.cos(time * 0.7 - i * 0.4) * 10;
          const randomSpike = Math.random() > 0.95 ? Math.random() * 25 : 0;
          targetBars[i] = Math.max(5, 20 + wave1 + wave2 + randomSpike + (Math.sin(time * 2.3 + i * 0.5) * 12));
        } else {
          targetBars[i] = targetBars[i] * 0.92;
        }
        bars[i] += (targetBars[i] - bars[i]) * 0.15;
      }

      if (visualizerStyle === "barras") {
        const spacing = width / barCount;
        for (let i = 0; i < barCount; i++) {
          const barHeight = (bars[i] / 60) * (height * 0.65);
          const x = i * spacing + spacing / 4;
          const y = height - barHeight - 15;

          const grad = ctx.createLinearGradient(x, height - 15, x, y);
          grad.addColorStop(0, `${glowColor}11`);
          grad.addColorStop(0.5, `${glowColor}88`);
          grad.addColorStop(1, glowColor);

          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.roundRect(x, y, spacing / 2, barHeight, [4, 4, 0, 0]);
          ctx.fill();
        }
      } else if (visualizerStyle === "espectro") {
        const centerX = width / 2;
        const centerY = height / 2;
        const baseRadius = Math.min(width, height) * 0.22;
        const ringPulse = isPlaying ? Math.sin(time * 2) * 4 : 0;
        const radius = baseRadius + ringPulse;

        ctx.strokeStyle = `${glowColor}33`;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.stroke();

        for (let i = 0; i < barCount; i++) {
          const angle = (i / barCount) * Math.PI * 2 + (time * 0.1);
          const barHeight = (bars[i] / 60) * (Math.min(width, height) * 0.28);
          
          const startX = centerX + Math.cos(angle) * radius;
          const startY = centerY + Math.sin(angle) * radius;
          const endX = centerX + Math.cos(angle) * (radius + barHeight);
          const endY = centerY + Math.sin(angle) * (radius + barHeight);

          ctx.strokeStyle = glowColor;
          ctx.lineWidth = 2.5;
          ctx.lineCap = "round";
          ctx.beginPath();
          ctx.moveTo(startX, startY);
          ctx.lineTo(endX, endY);
          ctx.stroke();
        }
      } else if (visualizerStyle === "ondas") {
        ctx.lineWidth = 2;
        for (let w = 0; w < 3; w++) {
          ctx.strokeStyle = w === 0 ? glowColor : w === 1 ? `${glowColor}99` : `${glowColor}44`;
          ctx.beginPath();
          for (let x = 0; x < width; x += 3) {
            const indexFactor = x / width;
            const waveAmp = isPlaying ? (bars[Math.floor(indexFactor * barCount)] || 15) : 5;
            const phaseShift = time * (1.5 - w * 0.3) + w * Math.PI * 0.5;
            const freq = 0.015 + w * 0.005;
            const y = (height / 2) + Math.sin(x * freq + phaseShift) * waveAmp;

            if (x === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.stroke();
        }
      } else if (visualizerStyle === "particulas") {
        const centerX = width / 2;
        const centerY = height / 2;
        const avgBar = bars.reduce((a, b) => a + b, 0) / barCount;
        const speedMultiplier = isPlaying ? 1 + (avgBar / 20) : 0.2;

        particles.forEach((p) => {
          p.x += Math.cos(p.angle) * p.speed * speedMultiplier;
          p.y += Math.sin(p.angle) * p.speed * speedMultiplier;

          if (p.x < 0 || p.x > width || p.y < 0 || p.y > height) {
            p.x = centerX;
            p.y = centerY;
            p.angle = Math.random() * Math.PI * 2;
            p.speed = 0.5 + Math.random() * 2;
            p.size = 1 + Math.random() * 3;
            p.alpha = 0.2 + Math.random() * 0.8;
          }

          ctx.fillStyle = glowColor;
          ctx.globalAlpha = p.alpha;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (1 + (isPlaying ? avgBar / 35 : 0)), 0, Math.PI * 2);
          ctx.fill();
        });
        ctx.globalAlpha = 1.0;
      } else if (visualizerStyle === "lineas") {
        ctx.beginPath();
        ctx.moveTo(0, height);
        const spacing = width / (barCount - 1);
        for (let i = 0; i < barCount; i++) {
          const x = i * spacing;
          const barHeight = (bars[i] / 60) * (height * 0.45);
          const y = height - barHeight - 20;
          ctx.lineTo(x, y);
        }
        ctx.lineTo(width, height);
        ctx.closePath();

        const fillGrad = ctx.createLinearGradient(0, height / 2, 0, height);
        fillGrad.addColorStop(0, `${glowColor}33`);
        fillGrad.addColorStop(1, `${glowColor}00`);
        ctx.fillStyle = fillGrad;
        ctx.fill();

        ctx.beginPath();
        for (let i = 0; i < barCount; i++) {
          const x = i * spacing;
          const barHeight = (bars[i] / 60) * (height * 0.45);
          const y = height - barHeight - 20;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.strokeStyle = glowColor;
        ctx.lineWidth = 3;
        ctx.stroke();
      } else if (visualizerStyle === "luces") {
        const centerX = width / 2;
        const centerY = height / 2;
        const avgBar = bars.reduce((a, b) => a + b, 0) / barCount;
        const radius = Math.min(width, height) * 0.28 * (1 + (avgBar / 40));

        const lightGrad = ctx.createRadialGradient(centerX, centerY, 5, centerX, centerY, radius);
        lightGrad.addColorStop(0, `${glowColor}99`);
        lightGrad.addColorStop(0.3, `${glowColor}33`);
        lightGrad.addColorStop(0.7, `${glowColor}08`);
        lightGrad.addColorStop(1, "rgba(0,0,0,0)");

        ctx.fillStyle = lightGrad;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.fill();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [playerViewMode, visualizerStyle, isPlaying, currentTrack, isMobileLightMode]);

  const activeThemeBackgrounds = () => {
    if (fullPlayerSubTab === "letras") {
      if (lyricsTheme === "classic") return "bg-slate-950 text-white";
      if (lyricsTheme === "dark") return "bg-neutral-950 text-gray-200";
      if (lyricsTheme === "warm") return "bg-[#fdf6e3] text-[#586e75]";
      return "bg-black text-white";
    }
    return isMobileLightMode ? "bg-[#f8fafc]" : "bg-[#040508]";
  };

  return (
    <motion.div
      initial={{ y: "100%" }}
      animate={{ y: 0 }}
      exit={{ y: "100%" }}
      transition={{ type: "spring", damping: 25, stiffness: 220 }}
      className={`absolute inset-0 z-50 flex flex-col justify-between p-5 pb-7 overflow-hidden select-none transition-colors duration-500 ${activeThemeBackgrounds()} ${
        isMobileLightMode ? "text-slate-900" : "text-white"
      }`}
    >
      {/* 2. BACKGROUND GLOW: Ambient dynamic blur of cover artwork colors */}
      {fullPlayerSubTab !== "letras" && (
        <div className="absolute inset-0 -z-10 overflow-hidden pointer-events-none">
          <div 
            className="absolute top-[-10%] left-[-10%] w-[120%] h-[85%] rounded-full opacity-[0.24] blur-[90px] transition-all duration-1000"
            style={{
              background: `radial-gradient(circle, ${getTrackColors(currentTrack).glow} 0%, rgba(0,0,0,0) 80%)`
            }}
          />
          <div 
            className="absolute bottom-[-15%] right-[-10%] w-[100%] h-[70%] rounded-full opacity-[0.16] blur-[110px] transition-all duration-1000"
            style={{
              background: `radial-gradient(circle, ${getTrackColors(currentTrack).glow}88 0%, rgba(0,0,0,0) 80%)`
            }}
          />
          <div className={`absolute inset-0 backdrop-blur-[35px] ${isMobileLightMode ? "bg-white/40" : "bg-black/40"}`} />
        </div>
      )}

      {/* 1. TOP BAR (BARRA SUPERIOR) */}
      <div className="flex items-center justify-between shrink-0 mb-4 z-10">
        {/* Left Back Arrow / Minimize Button */}
        <button 
          onClick={() => {
            setIsFullPlayerExpanded(false);
            playSynthBeep(350, 0.05);
          }}
          className={`p-2 rounded-2xl transition-all ${
            isMobileLightMode ? "bg-black/5 hover:bg-black/10 text-slate-700" : "bg-white/5 hover:bg-white/10 text-gray-300"
          }`}
          title="Regresar a la biblioteca"
          id="btn-regresar"
        >
          <ChevronDown className="w-5 h-5" />
        </button>

        {/* Center Sub-tab Toggles */}
        <div className="flex items-center bg-black/40 backdrop-blur-md rounded-full p-0.5 border border-white/10 shadow-inner">
          <button
            onClick={() => {
              playSynthBeep(450, 0.04);
              setFullPlayerSubTab(fullPlayerSubTab === "cola" ? "reproductor" : "cola");
            }}
            className={`px-4 py-1.5 rounded-full text-[10px] font-black tracking-wider transition-all duration-300 ${
              fullPlayerSubTab === "cola"
                ? "bg-gradient-to-r from-cyan-400 to-blue-500 text-black shadow-md"
                : "text-gray-400 hover:text-white"
            }`}
            id="btn-cola"
          >
            COLA
          </button>
          <button
            onClick={() => {
              playSynthBeep(450, 0.04);
              setFullPlayerSubTab(fullPlayerSubTab === "letras" ? "reproductor" : "letras");
            }}
            className={`px-4 py-1.5 rounded-full text-[10px] font-black tracking-wider transition-all duration-300 ${
              fullPlayerSubTab === "letras"
                ? "bg-gradient-to-r from-cyan-400 to-blue-500 text-black shadow-md"
                : "text-gray-400 hover:text-white"
            }`}
            id="btn-letras"
          >
            LETRAS
          </button>
        </div>

        {/* Right Song Options Menu Button */}
        <button
          onClick={() => {
            playSynthBeep(450, 0.05);
            setActiveOptionsTrack(currentTrack);
            setExpandedCategory(null);
          }}
          className={`p-2 rounded-2xl transition-all ${
            isMobileLightMode ? "bg-black/5 hover:bg-black/10 text-slate-700" : "bg-white/5 hover:bg-white/10 text-gray-300"
          }`}
          title="Opciones de canción"
          id="btn-opciones"
        >
          <MoreVertical className="w-5 h-5" />
        </button>
      </div>

      {/* CORE VIEWPORT SUBTABS */}
      
      {/* SUBTAB 1: REPRODUCTOR PRINCIPAL */}
      {fullPlayerSubTab === "reproductor" && (
        <div className="flex-1 flex flex-col justify-between my-2 overflow-y-auto scrollbar-none space-y-4">
          
          {/* 2 & 3. ALBUM COVER / VINYL ART WITH GESTURES */}
          <div className="relative flex flex-col items-center justify-center py-2 shrink-0">
            {/* Horizontal view toggle overlay */}
            <div className="absolute top-0 right-2 flex flex-col gap-1 z-10">
              <button
                onClick={() => {
                  playSynthBeep(520, 0.05);
                  setPlayerViewMode(playerViewMode === "cover" ? "visualizer" : "cover");
                }}
                className="p-1.5 rounded-full bg-black/60 text-cyan-400 border border-cyan-400/25 hover:scale-105 active:scale-95 transition-all"
                title="Alternar Vista"
              >
                {playerViewMode === "cover" ? <Activity className="w-4 h-4" /> : <Disc className="w-4 h-4" />}
              </button>
            </div>

            {/* Main Interactive Touch Area */}
            <div 
              className="relative w-48 h-48 sm:w-56 sm:h-56 rounded-full bg-black/40 border border-white/5 flex items-center justify-center overflow-hidden shadow-2xl cursor-grab active:cursor-grabbing"
              style={{
                boxShadow: `0 20px 40px -15px ${getTrackColors(currentTrack).glow}44`
              }}
              onTouchStart={(e) => handleGestureStart(e.touches[0].clientX, e.touches[0].clientY)}
              onTouchEnd={(e) => handleGestureEnd(e.changedTouches[0].clientX, e.changedTouches[0].clientY)}
              onMouseDown={(e) => handleGestureStart(e.clientX, e.clientY)}
              onMouseUp={(e) => handleGestureEnd(e.clientX, e.clientY)}
            >
              {playerViewMode === "cover" ? (
                /* GORGEOUS ROUND VINYL WITH PIN HOLE AND TONEARM */
                <div className="relative w-full h-full flex items-center justify-center pointer-events-none select-none">
                  <div 
                    className="absolute inset-2 rounded-full opacity-[0.35] blur-lg transition-all duration-1000"
                    style={{
                      background: `radial-gradient(circle, ${getTrackColors(currentTrack).glow} 0%, rgba(0,0,0,0) 80%)`
                    }}
                  />
                  {/* Outer Vinyl ring */}
                  <div 
                    className={`w-44 h-44 rounded-full bg-neutral-950 border-4 border-neutral-900 flex items-center justify-center shadow-2xl relative`}
                    style={{
                      transform: `rotate(${currentTime * (isPlaying ? 30 : 0)}deg)`,
                      transition: isPlaying ? "transform 1s linear" : "transform 0.5s ease"
                    }}
                  >
                    <div className="absolute inset-1.5 border border-neutral-900/40 rounded-full" />
                    <div className="absolute inset-3 border border-neutral-900/35 rounded-full" />
                    <div className="absolute inset-6 border border-neutral-900/30 rounded-full" />
                    <div className="absolute inset-10 border border-neutral-900/20 rounded-full" />
                    
                    {/* Inner Label artwork center label */}
                    <div 
                      className="w-16 h-16 rounded-full border border-neutral-800 flex items-center justify-center overflow-hidden relative shadow-[0_0_12px_rgba(0,0,0,0.85)]"
                      style={{
                        background: `linear-gradient(135deg, ${getTrackColors(currentTrack).glow}bb 0%, #0c111c 100%)`
                      }}
                    >
                      <div className="absolute inset-1.5 rounded-full border border-white/5 bg-black/50 flex flex-col items-center justify-center p-0.5">
                        <span className="text-[5.5px] font-black text-white text-center truncate max-w-[36px] uppercase">{currentTrack.title}</span>
                        <span className="text-[4.5px] text-gray-400 text-center truncate max-w-[36px] mt-0.5">{currentTrack.artist}</span>
                      </div>
                      <div className="w-3.5 h-3.5 rounded-full bg-black border border-white/25 z-10 flex items-center justify-center">
                        <div className="w-1 h-1 rounded-full bg-neutral-700" />
                      </div>
                    </div>
                  </div>

                  {/* Tonearm needle indicator */}
                  <div className={`absolute top-2 right-4 w-12 h-16 origin-top-right transition-all duration-700 pointer-events-none ${isPlaying ? 'rotate-8 translate-x-1' : '-rotate-12 opacity-50'}`}>
                    <div className="w-1 h-10 bg-neutral-600 rounded-full relative shadow-md">
                      <div className="absolute top-0 right-[-1px] w-1.5 h-1.5 bg-neutral-500 rounded-full" />
                      <div className="absolute bottom-0 left-[-1.5px] w-2 h-4 bg-neutral-400 rounded-sm origin-top rotate-12" />
                    </div>
                  </div>
                </div>
              ) : (
                /* PROCEDURAL VISUALIZER CANVAS */
                <div className="w-full h-full p-4 relative flex flex-col justify-between">
                  <canvas 
                    ref={canvasRef} 
                    className="w-full h-full absolute inset-0 rounded-full"
                  />
                  
                  {/* Selector Strip inside visualizer */}
                  <div className="absolute inset-x-4 bottom-2 flex items-center justify-between z-10 bg-black/60 backdrop-blur-md py-1 px-2 rounded-full border border-white/5 shadow-md">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        playSynthBeep(450, 0.05);
                        const styles: typeof visualizerStyle[] = ["barras", "espectro", "ondas", "particulas", "lineas", "luces"];
                        const idx = styles.indexOf(visualizerStyle);
                        const prevIdx = (idx - 1 + styles.length) % styles.length;
                        setVisualizerStyle(styles[prevIdx]);
                      }}
                      className="p-1 text-gray-400 hover:text-cyan-400"
                    >
                      <ChevronDown className="w-3.5 h-3.5 rotate-90" />
                    </button>
                    
                    <span className="text-[7.5px] font-black tracking-widest text-cyan-400 uppercase">
                      {visualizerStyle === "barras" ? "BARRAS" :
                       visualizerStyle === "espectro" ? "ESPECTRO" :
                       visualizerStyle === "ondas" ? "ONDAS" :
                       visualizerStyle === "particulas" ? "PARTÍCULAS" :
                       visualizerStyle === "lineas" ? "LÍNEAS" : "LUCES"}
                    </span>

                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        playSynthBeep(450, 0.05);
                        const styles: typeof visualizerStyle[] = ["barras", "espectro", "ondas", "particulas", "lineas", "luces"];
                        const idx = styles.indexOf(visualizerStyle);
                        const nextIdx = (idx + 1) % styles.length;
                        setVisualizerStyle(styles[nextIdx]);
                      }}
                      className="p-1 text-gray-400 hover:text-cyan-400"
                    >
                      <ChevronDown className="w-3.5 h-3.5 -rotate-90" />
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Pagination indicators */}
            <div className="flex gap-1.5 mt-3">
              <button 
                onClick={() => setPlayerViewMode("cover")}
                className={`w-1.5 h-1.5 rounded-full transition-all ${playerViewMode === "cover" ? "bg-cyan-400 w-3.5" : "bg-white/20"}`}
              />
              <button 
                onClick={() => setPlayerViewMode("visualizer")}
                className={`w-1.5 h-1.5 rounded-full transition-all ${playerViewMode === "visualizer" ? "bg-cyan-400 w-3.5" : "bg-white/20"}`}
              />
            </div>
          </div>

          {/* 4. TRACK METADATA AREA */}
          <div className="text-center px-4 max-w-full shrink-0">
            <h2 className={`text-base font-black tracking-tight truncate ${isMobileLightMode ? "text-slate-900" : "text-white"}`}>
              {currentTrack.title}
            </h2>
            <p className={`text-xs font-bold mt-0.5 truncate ${getTrackColors(currentTrack).text}`}>
              {currentTrack.artist}
            </p>
            <div className="flex items-center justify-center gap-1.5 mt-1 opacity-70">
              <span className="text-[8px] font-mono text-gray-400 bg-black/15 px-1.5 py-0.5 rounded border border-white/5">
                {currentTrack.album || "Sencillo"}
              </span>
              <span className="text-[8px] font-mono text-gray-400 bg-black/15 px-1.5 py-0.5 rounded border border-white/5">
                {currentTrack.genre || "Pop"}
              </span>
            </div>
          </div>

          {/* 5. COLLAPSIBLE ACTIONS COMPONENT */}
          <div className={`mx-1 rounded-2xl border transition-all ${
            isMobileLightMode ? "bg-slate-100/90 border-slate-200" : "bg-white/5 border-white/5"
          }`}>
            <button 
              onClick={() => {
                playSynthBeep(450, 0.05);
                setIsQuickActionsExpanded(!isQuickActionsExpanded);
              }}
              className="w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-black tracking-wider text-gray-400 uppercase hover:text-white"
            >
              <span className="flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                Acciones Rápidas
              </span>
              <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${isQuickActionsExpanded ? 'rotate-180 text-cyan-400' : ''}`} />
            </button>

            {isQuickActionsExpanded && (
              <div className="px-3.5 pb-3.5 pt-1 space-y-3 border-t border-white/5 text-[11px] animate-fade-in">
                {/* 1. VOLUME PANEL */}
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => {
                      playSynthBeep(200, 0.05);
                      setPlaybackVolume(playbackVolume === 0 ? 80 : 0);
                    }}
                    className="text-gray-400 hover:text-white"
                  >
                    {playbackVolume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
                  </button>
                  <input 
                    type="range"
                    min="0"
                    max="100"
                    value={playbackVolume}
                    onChange={(e) => setPlaybackVolume(parseInt(e.target.value))}
                    className="flex-1 accent-cyan-400 bg-black/40 h-1 rounded-full outline-none"
                  />
                  <span className="font-mono w-6 text-right text-gray-400">{playbackVolume}%</span>
                </div>

                {/* 2, 3, 4, 5. CONTROLS GRID */}
                <div className="grid grid-cols-2 gap-2">
                  {/* 2. Sleep Timer */}
                  <button
                    onClick={() => {
                      playSynthBeep(440, 0.05);
                      let nextPreset: typeof sleepTimerPreset = "Off";
                      let sec: number | null = null;
                      if (sleepTimerPreset === "Off") { nextPreset = "5m"; sec = 5 * 60; }
                      else if (sleepTimerPreset === "5m") { nextPreset = "15m"; sec = 15 * 60; }
                      else if (sleepTimerPreset === "15m") { nextPreset = "30m"; sec = 30 * 60; }
                      else if (sleepTimerPreset === "30m") { nextPreset = "60m"; sec = 60 * 60; }
                      setSleepTimerPreset(nextPreset);
                      setSleepTimer(sec);
                      showToast(`Apagado automático: ${nextPreset}`);
                    }}
                    className="flex items-center justify-between p-2 rounded-xl bg-black/40 border border-white/5 hover:bg-black/60 text-left"
                  >
                    <div className="min-w-0">
                      <p className="text-[8px] text-gray-500 font-bold uppercase">Apagado Auto</p>
                      <p className="font-mono font-bold truncate text-cyan-400">
                        {sleepTimer !== null 
                          ? `⏰ ${Math.floor(sleepTimer / 60)}:${(sleepTimer % 60).toString().padStart(2, "0")}` 
                          : "Desactivado"}
                      </p>
                    </div>
                    <Timer className="w-3.5 h-3.5 text-gray-500 shrink-0 ml-1" />
                  </button>

                  {/* 3. Favorite Songs */}
                  <button
                    onClick={() => toggleFavorite(currentTrack.title)}
                    className="flex items-center justify-between p-2 rounded-xl bg-black/40 border border-white/5 hover:bg-black/60 text-left"
                  >
                    <div>
                      <p className="text-[8px] text-gray-500 font-bold uppercase">Favorito</p>
                      <p className="font-bold text-gray-300 text-[10px]">
                        {favoriteSongs.includes(currentTrack.title) ? "Sí" : "No"}
                      </p>
                    </div>
                    <Heart className={`w-3.5 h-3.5 shrink-0 ${favoriteSongs.includes(currentTrack.title) ? 'text-rose-500 fill-rose-500' : 'text-gray-500'}`} />
                  </button>

                  {/* 4. Equalizer Selector */}
                  <div className="flex flex-col p-2 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-[8px] text-gray-500 font-bold uppercase mb-0.5">Ecualizador</span>
                    <select
                      value={eqPreset}
                      onChange={(e) => {
                        playSynthBeep(480, 0.05);
                        const preset = e.target.value as any;
                        setEqPreset(preset);
                        if (preset === "Bass Boost") setEqBands([5, 8, 3, -1, -2]);
                        else if (preset === "Vocal Boost") setEqBands([-2, 1, 6, 4, 1]);
                        else if (preset === "Clásico") setEqBands([3, 2, -1, 3, 4]);
                        else if (preset === "Plano") setEqBands([0, 0, 0, 0, 0]);
                        showToast(`EQ: preset ${preset} aplicado`);
                      }}
                      className="bg-transparent text-gray-300 border-none outline-none font-bold text-[10px]"
                    >
                      <option value="Bass Boost">Bass Boost</option>
                      <option value="Vocal Boost">Vocal Boost</option>
                      <option value="Clásico">Clásico</option>
                      <option value="Plano">Plano</option>
                    </select>
                  </div>

                  {/* 5. Playback speed */}
                  <button
                    onClick={() => {
                      playSynthBeep(550, 0.05);
                      const speeds = [0.5, 1.0, 1.25, 1.5, 2.0];
                      const idx = speeds.indexOf(playbackSpeed);
                      const nextSpeed = speeds[(idx + 1) % speeds.length];
                      setPlaybackSpeed(nextSpeed);
                      showToast(`Velocidad: ${nextSpeed}x`);
                    }}
                    className="flex items-center justify-between p-2 rounded-xl bg-black/40 border border-white/5 hover:bg-black/60 text-left"
                  >
                    <div>
                      <p className="text-[8px] text-gray-500 font-bold uppercase">Velocidad</p>
                      <p className="font-bold text-cyan-400 font-mono text-[10px]">{playbackSpeed}x</p>
                    </div>
                    <Zap className="w-3.5 h-3.5 text-gray-500" />
                  </button>
                </div>

                {/* 6. A-B LOOP CONTROLLER PANEL */}
                <div className="bg-black/25 p-2 rounded-xl border border-white/5 flex items-center justify-between">
                  <div>
                    <p className="text-[8px] text-gray-500 font-bold uppercase">Bucle A-B</p>
                    <p className="font-mono text-[10px] text-gray-300">
                      {abRepeat.a !== null ? `A: ${formatTime(abRepeat.a)}` : "A: --"}
                      {" | "}
                      {abRepeat.b !== null ? `B: ${formatTime(abRepeat.b)}` : "B: --"}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <button 
                      onClick={() => {
                        playSynthBeep(450, 0.05);
                        setAbRepeat({ ...abRepeat, a: currentTime });
                        showToast("Bucle: Punto A fijado");
                      }}
                      className="px-2 py-0.5 rounded bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 text-[9px] font-black border border-cyan-400/20"
                    >
                      Fijar A
                    </button>
                    <button 
                      onClick={() => {
                        playSynthBeep(520, 0.05);
                        if (abRepeat.a === null) {
                          showToast("Primero fija Punto A");
                          return;
                        }
                        setAbRepeat({ ...abRepeat, b: currentTime });
                        showToast("Bucle: Punto B fijado. Repitiendo loop");
                      }}
                      className="px-2 py-0.5 rounded bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 text-[9px] font-black border border-cyan-400/20"
                    >
                      Fijar B
                    </button>
                    <button 
                      onClick={() => {
                        playSynthBeep(300, 0.05);
                        setAbRepeat({ a: null, b: null });
                        showToast("Bucle A-B borrado");
                      }}
                      className="px-2 py-0.5 rounded bg-red-500/10 hover:bg-red-500/20 text-red-400 text-[9px] font-black border border-red-500/25"
                    >
                      Limpiar
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 6. SEEK BAR (BARRA DE PROGRESO) */}
          <div className="w-full space-y-1 shrink-0 px-1">
            <div className="relative h-5 flex items-center cursor-pointer">
              <input 
                type="range"
                min="0"
                max={currentTrack.durationSec}
                value={currentTime}
                onChange={(e) => {
                  const targetSec = parseInt(e.target.value);
                  setCurrentTime(targetSec);
                  playSynthBeep(440 + targetSec, 0.05, "sine");
                }}
                className="w-full accent-cyan-400 bg-black/45 h-1 rounded-full outline-none cursor-pointer"
              />
            </div>
            <div className="flex justify-between text-[10px] text-gray-500 font-mono font-bold px-0.5">
              <button 
                onClick={() => {
                  playSynthBeep(450, 0.03);
                  const formats: typeof timeFormatLeft[] = ["elapsed", "remaining", "total"];
                  const nextIdx = (formats.indexOf(timeFormatLeft) + 1) % formats.length;
                  setTimeFormatLeft(formats[nextIdx]);
                }}
                className="hover:text-cyan-400"
              >
                {getFormattedTimeForLabel(currentTime, currentTrack.durationSec, timeFormatLeft)}
              </button>
              <button 
                onClick={() => {
                  playSynthBeep(450, 0.03);
                  const formats: typeof timeFormatRight[] = ["elapsed", "remaining", "total"];
                  const nextIdx = (formats.indexOf(timeFormatRight) + 1) % formats.length;
                  setTimeFormatRight(formats[nextIdx]);
                }}
                className="hover:text-cyan-400"
              >
                {getFormattedTimeForLabel(currentTime, currentTrack.durationSec, timeFormatRight)}
              </button>
            </div>
          </div>

          {/* 7. PLAYBACK CONTROLS (CONTROLES DE REPRODUCCIÓN) */}
          <div className="flex items-center justify-between px-3 shrink-0 py-1">
            {/* Shuffle */}
            <button
              onClick={() => {
                playSynthBeep(420, 0.05);
                setShuffleOn(!shuffleOn);
                showToast(shuffleOn ? "Modo aleatorio apagado" : "Modo aleatorio encendido");
              }}
              className={`p-2 hover:bg-white/5 rounded-full transition-all ${
                shuffleOn ? 'text-cyan-400' : 'text-gray-500 hover:text-white'
              }`}
              title="Aleatorio"
            >
              <Shuffle className="w-4 h-4" />
            </button>

            {/* Previous */}
            <button
              onClick={handlePrevTrack}
              className="p-2 hover:bg-white/5 rounded-full text-gray-300 hover:text-white transition-all active:scale-90"
              title="Anterior"
            >
              <SkipBack className="w-5 h-5 fill-white/10" />
            </button>

            {/* Play/Pause (Most Visually Prominent) */}
            <button
              onClick={() => {
                playSynthBeep(isPlaying ? 350 : 600, 0.05);
                setIsPlaying(!isPlaying);
              }}
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-all hover:scale-105 active:scale-95 ${
                isPlaying 
                  ? "bg-transparent border-2 border-cyan-400 text-cyan-400 shadow-[0_0_15px_rgba(0,229,255,0.35)]"
                  : "bg-cyan-400 text-black shadow-[0_5px_22px_rgba(0,229,255,0.45)]"
              }`}
              title={isPlaying ? "Pausar" : "Reproducir"}
            >
              {isPlaying 
                ? <Pause className="w-5 h-5 fill-current" /> 
                : <Play className="w-5 h-5 fill-current translate-x-0.5" />
              }
            </button>

            {/* Next */}
            <button
              onClick={handleNextTrack}
              className="p-2 hover:bg-white/5 rounded-full text-gray-300 hover:text-white transition-all active:scale-90"
              title="Siguiente"
            >
              <SkipForward className="w-5 h-5 fill-white/10" />
            </button>

            {/* Repeat loop cycling */}
            <button
              onClick={() => {
                playSynthBeep(460, 0.05);
                const nextMode = repeatMode === "all" ? "one" : repeatMode === "one" ? "none" : "all";
                setRepeatMode(nextMode);
                showToast(`Repetir: ${nextMode === "all" ? "Repetir todo" : nextMode === "one" ? "Repetir una" : "Apagado"}`);
              }}
              className={`p-2 hover:bg-white/5 rounded-full transition-all ${
                repeatMode !== "none" ? 'text-cyan-400' : 'text-gray-500 hover:text-white'
              }`}
              title="Repetir"
            >
              {repeatMode === "all" ? <Repeat className="w-4 h-4 text-cyan-400" /> : 
               repeatMode === "one" ? <Repeat1 className="w-4 h-4 text-cyan-400" /> : 
               <Repeat className="w-4 h-4 text-gray-500" />}
            </button>
          </div>

        </div>
      )}

      {/* SUBTAB 2: COLA DE REPRODUCCIÓN (DEDICATED FULL SCREEN) */}
      {fullPlayerSubTab === "cola" && (
        <div className="flex-1 flex flex-col justify-between my-2 overflow-hidden">
          {/* Header toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-1.5 border-b border-white/5 pb-2.5 mb-2 shrink-0">
            <h3 className="text-[10px] font-black tracking-widest text-cyan-400 uppercase">
              COLA ({playbackQueue.length})
            </h3>
            
            <div className="flex gap-1">
              <button
                onClick={shuffleQueue}
                className="px-2 py-0.5 rounded bg-white/5 border border-white/5 hover:bg-cyan-500/10 hover:text-cyan-400 text-[8.5px] font-black uppercase transition-all"
                title="Aleatorizar reproducción de la cola"
              >
                Mezclar Cola
              </button>
              <button
                onClick={() => {
                  playSynthBeep(450, 0.05);
                  setIsSaveQueueModalOpen(true);
                }}
                className="px-2 py-0.5 rounded bg-white/5 border border-white/5 hover:bg-cyan-500/10 hover:text-cyan-400 text-[8.5px] font-black uppercase transition-all"
              >
                Guardar
              </button>
              <button
                onClick={() => {
                  playSynthBeep(450, 0.05);
                  setIsLoadQueueModalOpen(true);
                }}
                className="px-2 py-0.5 rounded bg-white/5 border border-white/5 hover:bg-cyan-500/10 hover:text-cyan-400 text-[8.5px] font-black uppercase transition-all"
              >
                Cargar
              </button>
              <button
                onClick={clearQueue}
                className="px-2 py-0.5 rounded bg-red-500/5 border border-red-500/10 hover:bg-red-500/20 text-red-400 text-[8.5px] font-black uppercase transition-all"
              >
                Vaciar
              </button>
            </div>
          </div>

          {/* Sonando Ahora active row */}
          <div className="p-3 mb-2 bg-cyan-950/20 rounded-2xl border border-cyan-500/20 shrink-0">
            <span className="text-[7.5px] font-black tracking-wider text-cyan-400 uppercase block mb-0.5">
              🔊 SONANDO AHORA
            </span>
            <div className="flex items-center justify-between">
              <div className="min-w-0">
                <h4 className="text-xs font-bold text-white truncate">{currentTrack.title}</h4>
                <p className="text-[9.5px] text-cyan-400/80 font-medium truncate">{currentTrack.artist}</p>
              </div>
              <div className="flex items-end gap-0.5 h-3 px-1.5">
                <div className="w-0.5 bg-cyan-400 animate-pulse h-2.5" />
                <div className="w-0.5 bg-cyan-400 animate-ping h-3" />
                <div className="w-0.5 bg-cyan-400 animate-pulse h-1.5" />
              </div>
            </div>
          </div>

          {/* Draggable scroll list */}
          <div className="flex-1 overflow-y-auto pr-0.5 space-y-1.5 scrollbar-none">
            <span className="text-[8px] font-black tracking-wider text-gray-500 uppercase block px-1">
              SIGUIENTES EN LA COLA (Arrastra para reordenar)
            </span>
            
            {playbackQueue.map((track, index) => {
              const isActive = index === currentQueueIndex;
              const isBeingDragged = index === draggedQueueIndex;
              return (
                <div 
                  key={`${track.title}-${index}`}
                  draggable={true}
                  onDragStart={() => handleQueueDragStart(index)}
                  onDragOver={(e) => handleQueueDragOver(e, index)}
                  onDrop={() => handleQueueDrop(index)}
                  onDragEnd={() => setDraggedQueueIndex(null)}
                  className={`flex items-center justify-between p-2 rounded-xl border cursor-grab active:cursor-grabbing transition-all ${
                    isActive 
                      ? "bg-cyan-500/10 border-cyan-400/40 text-cyan-400" 
                      : isBeingDragged 
                        ? "opacity-40 bg-neutral-900 border-dashed border-cyan-400"
                        : "bg-black/25 border-white/5 hover:bg-black/35 text-gray-300"
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0 flex-1 pointer-events-none">
                    <span className="font-mono text-[9px] text-gray-500 w-4 text-center shrink-0">
                      {index + 1}
                    </span>
                    <div className="min-w-0">
                      <h5 className="text-xs font-bold truncate">{track.title}</h5>
                      <p className="text-[9px] text-gray-500 truncate">{track.artist}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0 ml-1.5">
                    <button
                      onClick={() => moveQueueTrackUp(index)}
                      disabled={index === 0}
                      className="p-1 text-gray-500 hover:text-white disabled:opacity-30"
                      title="Subir"
                    >
                      <ChevronDown className="w-3.5 h-3.5 rotate-180" />
                    </button>
                    <button
                      onClick={() => moveQueueTrackDown(index)}
                      disabled={index === playbackQueue.length - 1}
                      className="p-1 text-gray-500 hover:text-white disabled:opacity-30"
                      title="Bajar"
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => removeQueueTrack(index)}
                      className="p-1 text-gray-500 hover:text-rose-400"
                      title="Eliminar"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      )}

      {/* SUBTAB 3: LETRAS AVANZADAS (DEDICATED FULL SCREEN) */}
      {fullPlayerSubTab === "letras" && (
        <div className="flex-1 flex flex-col justify-between my-2 overflow-hidden relative">
          
          {/* Top header configuration strip */}
          <div className="flex items-center justify-between border-b border-white/5 pb-2 shrink-0 mb-3 z-10">
            <span className="text-[9px] font-black tracking-widest text-cyan-400 uppercase">
              LETRAS DE LA ROLA
            </span>

            <div className="relative">
              {/* MoreVertical opens the options list */}
              <button
                onClick={() => {
                  playSynthBeep(450, 0.05);
                  setIsLyricsSettingsOpen(!isLyricsSettingsOpen);
                }}
                className="flex items-center gap-1 p-1.5 rounded-full bg-cyan-500/10 text-cyan-400 hover:bg-cyan-500/20 text-[9px] font-black border border-cyan-400/25 transition-all uppercase"
                id="btn-ajustar-letras"
                title="Ajustar Letras"
              >
                <Sliders className="w-3.5 h-3.5" />
              </button>

              {/* Floating Settings Dropdown Overlay */}
              <AnimatePresence>
                {isLyricsSettingsOpen && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 10 }}
                    className="absolute right-0 top-7 w-60 max-h-[320px] overflow-y-auto bg-neutral-950 border border-neutral-800 rounded-2xl p-3 shadow-2xl z-50 text-[11px] space-y-3.5 scrollbar-none"
                  >
                    <div className="flex items-center justify-between border-b border-white/5 pb-1 font-black uppercase text-cyan-400 text-[9px]">
                      <span>Menú de Opciones</span>
                      <button onClick={() => setIsLyricsSettingsOpen(false)} className="text-gray-400 hover:text-white">✕</button>
                    </div>

                    {/* 1. Buscar Letra Online */}
                    <div className="space-y-1">
                      <p className="text-[8px] text-gray-500 font-bold uppercase">1. Buscar en Internet</p>
                      <div className="flex gap-1">
                        <input 
                          type="text"
                          placeholder="Título..."
                          value={lyricsSearchQuery}
                          onChange={(e) => setLyricsSearchQuery(e.target.value)}
                          className="flex-1 bg-neutral-900 border border-neutral-800 rounded px-1.5 py-0.5 text-[9.5px] outline-none text-white font-medium"
                        />
                        <button
                          onClick={() => {
                            playSynthBeep(650, 0.08);
                            setIsLyricsSearching(true);
                            setTimeout(() => {
                              setIsLyricsSearching(false);
                              const query = lyricsSearchQuery.trim() || currentTrack.title;
                              const mockResults = [
                                `[00:05.00] Versión lírica de ${query}`,
                                `[00:10.00] Traducida al inglés - ${query}`,
                                `[00:15.00] Karaoke oficial - ${query}`
                              ];
                              setCustomLyricsMap({
                                ...customLyricsMap,
                                [currentTrack.title]: mockResults
                              });
                              showToast(`Líricas online para "${query}" aplicadas`);
                              setIsLyricsSettingsOpen(false);
                            }, 1000);
                          }}
                          className="px-2 py-0.5 rounded bg-cyan-400 text-black font-black text-[9px]"
                        >
                          {isLyricsSearching ? "..." : "Buscar"}
                        </button>
                      </div>
                    </div>

                    {/* 2 & 3. Sincronizar letra manualmente & retraso */}
                    <div className="space-y-1">
                      <p className="text-[8px] text-gray-500 font-bold uppercase">2 & 3. Sincronizar offset</p>
                      <div className="flex items-center justify-between p-1.5 rounded bg-white/5 border border-white/5">
                        <span className="text-[9px] font-mono text-cyan-400">Offset: {lyricsSyncOffset > 0 ? `+${lyricsSyncOffset.toFixed(1)}s` : `${lyricsSyncOffset.toFixed(1)}s`}</span>
                        <div className="flex gap-1 shrink-0">
                          <button 
                            onClick={() => { setLyricsSyncOffset(lyricsSyncOffset - 0.5); playSynthBeep(450, 0.04); showToast("Letra adelantada 0.5s"); }} 
                            className="w-5 h-5 rounded bg-neutral-900 hover:bg-neutral-800 text-cyan-400 font-bold flex items-center justify-center border border-white/5"
                          >
                            -
                          </button>
                          <button 
                            onClick={() => { setLyricsSyncOffset(lyricsSyncOffset + 0.5); playSynthBeep(450, 0.04); showToast("Letra atrasada 0.5s"); }} 
                            className="w-5 h-5 rounded bg-neutral-900 hover:bg-neutral-800 text-cyan-400 font-bold flex items-center justify-center border border-white/5"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* 4. Importar LRC */}
                    <div className="space-y-1">
                      <p className="text-[8px] text-gray-500 font-bold uppercase">4. Importar archivo LRC</p>
                      <button
                        onClick={() => {
                          playSynthBeep(550, 0.08);
                          setLyricsModalType("import");
                          setLyricsModalTitle("Importar Archivo LRC");
                          setLyricsImportInput("");
                          setIsLyricsModalOpen(true);
                          setIsLyricsSettingsOpen(false);
                        }}
                        className="w-full text-center py-0.5 bg-cyan-500/10 border border-cyan-400/25 hover:bg-cyan-500/20 text-cyan-400 font-bold rounded"
                      >
                        Pegar / Importar LRC
                      </button>
                    </div>

                    {/* 5. Exportar LRC */}
                    <div className="space-y-1">
                      <p className="text-[8px] text-gray-500 font-bold uppercase">5. Exportar archivo LRC</p>
                      <button
                        onClick={() => {
                          playSynthBeep(600, 0.08);
                          const lines = customLyricsMap[currentTrack.title] || currentTrack.lyrics;
                          const lrcFormatted = lines.map((l, i) => `[00:${(i * 4).toString().padStart(2, "0")}.00] ${l}`).join("\n");
                          setLyricsModalType("export");
                          setLyricsModalTitle("Exportar Archivo LRC");
                          setLyricsModalContent(lrcFormatted);
                          setIsLyricsModalOpen(true);
                          setIsLyricsSettingsOpen(false);
                        }}
                        className="w-full text-center py-0.5 bg-white/5 hover:bg-white/10 text-gray-300 font-bold rounded"
                      >
                        Exportar a LRC
                      </button>
                    </div>

                    {/* 6 & 7. Traducción vs Letra original */}
                    <div className="space-y-1">
                      <p className="text-[8px] text-gray-500 font-bold uppercase">6 & 7. Idioma Letra</p>
                      <div className="flex gap-1">
                        <button
                          onClick={() => { setLyricsTranslationEnabled(true); playSynthBeep(400, 0.03); showToast("Traducción activada"); }}
                          className={`flex-1 text-center py-1 text-[9px] font-black rounded ${lyricsTranslationEnabled ? 'bg-cyan-400 text-black' : 'bg-white/5 text-gray-400'}`}
                        >
                          Traducción
                        </button>
                        <button
                          onClick={() => { setLyricsTranslationEnabled(false); playSynthBeep(400, 0.03); showToast("Letra original activada"); }}
                          className={`flex-1 text-center py-1 text-[9px] font-black rounded ${!lyricsTranslationEnabled ? 'bg-cyan-400 text-black' : 'bg-white/5 text-gray-400'}`}
                        >
                          Original
                        </button>
                      </div>
                    </div>

                    {/* 8. Cambiar tamaño del texto */}
                    <div className="space-y-1">
                      <p className="text-[8px] text-gray-500 font-bold uppercase">8. Tamaño del texto</p>
                      <div className="flex justify-between gap-1">
                        {(["sm", "md", "lg", "xl"] as const).map((sz) => (
                          <button
                            key={sz}
                            onClick={() => { setLyricsTextSize(sz); playSynthBeep(420, 0.03); }}
                            className={`flex-1 py-0.5 text-[9px] font-black rounded uppercase ${lyricsTextSize === sz ? "bg-cyan-400 text-black" : "bg-neutral-900 text-gray-400"}`}
                          >
                            {sz}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* 9. Cambiar alineación */}
                    <div className="space-y-1">
                      <p className="text-[8px] text-gray-500 font-bold uppercase">9. Alineación de letras</p>
                      <div className="flex justify-between gap-1">
                        {(["left", "center", "right"] as const).map((al) => (
                          <button
                            key={al}
                            onClick={() => { setLyricsAlignment(al); playSynthBeep(420, 0.03); }}
                            className={`flex-1 py-0.5 text-[9px] font-black rounded capitalize ${lyricsAlignment === al ? "bg-cyan-400 text-black" : "bg-neutral-900 text-gray-400"}`}
                          >
                            {al}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* 10. Cambiar tema de colores */}
                    <div className="space-y-1 flex items-center justify-between">
                      <p className="text-[8px] text-gray-500 font-bold uppercase">10. Tema Letra</p>
                      <select
                        value={lyricsTheme}
                        onChange={(e) => setLyricsTheme(e.target.value as any)}
                        className="bg-neutral-900 text-cyan-400 font-bold border-none outline-none rounded p-0.5 text-[9px]"
                      >
                        <option value="neon">Neon Glow</option>
                        <option value="classic">Classic Slate</option>
                        <option value="warm">Warm Cozy</option>
                        <option value="dark">Pure Dark</option>
                      </select>
                    </div>

                    {/* 11. Activar Karaoke */}
                    <div className="flex items-center justify-between p-0.5">
                      <span className="font-bold text-gray-400 text-[9px]">11. Efecto Karaoke</span>
                      <button
                        onClick={() => setLyricsKaraokeEnabled(!lyricsKaraokeEnabled)}
                        className={`w-7 h-4 rounded-full p-0.5 transition-all ${lyricsKaraokeEnabled ? "bg-cyan-400" : "bg-neutral-800"}`}
                      >
                        <div className={`w-3 h-3 rounded-full bg-white transition-all ${lyricsKaraokeEnabled ? 'translate-x-3.5' : 'translate-x-0'}`} />
                      </button>
                    </div>

                    {/* 12. Desplazamiento automático */}
                    <div className="flex items-center justify-between p-0.5">
                      <span className="font-bold text-gray-400 text-[9px]">12. Auto Scroll</span>
                      <button
                        onClick={() => setLyricsAutoScrollEnabled(!lyricsAutoScrollEnabled)}
                        className={`w-7 h-4 rounded-full p-0.5 transition-all ${lyricsAutoScrollEnabled ? "bg-cyan-400" : "bg-neutral-800"}`}
                      >
                        <div className={`w-3 h-3 rounded-full bg-white transition-all ${lyricsAutoScrollEnabled ? 'translate-x-3.5' : 'translate-x-0'}`} />
                      </button>
                    </div>

                    {/* 13. Configurar repetición A-B */}
                    <button
                      onClick={() => {
                        playSynthBeep(450, 0.05);
                        setAbRepeat({ a: Math.max(0, currentTime - 5), b: Math.min(currentTrack.durationSec, currentTime + 5) });
                        showToast("Bucle rápido de 10s fijado");
                        setIsLyricsSettingsOpen(false);
                      }}
                      className="w-full text-center py-1 bg-white/5 hover:bg-white/10 text-cyan-400 border border-white/5 text-[9.5px] font-bold rounded"
                    >
                      13. Bucle rápido 10s aquí
                    </button>

                    {/* 14. Compartir Letra */}
                    <button
                      onClick={() => {
                        playSynthBeep(500, 0.05);
                        const lines = customLyricsMap[currentTrack.title] || currentTrack.lyrics;
                        const activeLine = lines[activeLyricsIndex] || "Rolita del alma";
                        const shareTxt = `🎸 Fragmento de "${currentTrack.title}" (${currentTrack.artist}):\n\n"${activeLine}"\n\nCompartido desde ¿Unas Rolitas?`;
                        setLyricsModalType("share");
                        setLyricsModalTitle("Compartir Fragmento");
                        setLyricsModalContent(shareTxt);
                        setIsLyricsModalOpen(true);
                        setIsLyricsSettingsOpen(false);
                      }}
                      className="w-full text-center py-1 bg-[#FF007F]/10 hover:bg-[#FF007F]/20 text-[#FF007F] font-black rounded"
                    >
                      14. Compartir Fragmento
                    </button>

                    {/* 15. Copiar Letra */}
                    <button
                      onClick={() => {
                        playSynthBeep(520, 0.05);
                        const lines = customLyricsMap[currentTrack.title] || currentTrack.lyrics;
                        const fullTxt = lines.join("\n");
                        setLyricsModalType("copy");
                        setLyricsModalTitle("Letra Completa");
                        setLyricsModalContent(fullTxt);
                        navigator.clipboard?.writeText(fullTxt);
                        showToast("Letra copiada al portapapeles!");
                        setIsLyricsModalOpen(true);
                        setIsLyricsSettingsOpen(false);
                      }}
                      className="w-full text-center py-1 bg-white/5 hover:bg-white/10 text-gray-300 font-bold rounded"
                    >
                      15. Copiar Letra Completa
                    </button>

                    {/* 16. Fuente de información */}
                    <div className="border-t border-white/5 pt-1 text-[8.5px] text-gray-500 text-center leading-tight">
                      16. Líricas oficiales proveídas por MusixMatch para "¿Unas Rolitas?" S.A. 2026.
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Interactive scrolling lyrics content */}
          <div 
            ref={lyricsContainerRef}
            className={`flex-1 overflow-y-auto px-4 py-8 space-y-6 scrollbar-none rounded-2xl relative transition-all duration-500 shadow-inner ${
              lyricsTheme === "neon" ? "bg-black/60 border border-white/5" :
              lyricsTheme === "classic" ? "bg-slate-950/80 border border-slate-900" :
              lyricsTheme === "warm" ? "bg-[#fdf6e3]/60 border border-[#eee8d5]" :
              "bg-black border border-neutral-900"
            }`}
          >
            {(customLyricsMap[currentTrack.title] || currentTrack.lyrics).map((line, idx) => {
              const isActive = idx === activeLyricsIndex;
              const alignmentClass = 
                lyricsAlignment === "left" ? "text-left" :
                lyricsAlignment === "right" ? "text-right" : "text-center";

              const sizeClass =
                lyricsTextSize === "sm" ? "text-[11px]" :
                lyricsTextSize === "md" ? "text-xs sm:text-sm" :
                lyricsTextSize === "lg" ? "text-sm sm:text-base font-medium" :
                "text-base sm:text-lg font-bold";

              return (
                <div
                  id={`lyric-line-${idx}`}
                  key={idx}
                  onClick={() => {
                    playSynthBeep(450 + (idx * 15), 0.05);
                    const linesCount = (customLyricsMap[currentTrack.title] || currentTrack.lyrics).length;
                    const targetSec = Math.floor((idx / linesCount) * currentTrack.durationSec);
                    setCurrentTime(targetSec);
                  }}
                  className={`py-1 rounded-xl transition-all duration-300 cursor-pointer ${alignmentClass} ${
                    isActive 
                      ? (lyricsKaraokeEnabled
                          ? "text-cyan-400 font-extrabold filter drop-shadow-[0_0_10px_rgba(0,229,255,0.7)] scale-105"
                          : "text-white font-extrabold scale-105")
                      : (lyricsTheme === "warm" ? "text-[#93a1a1] hover:text-[#586e75]" : "text-gray-500 hover:text-gray-300")
                  }`}
                >
                  <p className={`${sizeClass} leading-relaxed`}>
                    {line}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Manual offset tuner at bottom */}
          <div className="mt-2 bg-black/50 p-2 rounded-xl border border-white/5 flex items-center justify-between shrink-0 text-[10px] font-bold z-10">
            <span className="text-gray-400 flex items-center gap-1">
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              Sincronización manual: {lyricsSyncOffset > 0 ? `+${lyricsSyncOffset.toFixed(1)}s` : `${lyricsSyncOffset.toFixed(1)}s`}
            </span>
            <div className="flex gap-1">
              <button 
                onClick={() => { setLyricsSyncOffset(lyricsSyncOffset - 0.5); playSynthBeep(420, 0.03); }}
                className="px-2 py-0.5 bg-neutral-900 rounded text-cyan-400 border border-white/5"
              >
                Adelantar
              </button>
              <button 
                onClick={() => { setLyricsSyncOffset(lyricsSyncOffset + 0.5); playSynthBeep(420, 0.03); }}
                className="px-2 py-0.5 bg-neutral-900 rounded text-cyan-400 border border-white/5"
              >
                Atrasar
              </button>
              <button 
                onClick={() => { setLyricsSyncOffset(0); playSynthBeep(300, 0.03); }}
                className="px-2 py-0.5 bg-neutral-900 rounded text-gray-400 border border-white/5"
              >
                Reset
              </button>
            </div>
          </div>

          {/* Special overlay lyrics dialogs */}
          {isLyricsModalOpen && (
            <div className="absolute inset-0 bg-black/90 backdrop-blur-sm z-50 flex flex-col justify-center p-6 space-y-4">
              <div className="bg-[#0c111e] border border-white/10 rounded-2xl p-5 space-y-3 shadow-2xl flex flex-col max-h-[85%] text-white">
                <h4 className="text-xs font-black tracking-wider text-cyan-400 uppercase">{lyricsModalTitle}</h4>
                
                {lyricsModalType === "import" ? (
                  <div className="space-y-3 flex-1 flex flex-col min-h-0">
                    <p className="text-[10px] text-gray-400">Pega las líneas LRC o líricas separadas por saltos de línea:</p>
                    <textarea
                      value={lyricsImportInput}
                      onChange={(e) => setLyricsImportInput(e.target.value)}
                      placeholder="Ejemplo:&#10;[00:10.00] Primera línea de la rola&#10;[00:14.00] Segunda línea de la rola"
                      className="flex-1 bg-black/60 border border-white/10 rounded-xl p-3 text-xs text-white placeholder-gray-500 outline-none focus:border-cyan-400 resize-none font-mono"
                    />
                    <div className="flex gap-2 justify-end shrink-0 pt-1">
                      <button 
                        onClick={() => {
                          playSynthBeep(350, 0.05);
                          setIsLyricsModalOpen(false);
                          setLyricsImportInput("");
                        }}
                        className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-[10px] font-bold text-gray-400 transition-all"
                      >
                        CANCELAR
                      </button>
                      <button 
                        onClick={() => {
                          playSynthBeep(650, 0.08);
                          const cleanLines = lyricsImportInput.split(/[,\n]/).map(l => l.replace(/\[\d+:\d+\.\d+\]/, "").trim()).filter(Boolean);
                          if (cleanLines.length > 0) {
                            setCustomLyricsMap({
                              ...customLyricsMap,
                              [currentTrack.title]: cleanLines
                            });
                            showToast("LRC importado con éxito");
                            setIsLyricsModalOpen(false);
                            setLyricsImportInput("");
                          } else {
                            showToast("No se encontraron líneas válidas");
                          }
                        }}
                        className="px-4 py-2 rounded-xl bg-cyan-400 text-black hover:bg-cyan-300 text-[10px] font-black transition-all"
                      >
                        IMPORTAR
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3 flex-1 flex flex-col min-h-0">
                    <textarea
                      value={lyricsModalContent}
                      readOnly
                      className="flex-1 bg-black/60 border border-white/10 rounded-xl p-3 text-xs text-white outline-none font-mono resize-none"
                    />
                    <div className="flex gap-2 justify-end shrink-0 pt-1">
                      <button 
                        onClick={() => {
                          playSynthBeep(520, 0.05);
                          navigator.clipboard?.writeText(lyricsModalContent);
                          showToast("Copiado!");
                        }}
                        className="px-4 py-2 rounded-xl bg-cyan-400 text-black hover:bg-cyan-300 text-[10px] font-black transition-all"
                      >
                        COPIAR TEXTO
                      </button>
                      <button 
                        onClick={() => {
                          playSynthBeep(350, 0.05);
                          setIsLyricsModalOpen(false);
                        }}
                        className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-[10px] font-bold text-gray-400 transition-all"
                      >
                        CERRAR
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

        </div>
      )}

    </motion.div>
  );
};

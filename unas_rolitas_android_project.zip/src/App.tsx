import React, { useState, useEffect, useRef } from "react";
import { 
  Folder, 
  File, 
  Terminal, 
  Play, 
  Pause, 
  SkipForward, 
  SkipBack, 
  Download, 
  Check, 
  Copy, 
  Search, 
  Music, 
  ListMusic, 
  Heart, 
  Settings, 
  Volume2, 
  Sliders, 
  Bluetooth, 
  ShieldAlert, 
  Layers, 
  ChevronRight, 
  RefreshCw,
  Info,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Smartphone,
  SlidersHorizontal,
  FileMusic,
  Radio,
  Clock,
  Battery,
  Wifi,
  VolumeX,
  Volume1,
  RotateCw,
  HelpCircle,
  Menu,
  MoreVertical,
  ListPlus,
  Plus,
  Trash2,
  Moon,
  Sun,
  X,
  Activity,
  EyeOff,
  Ban,
  Share2,
  FileAudio,
  Compass,
  User,
  FileText,
  Shuffle,
  ArrowLeft,
  Disc,
  Timer,
  Globe,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Zap,
  Repeat,
  Repeat1,
  Edit,
  Calendar,
  HardDrive,
  FolderOpen,
  PenTool,
  Move,
  CheckCircle,
  Image,
  Tag
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import JSZip from "jszip";
import { androidFiles, CodeFile } from "./data/androidFiles";
import { FullPlayer } from "./components/FullPlayer";

// Interfaces
interface Track {
  title: string;
  artist: string;
  album: string;
  duration: string;
  durationSec: number;
  genre: string;
  size: string;
  lyrics: string[];
  composer?: string;
  year?: string;
  plays?: number;
  dateAdded?: string;
  folder?: string;
}

const simulatedTracks: Track[] = [
  {
    title: "Luna de Octubre",
    artist: "Los Bohemios",
    album: "Cielos de Otoño",
    duration: "3:42",
    durationSec: 222,
    genre: "Bolero Neón",
    size: "8.5 MB",
    composer: "José Alfredo",
    year: "1954",
    plays: 142,
    dateAdded: "2026-05-12",
    folder: "/storage/Music/Descargas",
    lyrics: [
      "De las lunas, la de octubre es la más bella...",
      "Porque en ella se refleja tu mirar...",
      "Bajo el manto de la noche y las estrellas...",
      "Juro que nunca te dejaré de amar...",
      "Y la brisa nos susurra con ternura...",
      "Que este amor nunca tendrá un final..."
    ]
  },
  {
    title: "Ecos del Silencio",
    artist: "Elena Ríos",
    album: "Raíces",
    duration: "4:15",
    durationSec: 255,
    genre: "Folk Fusión",
    size: "9.8 MB",
    composer: "Elena Ríos",
    year: "2021",
    plays: 87,
    dateAdded: "2026-06-01",
    folder: "/storage/Music/Clásicos",
    lyrics: [
      "En el silencio de mi alcoba te recuerdo...",
      "Y los ecos de tu voz vuelven a mí...",
      "Como un dulce susurro que se pierde...",
      "En la nostalgia de lo que ayer viví...",
      "La guitarra llora lento en el camino...",
      "Esperando que regreses junto a mí..."
    ]
  },
  {
    title: "Atardecer",
    artist: "Mar de Cristal",
    album: "Horizonte",
    duration: "2:58",
    durationSec: 178,
    genre: "Indie Pop",
    size: "6.8 MB",
    composer: "Carlos G.",
    year: "2023",
    plays: 198,
    dateAdded: "2026-06-15",
    folder: "/storage/Music/Descargas",
    lyrics: [
      "El sol se oculta tras el mar de cristal...",
      "Pintando el cielo de fuego y coral...",
      "Y yo me quedo pensando en tu sonrisa...",
      "Mientras me arrulla la suave brisa...",
      "Un momento eterno suspendido en el tiempo...",
      "Donde el destino se vuelve casual..."
    ]
  },
  {
    title: "Vuelo Libre",
    artist: "Daniel Peralta",
    album: "Alas de Papel",
    duration: "5:04",
    durationSec: 304,
    genre: "Electro Acústico",
    size: "11.6 MB",
    composer: "Daniel Peralta",
    year: "2020",
    plays: 53,
    dateAdded: "2026-07-02",
    folder: "/storage/Music/Descargas",
    lyrics: [
      "Abro mis alas al viento del destino...",
      "Sin mirar atrás, forjando mi camino...",
      "La libertad se siente tan real y pura...",
      "Volando alto en esta gran aventura...",
      "Nuevas alturas, sin miedo a caer...",
      "La vida empieza al amanecer..."
    ]
  },
  {
    title: "Ritmo Urbano",
    artist: "Zoe & Co.",
    album: "Calles de Oro",
    duration: "3:20",
    durationSec: 200,
    genre: "Urbano Alternativo",
    size: "7.7 MB",
    composer: "Zoe & Co.",
    year: "2024",
    plays: 124,
    dateAdded: "2026-07-10",
    folder: "/storage/Music/Clásicos",
    lyrics: [
      "Las luces de la ciudad se encienden hoy...",
      "Sintiendo el ritmo en cada paso a donde voy...",
      "El bajo suena profundo en el asfalto...",
      "Llevando mis pensamientos a lo alto...",
      "Esquivando sombras bajo el farol...",
      "Hasta que vuelva a salir el sol..."
    ]
  }
];

const lyricsTranslations: { [songTitle: string]: string[] } = {
  "Luna de Octubre": [
    "Of all the moons, the one in October is the most beautiful...",
    "Because in it, your gaze is reflected...",
    "Under the blanket of the night and the stars...",
    "I swear that I will never stop loving you...",
    "And the breeze whispers to us with tenderness...",
    "That this love will never have an end..."
  ],
  "Ecos del Silencio": [
    "In the silence of my bedroom I remember you...",
    "And the echoes of your voice return to me...",
    "Like a sweet whisper that gets lost...",
    "In the nostalgia of what I lived yesterday...",
    "The guitar cries slowly on the path...",
    "Waiting for you to return to my side..."
  ],
  "Atardecer": [
    "The sun hides behind the glass sea...",
    "Painting the sky with fire and coral...",
    "And I stay here thinking of your smile...",
    "While the soft breeze lulls me...",
    "An eternal moment suspended in time...",
    "Where destiny becomes casual..."
  ],
  "Vuelo Libre": [
    "I open my wings to the wind of destiny...",
    "Without looking back, forging my path...",
    "Freedom feels so real and pure...",
    "Flying high in this great adventure...",
    "New heights, without fear of falling...",
    "Life begins at dawn..."
  ],
  "Ritmo Urbano": [
    "The city lights turn on today...",
    "Feeling the rhythm in every step where I go...",
    "The bass sounds deep on the asphalt...",
    "Carrying my thoughts to the top...",
    "Dodging shadows under the streetlamp...",
    "Until the sun rises again..."
  ]
};

const getTrackColors = (track: any) => {
  if (!track) return { bg: "from-cyan-950 via-slate-950 to-black", glow: "#00E5FF", text: "text-cyan-400" };
  
  // Custom coverColor mappings
  if (track.coverColor) {
    switch (track.coverColor) {
      case "violeta":
        return { bg: "from-purple-950/40 via-neutral-950 to-neutral-950", glow: "#a855f7", text: "text-purple-400" };
      case "esmeralda":
        return { bg: "from-emerald-950/40 via-neutral-950 to-neutral-950", glow: "#10b981", text: "text-emerald-400" };
      case "dorado":
        return { bg: "from-yellow-950/40 via-neutral-950 to-neutral-950", glow: "#eab308", text: "text-yellow-400" };
      case "cian":
        return { bg: "from-cyan-950/40 via-neutral-950 to-neutral-950", glow: "#06b6d4", text: "text-cyan-400" };
      case "rosa":
        return { bg: "from-pink-950/40 via-neutral-950 to-neutral-950", glow: "#ec4899", text: "text-pink-400" };
      case "coral":
        return { bg: "from-orange-950/40 via-neutral-950 to-neutral-950", glow: "#f97316", text: "text-orange-400" };
      case "ambar":
        return { bg: "from-amber-950/40 via-neutral-950 to-neutral-950", glow: "#f59e0b", text: "text-amber-400" };
    }
  }

  switch (track.title) {
    case "Luna de Octubre":
      return { bg: "from-amber-950/40 via-neutral-950 to-neutral-950", glow: "#f59e0b", text: "text-amber-400" };
    case "Ecos del Silencio":
      return { bg: "from-teal-950/40 via-neutral-950 to-neutral-950", glow: "#14b8a6", text: "text-teal-400" };
    case "Atardecer":
      return { bg: "from-rose-950/40 via-neutral-950 to-neutral-950", glow: "#f43f5e", text: "text-rose-400" };
    case "Vuelo Libre":
      return { bg: "from-cyan-950/40 via-neutral-950 to-neutral-950", glow: "#06b6d4", text: "text-cyan-400" };
    case "Ritmo Urbano":
      return { bg: "from-fuchsia-950/40 via-neutral-950 to-neutral-950", glow: "#d946ef", text: "text-fuchsia-400" };
    default:
      return { bg: "from-blue-950/40 via-neutral-950 to-neutral-950", glow: "#3b82f6", text: "text-blue-400" };
  }
};

export default function App() {
  const [activeTab, setActiveTab] = useState<"reproductor" | "files" | "termux" | "specs">("reproductor");
  const [selectedFile, setSelectedFile] = useState<string>("app/src/main/java/com/unasrolitas/app/ui/MainScreen.kt");
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [isZipping, setIsZipping] = useState(false);
  const [loadedAndroidFiles, setLoadedAndroidFiles] = useState<CodeFile[]>(androidFiles);

  // Simulated Mobile App state
  const [mobileTab, setMobileTab] = useState<"biblioteca" | "buscar" | "ajustes">("biblioteca");
  const [searchQuery, setSearchQuery] = useState("");
  const [tracks, setTracks] = useState<Track[]>(simulatedTracks);
  const [playbackQueue, setPlaybackQueue] = useState<Track[]>(simulatedTracks);
  const [currentQueueIndex, setCurrentQueueIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(42); // in seconds
  const [isFullPlayerExpanded, setIsFullPlayerExpanded] = useState(false);
  const [fullPlayerSubTab, setFullPlayerSubTab] = useState<"reproductor" | "cola" | "letras">("reproductor");
  const [shuffleOn, setShuffleOn] = useState(false);
  const [repeatMode, setRepeatMode] = useState<"none" | "one" | "all">("all");

  const currentTrackIndex = currentQueueIndex; // Alias for compatibility

  // Advanced reproducer states
  const [playerViewMode, setPlayerViewMode] = useState<"cover" | "visualizer">("cover");
  const [visualizerStyle, setVisualizerStyle] = useState<"barras" | "espectro" | "ondas" | "particulas" | "lineas" | "luces">("barras");
  const [isQuickActionsExpanded, setIsQuickActionsExpanded] = useState(false);
  const [playbackVolume, setPlaybackVolume] = useState(80);
  const [sleepTimer, setSleepTimer] = useState<number | null>(null);
  const [sleepTimerPreset, setSleepTimerPreset] = useState<"Off" | "5m" | "15m" | "30m" | "60m">("Off");
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [abRepeat, setAbRepeat] = useState<{ a: number | null; b: number | null }>({ a: null, b: null });
  const [timeFormatLeft, setTimeFormatLeft] = useState<"elapsed" | "remaining" | "total">("elapsed");
  const [timeFormatRight, setTimeFormatRight] = useState<"elapsed" | "remaining" | "total">("remaining");

  // Lyrics advanced states
  const [lyricsSearchQuery, setLyricsSearchQuery] = useState("");
  const [isLyricsSearching, setIsLyricsSearching] = useState(false);
  const [lyricsSyncOffset, setLyricsSyncOffset] = useState<number>(0);
  const [lyricsTranslationEnabled, setLyricsTranslationEnabled] = useState(false);
  const [lyricsTextSize, setLyricsTextSize] = useState<"sm" | "md" | "lg" | "xl">("md");
  const [lyricsAlignment, setLyricsAlignment] = useState<"left" | "center" | "right">("center");
  const [lyricsTheme, setLyricsTheme] = useState<"neon" | "classic" | "warm" | "dark">("neon");
  const [lyricsKaraokeEnabled, setLyricsKaraokeEnabled] = useState(true);
  const [lyricsAutoScrollEnabled, setLyricsAutoScrollEnabled] = useState(true);
  const [isLyricsSettingsOpen, setIsLyricsSettingsOpen] = useState(false);
  const [customLyricsMap, setCustomLyricsMap] = useState<{ [songTitle: string]: string[] }>({});

  const [isSaveQueueModalOpen, setIsSaveQueueModalOpen] = useState(false);
  const [isLoadQueueModalOpen, setIsLoadQueueModalOpen] = useState(false);
  const [newPlaylistNameInput, setNewPlaylistNameInput] = useState("");

  const [isLyricsModalOpen, setIsLyricsModalOpen] = useState(false);
  const [lyricsModalTitle, setLyricsModalTitle] = useState("");
  const [lyricsModalContent, setLyricsModalContent] = useState("");
  const [lyricsModalType, setLyricsModalType] = useState<"import" | "export" | "share" | "copy">("import");
  const [lyricsImportInput, setLyricsImportInput] = useState("");
  
  // Redesign state parameters
  const [blacklistedSongs, setBlacklistedSongs] = useState<string[]>([]);
  const [hiddenSongs, setHiddenSongs] = useState<string[]>([]);
  const [playlists, setPlaylists] = useState<{ [name: string]: string[] }>({
    "Favoritas": ["Luna de Octubre", "Atardecer"],
    "Sabor Latino": ["Luna de Octubre"],
    "Para Programar": ["Vuelo Libre", "Atardecer"],
    "Viaje Nocturno": ["Ritmo Urbano", "Ecos del Silencio"]
  });
  const [libraryTab, setLibraryTab] = useState<string>("canciones");
  const [activePlaylistName, setActivePlaylistName] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<string>("titulo_az");
  const [isSortDropdownOpen, setIsSortDropdownOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [activeOptionsTrack, setActiveOptionsTrack] = useState<Track | null>(null);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const [isMobileLightMode, setIsMobileLightMode] = useState(false);
  
  // Drag and drop queue state
  const [draggedQueueIndex, setDraggedQueueIndex] = useState<number | null>(null);
  
  // Settings Control Center State variables
  const [activeSettingsCategory, setActiveSettingsCategory] = useState<string | null>(null);
  const [volumeAmpEnabled, setVolumeAmpEnabled] = useState(false);
  const [gaplessEnabled, setGaplessEnabled] = useState(true);
  const [autoLyricsEnabled, setAutoLyricsEnabled] = useState(true);
  const [autoLibraryScan, setAutoLibraryScan] = useState(false);
  const [autoMetadataSearch, setAutoMetadataSearch] = useState(true);
  
  // B. Reproducción
  const [resumePlayAuto, setResumePlayAuto] = useState(true);
  const [rememberPlayPos, setRememberPlayPos] = useState(true);
  const [replayGainEnabled, setReplayGainEnabled] = useState(false);
  const [audioBalance, setAudioBalance] = useState(0); // -10 (izquierda) to 10 (derecha)
  const [audioMono, setAudioMono] = useState(false);
  const [pitchAdjust, setPitchAdjust] = useState(0); // -5 to 5
  const [pauseOnBluetoothDisconnect, setPauseOnBluetoothDisconnect] = useState(true);
  const [resumeOnHeadphonesConnect, setResumeOnHeadphonesConnect] = useState(false);
  
  // C. Audio
  const [eqParametricEnabled, setEqParametricEnabled] = useState(false);
  const [bassBoostLevel, setBassBoostLevel] = useState(30);
  const [virtualizerLevel, setVirtualizerLevel] = useState(0);
  const [surround3D, setSurround3D] = useState(false);
  const [reverbPreset, setReverbPreset] = useState("Ninguno");
  const [limiterEnabled, setLimiterEnabled] = useState(false);
  const [dynamicCompressor, setDynamicCompressor] = useState(false);
  const [crossfeedHeadphones, setCrossfeedHeadphones] = useState(false);
  const [hiResOutput, setHiResOutput] = useState(true);
  const [sampleRate, setSampleRate] = useState("96 kHz");
  const [bitDepth, setBitDepth] = useState("24-bit");
  const [savedPresets, setSavedPresets] = useState<string[]>(["Mi Perfil Ultra", "Electro-Glow", "Acústico Suave"]);
  const [newPresetInput, setNewPresetInput] = useState("");
  
  // D. Apariencia
  const [appThemeMode, setAppThemeMode] = useState<"claro" | "oscuro" | "automatico">("oscuro");
  const [selectedMainColor, setSelectedMainColor] = useState("cyan");
  const [materialDesignEnabled, setMaterialDesignEnabled] = useState(true);
  const [transparenciesEnabled, setTransparenciesEnabled] = useState(true);
  const [dynamicBackground, setDynamicBackground] = useState(true);
  const [animationsEnabled, setAnimationsEnabled] = useState(true);
  const [uiFontSize, setUiFontSize] = useState("Mediano");
  const [uiIconStyle, setUiIconStyle] = useState("Minimalista");
  const [coverArtShape, setCoverArtShape] = useState("Circular");
  const [playerStyle, setPlayerStyle] = useState("Premium");
  
  // E. Visualizador
  const [visualizerDefault, setVisualizerDefault] = useState("barras");
  const [visualizerFps, setVisualizerFps] = useState(60);
  const [visualizerSensitivity, setVisualizerSensitivity] = useState(80);
  const [visualizerSpeed, setVisualizerSpeed] = useState(50);
  const [visualizerColorPalette, setVisualizerColorPalette] = useState("Dinámico");
  const [visualizerIntensity, setVisualizerIntensity] = useState(75);
  const [visualizerParticles, setVisualizerParticles] = useState(true);
  const [visualizerQuality, setVisualizerQuality] = useState("Alta");
  
  // G. Metadatos
  const [metadataAutoDownloadCovers, setMetadataAutoDownloadCovers] = useState(true);
  const [metadataAutoRename, setMetadataAutoRename] = useState(false);
  const [metadataAutoOrganize, setMetadataAutoOrganize] = useState(false);
  
  // H. Herramientas de audio
  const [audioToolConvertFormat, setAudioToolConvertFormat] = useState("MP3");
  const [audioToolBitrate, setAudioToolBitrate] = useState("320 kbps");
  const [audioToolSampleRate, setAudioToolSampleRate] = useState("48 kHz");
  const [audioToolBitDepth, setAudioToolBitDepth] = useState("16-bit");
  const [audioToolChannels, setAudioToolChannels] = useState("Estéreo");
  const [audioToolNormalize, setAudioToolNormalize] = useState(true);

  // Backup state
  const [lastBackupTime, setLastBackupTime] = useState("Hace 2 días");
  const [isDeveloperMode, setIsDeveloperMode] = useState(false);
  const [excludeFolders, setExcludeFolders] = useState<string[]>(["/storage/Music/WhatsApp", "/storage/Music/Alarms"]);
  const [musicFolders, setMusicFolders] = useState<string[]>(["/storage/Music", "/storage/Downloads/Music"]);

  // Sub-features interactive state parameters
  const [libraryScanning, setLibraryScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanStepText, setScanStepText] = useState("");
  const [duplicatesFinderRunning, setDuplicatesFinderRunning] = useState(false);
  const [duplicateScanCompleted, setDuplicateScanCompleted] = useState(false);
  const [foundDuplicates, setFoundDuplicates] = useState<string[]>(["Atardecer (Duplicado).mp3", "Ritmo Urbano (Duplicado).mp3"]);

  const [selectedID3TrackTitle, setSelectedID3TrackTitle] = useState("");
  const [id3TitleInput, setId3TitleInput] = useState("");
  const [id3ArtistInput, setId3ArtistInput] = useState("");
  const [id3AlbumInput, setId3AlbumInput] = useState("");
  
  const [lyricsEditorTrackTitle, setLyricsEditorTrackTitle] = useState("");
  const [lyricsEditorContent, setLyricsEditorContent] = useState("");

  const [convertToolSourceTitle, setConvertToolSourceTitle] = useState("");
  const [convertToolRunning, setConvertToolRunning] = useState(false);
  const [convertToolProgress, setConvertToolProgress] = useState(0);
  const [convertToolStep, setConvertToolStep] = useState("");
  const [convertedTracksList, setConvertedTracksList] = useState<string[]>([]);

  const [trimToolSourceTitle, setTrimToolSourceTitle] = useState("");
  const [trimToolStartSec, setTrimToolStartSec] = useState(0);
  const [trimToolEndSec, setTrimToolEndSec] = useState(60);
  const [trimToolRunning, setTrimToolRunning] = useState(false);

  const [audioAnalysisTitle, setAudioAnalysisTitle] = useState("");
  const [audioAnalysisRunning, setAudioAnalysisRunning] = useState(false);
  const [audioAnalysisReport, setAudioAnalysisReport] = useState<any | null>(null);

  const [donationAmount, setDonationAmount] = useState("5.00");
  const [donationSuccess, setDonationSuccess] = useState(false);
  const [bugReportText, setBugReportText] = useState("");
  const [bugReportSuccess, setBugReportSuccess] = useState(false);
  const [suggestionText, setSuggestionText] = useState("");
  const [suggestionSuccess, setSuggestionSuccess] = useState(false);

  const [liveLogLines, setLiveLogLines] = useState<string[]>([
    "[" + new Date().toLocaleTimeString() + "] Audio Engine v2.4 initialized successfully.",
    "[" + new Date().toLocaleTimeString() + "] Connected to virtual Android device (Host: localhost:5555)",
    "[" + new Date().toLocaleTimeString() + "] Decoded 5 cover art images (cached: 100%)",
    "[" + new Date().toLocaleTimeString() + "] System CPU Load: 1.2% | Memory footprint: 42.5 MB"
  ]);

  const addLiveLog = (message: string) => {
    setLiveLogLines(prev => [
      `[${new Date().toLocaleTimeString()}] ${message}`,
      ...prev.slice(0, 15) // Keep last 16 records
    ]);
  };
  
  // Interactive mini utilities inside 3-dots
  const [editingField, setEditingField] = useState<{ fieldName: string; value: string } | null>(null);
  const [isConverting, setIsConverting] = useState(false);
  const [conversionProgress, setConversionProgress] = useState(0);
  const [conversionTarget, setConversionTarget] = useState<string>("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  // Custom Audio settings
  const [favoriteSongs, setFavoriteSongs] = useState<string[]>(["Luna de Octubre", "Atardecer"]);
  const [eqPreset, setEqPreset] = useState<"Clásico" | "Bass Boost" | "Vocal Boost" | "Plano" | "Personalizado">("Bass Boost");
  const [eqBands, setEqBands] = useState<number[]>([4, 8, 3, -1, 5]); // 60Hz, 230Hz, 910Hz, 4kHz, 14kHz
  const [audioQuality, setAudioQuality] = useState<"Alta (320kbps)" | "Estándar (192kbps)" | "Ahorro (96kbps)">("Alta (320kbps)");
  const [crossfade, setCrossfade] = useState(true);
  const [preampWarmth, setPreampWarmth] = useState(false);

  // Web Audio refs for Warmth Rumble and Crackle Simulation
  const audioCtxRef = useRef<AudioContext | null>(null);
  const humOscRef = useRef<OscillatorNode | null>(null);
  const humGainRef = useRef<GainNode | null>(null);
  const crackleNoiseRef = useRef<AudioWorkletNode | ScriptProcessorNode | null>(null);
  const crackleGainRef = useRef<GainNode | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const currentTrack = playbackQueue[currentQueueIndex] || simulatedTracks[0];

  // Format second timestamps (e.g. 1:45)
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? "0" : ""}${s}`;
  };

  const getFormattedTimeForLabel = (current: number, duration: number, format: "elapsed" | "remaining" | "total") => {
    if (format === "elapsed") {
      return formatTime(current);
    } else if (format === "remaining") {
      return "-" + formatTime(Math.max(0, duration - current));
    } else {
      return formatTime(duration);
    }
  };

  // Active highlighted lyrics index based on progress and sync offset
  const effectiveLyricsTime = Math.max(0, currentTime + lyricsSyncOffset);
  const activeLyricsIndex = Math.min(
    Math.floor((effectiveLyricsTime / currentTrack.durationSec) * currentTrack.lyrics.length),
    currentTrack.lyrics.length - 1
  );

  // Gesture state for album art / visualizer swipe
  const dragStartRef = useRef<{ x: number; y: number } | null>(null);

  const handleGestureStart = (clientX: number, clientY: number) => {
    dragStartRef.current = { x: clientX, y: clientY };
  };

  const handleGestureEnd = (clientX: number, clientY: number) => {
    if (!dragStartRef.current) return;
    const diffX = clientX - dragStartRef.current.x;
    const diffY = clientY - dragStartRef.current.y;
    dragStartRef.current = null;

    // Horizontal swipe threshold: 40px
    if (Math.abs(diffX) > Math.abs(diffY)) {
      if (Math.abs(diffX) > 40) {
        playSynthBeep(480, 0.04);
        setPlayerViewMode(prev => prev === "cover" ? "visualizer" : "cover");
        showToast(playerViewMode === "cover" ? "Modo: Visualizador de Audio" : "Modo: Carátula del Álbum");
      }
    } else {
      // Vertical swipe threshold: 40px
      if (Math.abs(diffY) > 40) {
        if (playerViewMode === "visualizer") {
          playSynthBeep(520, 0.04);
          const styles: typeof visualizerStyle[] = ["barras", "espectro", "ondas", "particulas", "lineas", "luces"];
          const idx = styles.indexOf(visualizerStyle);
          
          if (diffY > 0) {
            const prevIdx = (idx - 1 + styles.length) % styles.length;
            setVisualizerStyle(styles[prevIdx]);
            showToast(`Visualizador: ${styles[prevIdx].toUpperCase()}`);
          } else {
            const nextIdx = (idx + 1) % styles.length;
            setVisualizerStyle(styles[nextIdx]);
            showToast(`Visualizador: ${styles[nextIdx].toUpperCase()}`);
          }
        }
      }
    }
  };

  // Drag and drop queue handlers
  const handleQueueDragStart = (index: number) => {
    setDraggedQueueIndex(index);
    playSynthBeep(450, 0.03);
  };

  const handleQueueDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
  };

  const handleQueueDrop = (index: number) => {
    if (draggedQueueIndex === null) return;
    if (draggedQueueIndex === index) {
      setDraggedQueueIndex(null);
      return;
    }

    const updatedQueue = [...playbackQueue];
    const [draggedTrack] = updatedQueue.splice(draggedQueueIndex, 1);
    updatedQueue.splice(index, 0, draggedTrack);

    setPlaybackQueue(updatedQueue);
    
    if (currentQueueIndex === draggedQueueIndex) {
      setCurrentQueueIndex(index);
    } else if (currentQueueIndex > draggedQueueIndex && currentQueueIndex <= index) {
      setCurrentQueueIndex(currentQueueIndex - 1);
    } else if (currentQueueIndex < draggedQueueIndex && currentQueueIndex >= index) {
      setCurrentQueueIndex(currentQueueIndex + 1);
    }

    setDraggedQueueIndex(null);
    playSynthBeep(520, 0.05);
    showToast("Cola reordenada");
  };

  // Canvas Visualizer Effect
  useEffect(() => {
    let animationFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set correct retina scale
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    // Helper states for smooth animations
    let time = 0;
    const barCount = 32;
    const bars: number[] = Array(barCount).fill(0).map(() => Math.random() * 20);
    const targetBars: number[] = Array(barCount).fill(0);
    
    // For particles style
    const particleCount = 45;
    const particles = Array(particleCount).fill(0).map(() => ({
      x: width / 2,
      y: height / 2,
      angle: Math.random() * Math.PI * 2,
      speed: 0.5 + Math.random() * 2,
      size: 1 + Math.random() * 3,
      alpha: 0.2 + Math.random() * 0.8
    }));

    const render = () => {
      // Clear canvas with trail fade
      ctx.fillStyle = isMobileLightMode ? "rgba(245, 247, 250, 0.15)" : "rgba(4, 5, 8, 0.15)";
      ctx.fillRect(0, 0, width, height);

      time += isPlaying ? 0.05 : 0.01;

      const trackColors = getTrackColors(currentTrack);
      const glowColor = trackColors.glow;

      for (let i = 0; i < barCount; i++) {
        if (isPlaying) {
          const wave1 = Math.sin(time + i * 0.2) * 15;
          const wave2 = Math.cos(time * 0.7 - i * 0.4) * 10;
          const randomSpike = Math.random() > 0.95 ? Math.random() * 25 : 0;
          targetBars[i] = Math.max(5, 20 + wave1 + wave2 + randomSpike + (Math.sin(time * 2.3 + i * 0.5) * 12));
        } else {
          targetBars[i] = targetBars[i] * 0.92;
        }
        bars[i] += (targetBars[i] - bars[i]) * 0.15;
      }

      if (visualizerStyle === "barras") {
        const spacing = width / barCount;
        for (let i = 0; i < barCount; i++) {
          const barHeight = (bars[i] / 60) * (height * 0.65);
          const x = i * spacing + spacing / 4;
          const y = height - barHeight - 15;

          const grad = ctx.createLinearGradient(x, height - 15, x, y);
          grad.addColorStop(0, `${glowColor}11`);
          grad.addColorStop(0.5, `${glowColor}88`);
          grad.addColorStop(1, glowColor);

          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.roundRect(x, y, spacing / 2, barHeight, [4, 4, 0, 0]);
          ctx.fill();
        }
      } else if (visualizerStyle === "espectro") {
        const centerX = width / 2;
        const centerY = height / 2;
        const baseRadius = Math.min(width, height) * 0.22;
        const ringPulse = isPlaying ? Math.sin(time * 2) * 4 : 0;
        const radius = baseRadius + ringPulse;

        ctx.strokeStyle = `${glowColor}33`;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.stroke();

        for (let i = 0; i < barCount; i++) {
          const angle = (i / barCount) * Math.PI * 2 + (time * 0.1);
          const barHeight = (bars[i] / 60) * (Math.min(width, height) * 0.28);
          
          const startX = centerX + Math.cos(angle) * radius;
          const startY = centerY + Math.sin(angle) * radius;
          const endX = centerX + Math.cos(angle) * (radius + barHeight);
          const endY = centerY + Math.sin(angle) * (radius + barHeight);

          ctx.strokeStyle = glowColor;
          ctx.lineWidth = 2.5;
          ctx.lineCap = "round";
          ctx.beginPath();
          ctx.moveTo(startX, startY);
          ctx.lineTo(endX, endY);
          ctx.stroke();
        }
      } else if (visualizerStyle === "ondas") {
        ctx.lineWidth = 2;
        for (let w = 0; w < 3; w++) {
          ctx.strokeStyle = w === 0 ? glowColor : w === 1 ? `${glowColor}99` : `${glowColor}44`;
          ctx.beginPath();
          for (let x = 0; x < width; x += 3) {
            const indexFactor = x / width;
            const waveAmp = isPlaying ? (bars[Math.floor(indexFactor * barCount)] || 15) : 5;
            const phaseShift = time * (1.5 - w * 0.3) + w * Math.PI * 0.5;
            const freq = 0.015 + w * 0.005;
            const y = (height / 2) + Math.sin(x * freq + phaseShift) * waveAmp;

            if (x === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.stroke();
        }
      } else if (visualizerStyle === "particulas") {
        const centerX = width / 2;
        const centerY = height / 2;
        const avgBar = bars.reduce((a, b) => a + b, 0) / barCount;
        const speedMultiplier = isPlaying ? 1 + (avgBar / 20) : 0.2;

        particles.forEach((p) => {
          p.x += Math.cos(p.angle) * p.speed * speedMultiplier;
          p.y += Math.sin(p.angle) * p.speed * speedMultiplier;

          if (p.x < 0 || p.x > width || p.y < 0 || p.y > height) {
            p.x = centerX;
            p.y = centerY;
            p.angle = Math.random() * Math.PI * 2;
            p.speed = 0.5 + Math.random() * 2;
            p.size = 1 + Math.random() * 3;
            p.alpha = 0.2 + Math.random() * 0.8;
          }

          ctx.fillStyle = glowColor;
          ctx.globalAlpha = p.alpha;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (1 + (isPlaying ? avgBar / 35 : 0)), 0, Math.PI * 2);
          ctx.fill();
        });
        ctx.globalAlpha = 1.0;
      } else if (visualizerStyle === "lineas") {
        ctx.beginPath();
        ctx.moveTo(0, height);
        const spacing = width / (barCount - 1);
        for (let i = 0; i < barCount; i++) {
          const x = i * spacing;
          const barHeight = (bars[i] / 60) * (height * 0.45);
          const y = height - barHeight - 20;
          ctx.lineTo(x, y);
        }
        ctx.lineTo(width, height);
        ctx.closePath();

        const fillGrad = ctx.createLinearGradient(0, height / 2, 0, height);
        fillGrad.addColorStop(0, `${glowColor}33`);
        fillGrad.addColorStop(1, `${glowColor}00`);
        ctx.fillStyle = fillGrad;
        ctx.fill();

        ctx.beginPath();
        for (let i = 0; i < barCount; i++) {
          const x = i * spacing;
          const barHeight = (bars[i] / 60) * (height * 0.45);
          const y = height - barHeight - 20;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.strokeStyle = glowColor;
        ctx.lineWidth = 3;
        ctx.stroke();
      } else if (visualizerStyle === "luces") {
        const centerX = width / 2;
        const centerY = height / 2;
        const avgBar = bars.reduce((a, b) => a + b, 0) / barCount;
        const radius = Math.min(width, height) * 0.28 * (1 + (avgBar / 40));

        const lightGrad = ctx.createRadialGradient(centerX, centerY, 5, centerX, centerY, radius);
        lightGrad.addColorStop(0, `${glowColor}99`);
        lightGrad.addColorStop(0.3, `${glowColor}33`);
        lightGrad.addColorStop(0.7, `${glowColor}08`);
        lightGrad.addColorStop(1, "rgba(0,0,0,0)");

        ctx.fillStyle = lightGrad;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.fill();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [playerViewMode, visualizerStyle, isPlaying, currentTrack, isMobileLightMode]);

  const lyricsContainerRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll effect for active lyrics
  useEffect(() => {
    if (fullPlayerSubTab === "letras" && lyricsAutoScrollEnabled) {
      const activeEl = document.getElementById(`lyric-line-${activeLyricsIndex}`);
      if (activeEl && lyricsContainerRef.current) {
        lyricsContainerRef.current.scrollTo({
          top: activeEl.offsetTop - (lyricsContainerRef.current.clientHeight / 2) + (activeEl.clientHeight / 2),
          behavior: "smooth"
        });
      }
    }
  }, [activeLyricsIndex, fullPlayerSubTab, lyricsAutoScrollEnabled]);

  // Sleep timer ticker
  useEffect(() => {
    let interval: any;
    if (sleepTimer !== null && isPlaying) {
      interval = setInterval(() => {
        setSleepTimer((prev) => {
          if (prev === null) return null;
          if (prev <= 1) {
            setIsPlaying(false);
            setSleepTimerPreset("Off");
            playSynthBeep(250, 0.5);
            showToast("Temporizador: Apagado automático activado");
            return null;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [sleepTimer, isPlaying]);

  // Auto-progress simulated time when playing
  useEffect(() => {
    let timer: any;
    if (isPlaying) {
      timer = setInterval(() => {
        setCurrentTime((prev) => {
          if (abRepeat && abRepeat.a !== null && abRepeat.b !== null) {
            if (prev >= abRepeat.b) {
              return abRepeat.a;
            }
          }
          if (prev >= currentTrack.durationSec) {
            handleNextTrack();
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isPlaying, currentQueueIndex, abRepeat, currentTrack]);

  // Handle Track Skipping
  const handleNextTrack = () => {
    playSynthBeep(600, 0.08);
    if (playbackQueue.length === 0) return;
    
    let nextIndex = 0;
    if (repeatMode === "one") {
      nextIndex = currentQueueIndex;
    } else if (shuffleOn) {
      nextIndex = Math.floor(Math.random() * playbackQueue.length);
    } else {
      nextIndex = (currentQueueIndex + 1) % playbackQueue.length;
    }
    
    setCurrentQueueIndex(nextIndex);
    setCurrentTime(0);
  };

  const handlePrevTrack = () => {
    playSynthBeep(450, 0.08);
    if (playbackQueue.length === 0) return;
    
    let prevIndex = 0;
    if (shuffleOn) {
      prevIndex = Math.floor(Math.random() * playbackQueue.length);
    } else {
      prevIndex = (currentQueueIndex - 1 + playbackQueue.length) % playbackQueue.length;
    }
    
    setCurrentQueueIndex(prevIndex);
    setCurrentTime(0);
  };

  const playTrackFromLibrary = (track: Track, customContextList?: Track[]) => {
    const context = customContextList || getProcessedTracks();
    let contextWithTrack = [...context];
    if (!contextWithTrack.some(t => t.title === track.title)) {
      contextWithTrack = [track, ...contextWithTrack];
    }
    setPlaybackQueue(contextWithTrack);
    const idx = contextWithTrack.findIndex(t => t.title === track.title);
    setCurrentQueueIndex(idx !== -1 ? idx : 0);
    setCurrentTime(0);
    setIsPlaying(true);
    playSynthBeep(523, 0.05);
  };

  const moveQueueTrackUp = (index: number) => {
    if (index <= 0) return;
    const newQueue = [...playbackQueue];
    const temp = newQueue[index];
    newQueue[index] = newQueue[index - 1];
    newQueue[index - 1] = temp;
    setPlaybackQueue(newQueue);
    if (currentQueueIndex === index) {
      setCurrentQueueIndex(index - 1);
    } else if (currentQueueIndex === index - 1) {
      setCurrentQueueIndex(index);
    }
    playSynthBeep(450, 0.05);
  };

  const moveQueueTrackDown = (index: number) => {
    if (index >= playbackQueue.length - 1) return;
    const newQueue = [...playbackQueue];
    const temp = newQueue[index];
    newQueue[index] = newQueue[index + 1];
    newQueue[index + 1] = temp;
    setPlaybackQueue(newQueue);
    if (currentQueueIndex === index) {
      setCurrentQueueIndex(index + 1);
    } else if (currentQueueIndex === index + 1) {
      setCurrentQueueIndex(index);
    }
    playSynthBeep(450, 0.05);
  };

  const removeQueueTrack = (index: number) => {
    if (playbackQueue.length <= 1) {
      showToast("La cola no puede estar totalmente vacía");
      return;
    }
    const newQueue = playbackQueue.filter((_, idx) => idx !== index);
    setPlaybackQueue(newQueue);
    if (currentQueueIndex >= newQueue.length) {
      setCurrentQueueIndex(newQueue.length - 1);
    } else if (currentQueueIndex > index) {
      setCurrentQueueIndex(currentQueueIndex - 1);
    }
    playSynthBeep(300, 0.08);
    showToast("Canción eliminada de la cola");
  };

  const clearQueue = () => {
    setPlaybackQueue([currentTrack]);
    setCurrentQueueIndex(0);
    playSynthBeep(250, 0.1);
    showToast("Cola vaciada");
  };

  const handleSaveQueueToPlaylist = (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) {
      showToast("Ingresa un nombre de playlist válido");
      return;
    }
    const songTitles = playbackQueue.map(t => t.title);
    setPlaylists(prev => ({
      ...prev,
      [trimmed]: songTitles
    }));
    playSynthBeep(650, 0.1);
    showToast(`Cola guardada como playlist "${trimmed}"`);
    setIsSaveQueueModalOpen(false);
    setNewPlaylistNameInput("");
  };

  const loadPlaylistIntoQueue = (pName: string) => {
    const songTitles = playlists[pName];
    if (!songTitles || songTitles.length === 0) {
      showToast("La playlist está vacía");
      return;
    }
    const loadedTracks = songTitles.map(title => tracks.find(t => t.title === title)).filter(Boolean) as Track[];
    if (loadedTracks.length === 0) return;
    setPlaybackQueue(loadedTracks);
    setCurrentQueueIndex(0);
    setCurrentTime(0);
    setIsPlaying(true);
    playSynthBeep(600, 0.08);
    showToast(`Playlist "${pName}" cargada en la cola`);
  };

  const shuffleQueue = () => {
    if (playbackQueue.length <= 1) return;
    const current = playbackQueue[currentQueueIndex];
    const others = playbackQueue.filter((_, idx) => idx !== currentQueueIndex);
    for (let i = others.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [others[i], others[j]] = [others[j], others[i]];
    }
    const shuffled = [current, ...others];
    setPlaybackQueue(shuffled);
    setCurrentQueueIndex(0);
    playSynthBeep(550, 0.08);
    showToast("Cola aleatorizada");
  };

  // Toggle Favorite
  const toggleFavorite = (title: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    playSynthBeep(700, 0.05);
    setFavoriteSongs((prev) =>
      prev.includes(title) ? prev.filter((t) => t !== title) : [...prev, title]
    );
  };

  // Sort/Filter Songs based on search query, library tab, and blacklist
  const getProcessedTracks = () => {
    let list = tracks.filter(t => !blacklistedSongs.includes(t.title) && !hiddenSongs.includes(t.title));

    // Search query matches title, artist, or album
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(t => t.title.toLowerCase().includes(q) || t.artist.toLowerCase().includes(q) || t.album.toLowerCase().includes(q));
    } else {
      // Filter based on active tab
      switch (libraryTab) {
        case "favoritos":
          list = list.filter(t => favoriteSongs.includes(t.title));
          break;
        case "playlists":
          if (activePlaylistName && playlists[activePlaylistName]) {
            const playlistSongs = playlists[activePlaylistName];
            list = list.filter(t => playlistSongs.includes(t.title));
          }
          break;
        case "descargadas":
          // Even indices are simulated as downloaded
          list = list.filter((_, idx) => idx % 2 === 0);
          break;
        case "mas_reproducidas":
          // Sorted by plays (handled below in sort block)
          break;
        case "recientes":
          // Sorted by date (handled below in sort block)
          break;
        case "historial":
          // Mock history (e.g., Luna de Octubre and Atardecer)
          list = list.filter(t => t.title === "Luna de Octubre" || t.title === "Atardecer");
          break;
        default:
          break;
      }
    }

    // Apply sorting
    switch (sortBy) {
      case "titulo_az":
        list.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case "titulo_za":
        list.sort((a, b) => b.title.localeCompare(a.title));
        break;
      case "artista_az":
        list.sort((a, b) => a.artist.localeCompare(b.artist));
        break;
      case "artista_za":
        list.sort((a, b) => b.artist.localeCompare(a.artist));
        break;
      case "album_az":
        list.sort((a, b) => a.album.localeCompare(b.album));
        break;
      case "album_za":
        list.sort((a, b) => b.album.localeCompare(a.album));
        break;
      case "genero":
        list.sort((a, b) => a.genre.localeCompare(b.genre));
        break;
      case "duracion_corta":
        list.sort((a, b) => a.durationSec - b.durationSec);
        break;
      case "duracion_larga":
        list.sort((a, b) => b.durationSec - a.durationSec);
        break;
      case "tamano":
        list.sort((a, b) => parseFloat(a.size) - parseFloat(b.size));
        break;
      case "reproducciones":
        list.sort((a, b) => (b.plays || 0) - (a.plays || 0));
        break;
      case "fecha_reciente":
        list.sort((a, b) => (b.dateAdded || "").localeCompare(a.dateAdded || ""));
        break;
      case "fecha_antigua":
        list.sort((a, b) => (a.dateAdded || "").localeCompare(b.dateAdded || ""));
        break;
      default:
        break;
    }

    return list;
  };

  const filteredTracks = getProcessedTracks();

  // Handle Equalizer presets
  const applyEqPreset = (preset: typeof eqPreset) => {
    setEqPreset(preset);
    playSynthBeep(520, 0.1, "triangle");
    switch (preset) {
      case "Clásico":
        setEqBands([2, 1, -1, 2, 4]);
        break;
      case "Bass Boost":
        setEqBands([8, 6, 2, -1, 1]);
        break;
      case "Vocal Boost":
        setEqBands([-2, -1, 6, 4, 1]);
        break;
      case "Plano":
        setEqBands([0, 0, 0, 0, 0]);
        break;
    }
  };

  const handleEqBandChange = (index: number, val: number) => {
    const updated = [...eqBands];
    updated[index] = val;
    setEqBands(updated);
    setEqPreset("Personalizado");
    // Play a tailored synth beep representing the frequency band being adjusted
    const frequencies = [80, 250, 1000, 4000, 12000];
    playSynthBeep(frequencies[index], 0.1, "sine");
  };

  // Web Audio Preamp Warmth Generator (Low rumble and gentle record dust crackles)
  const initAudio = () => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      if (audioCtxRef.current.state === "suspended") {
        audioCtxRef.current.resume();
      }
    } catch (e) {
      console.error("Audio Context is not supported in this browser.", e);
    }
  };

  const playSynthBeep = (freq = 440, duration = 0.1, type: OscillatorType = "sine") => {
    try {
      initAudio();
      if (!audioCtxRef.current) return;
      
      const osc = audioCtxRef.current.createOscillator();
      const gainNode = audioCtxRef.current.createGain();
      
      osc.type = type;
      osc.frequency.setValueAtTime(freq, audioCtxRef.current.currentTime);
      
      gainNode.gain.setValueAtTime(0.08, audioCtxRef.current.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.0001, audioCtxRef.current.currentTime + duration);
      
      osc.connect(gainNode);
      gainNode.connect(audioCtxRef.current.destination);
      
      osc.start();
      osc.stop(audioCtxRef.current.currentTime + duration);
    } catch (e) {
      // Ignored if browser policy blocks Audio
    }
  };

  // Preamp Warmth Switch handler
  useEffect(() => {
    if (preampWarmth) {
      try {
        initAudio();
        const ctx = audioCtxRef.current;
        if (!ctx) return;

        // 1. Create analog low-frequency hum (55Hz and 110Hz harmonics)
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(55, ctx.currentTime);
        gain.gain.setValueAtTime(0, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.015, ctx.currentTime + 1.5); // soft fade in

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        humOscRef.current = osc;
        humGainRef.current = gain;

        // 2. Create dusty crackle pops using a procedural AudioBuffer
        const bufferSize = ctx.sampleRate * 2; // 2 seconds of dust loop
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        
        for (let i = 0; i < bufferSize; i++) {
          // Soft pink noise background
          data[i] = (Math.random() - 0.5) * 0.003;
          // Random tiny record crackles
          if (Math.random() < 0.00015) {
            const crackleStrength = 0.1 + Math.random() * 0.25;
            data[i] += (Math.random() > 0.5 ? 1 : -1) * crackleStrength;
          }
        }

        const bufferSource = ctx.createBufferSource();
        bufferSource.buffer = buffer;
        bufferSource.loop = true;

        const lowpass = ctx.createBiquadFilter();
        lowpass.type = "lowpass";
        lowpass.frequency.setValueAtTime(1400, ctx.currentTime);

        const crackleGain = ctx.createGain();
        crackleGain.gain.setValueAtTime(0, ctx.currentTime);
        crackleGain.gain.linearRampToValueAtTime(0.3, ctx.currentTime + 2.0); // slow fade in

        bufferSource.connect(lowpass);
        lowpass.connect(crackleGain);
        crackleGain.connect(ctx.destination);
        bufferSource.start();

        crackleNoiseRef.current = bufferSource as any;
        crackleGainRef.current = crackleGain;
      } catch (e) {
        console.error("Failed to initialize preamp warmth synth:", e);
      }
    } else {
      // Fade out and stop hum
      if (humGainRef.current && humOscRef.current) {
        try {
          const osc = humOscRef.current;
          const gain = humGainRef.current;
          const ctx = audioCtxRef.current;
          if (ctx) {
            gain.gain.setValueAtTime(gain.gain.value, ctx.currentTime);
            gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.5);
            setTimeout(() => {
              try { osc.stop(); } catch(e){}
            }, 600);
          }
        } catch(e){}
        humOscRef.current = null;
        humGainRef.current = null;
      }
      // Stop crackle dust
      if (crackleGainRef.current && crackleNoiseRef.current) {
        try {
          const source = crackleNoiseRef.current as any;
          const gain = crackleGainRef.current;
          const ctx = audioCtxRef.current;
          if (ctx) {
            gain.gain.setValueAtTime(gain.gain.value, ctx.currentTime);
            gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.5);
            setTimeout(() => {
              try { source.stop(); } catch(e){}
            }, 600);
          }
        } catch(e){}
        crackleNoiseRef.current = null;
        crackleGainRef.current = null;
      }
    }
  }, [preampWarmth]);

  // Clean up synth when App unmounts
  useEffect(() => {
    return () => {
      try {
        if (humOscRef.current) { humOscRef.current.stop(); }
        if (crackleNoiseRef.current) { (crackleNoiseRef.current as any).stop(); }
      } catch (e) {}
    };
  }, []);

  // Fetch dynamic, real-time Android project source files from disk on mount
  useEffect(() => {
    fetch("/api/android-files")
      .then((res) => {
        if (!res.ok) throw new Error("API error");
        return res.json();
      })
      .then((data) => {
        if (data.files && data.files.length > 0) {
          setLoadedAndroidFiles(data.files);
        }
      })
      .catch((err) => {
        console.warn("Could not load dynamic Android files, falling back to static:", err);
      });
  }, []);

  // Helper to copy text to clipboard
  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    playSynthBeep(880, 0.08); // high pitch UI feedback
    setTimeout(() => setCopiedText(null), 2000);
  };

  // Download Android Project as a real Gradle structured ZIP
  const downloadAndroidZip = async () => {
    setIsZipping(true);
    playSynthBeep(523.25, 0.1, "sine"); // C5 chime
    try {
      // Fetch direct high-fidelity backend ZIP download from disk as a Blob
      const response = await fetch("/api/download-zip");
      if (!response.ok) {
        throw new Error(`Server returned status ${response.status}`);
      }
      
      const contentType = response.headers.get("content-type");
      if (contentType && contentType.includes("text/html")) {
        throw new Error("Server returned an HTML file instead of a ZIP file (possibly routing fallback)");
      }
      
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "unas_rolitas_android_project.zip";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      // Success melody
      setTimeout(() => {
        playSynthBeep(659.25, 0.1, "sine"); // E5
        setTimeout(() => {
          playSynthBeep(783.99, 0.15, "sine"); // G5
        }, 100);
      }, 200);
    } catch (error) {
      console.warn("Error downloading backend ZIP, falling back to client-side zipping:", error);
      // Fallback to client-side zipping using loadedAndroidFiles
      try {
        const zip = new JSZip();
        loadedAndroidFiles.forEach((file) => {
          zip.file(file.path, file.content);
        });
        const blob = await zip.generateAsync({ type: "blob" });
        const url = URL.createObjectURL(blob);
        const fallbackLink = document.createElement("a");
        fallbackLink.href = url;
        fallbackLink.download = "unas_rolitas_android_project.zip";
        document.body.appendChild(fallbackLink);
        fallbackLink.click();
        document.body.removeChild(fallbackLink);
        URL.revokeObjectURL(url);
      } catch (fallbackError) {
        console.error("Error during fallback ZIP generation:", fallbackError);
      }
    } finally {
      setIsZipping(false);
    }
  };

  const currentFileData = loadedAndroidFiles.find((f) => f.path === selectedFile) || loadedAndroidFiles[5];

  const themeColorHex = 
    selectedMainColor === "cyan" ? "#00E5FF" : 
    selectedMainColor === "magenta" ? "#FF007F" : 
    selectedMainColor === "violet" ? "#8B5CF6" : 
    selectedMainColor === "emerald" ? "#10B981" : "#F59E0B";

  const themeColorText = 
    selectedMainColor === "cyan" ? "text-[#00E5FF]" : 
    selectedMainColor === "magenta" ? "text-[#FF007F]" : 
    selectedMainColor === "violet" ? "text-[#8B5CF6]" : 
    selectedMainColor === "emerald" ? "text-[#10B981]" : "text-[#F59E0B]";

  const themeColorBg = 
    selectedMainColor === "cyan" ? "bg-[#00E5FF]" : 
    selectedMainColor === "magenta" ? "bg-[#FF007F]" : 
    selectedMainColor === "violet" ? "bg-[#8B5CF6]" : 
    selectedMainColor === "emerald" ? "bg-[#10B981]" : "bg-[#F59E0B]";

  const themeColorBorder = 
    selectedMainColor === "cyan" ? "border-[#00E5FF]/20" : 
    selectedMainColor === "magenta" ? "border-[#FF007F]/20" : 
    selectedMainColor === "violet" ? "border-[#8B5CF6]/20" : 
    selectedMainColor === "emerald" ? "border-[#10B981]/20" : "border-[#F59E0B]/20";

  const quickActionsList = [
    {
      id: "dark_mode",
      name: "Modo oscuro",
      active: !isMobileLightMode,
      icon: Moon,
      onToggle: () => {
        playSynthBeep(450, 0.05);
        setIsMobileLightMode(!isMobileLightMode);
        showToast(!isMobileLightMode ? "Tema Oscuro activo" : "Tema Claro activo");
      }
    },
    {
      id: "volume_amp",
      name: "Amplificador",
      active: volumeAmpEnabled,
      icon: Volume2,
      onToggle: () => {
        playSynthBeep(480, 0.05);
        setVolumeAmpEnabled(!volumeAmpEnabled);
        showToast(!volumeAmpEnabled ? "Amplificador activado (+6dB)" : "Amplificador desactivado");
      }
    },
    {
      id: "eq",
      name: "Ecualizador",
      active: eqPreset !== "Plano",
      icon: Sliders,
      onToggle: () => {
        playSynthBeep(520, 0.05);
        const nextPreset = eqPreset === "Plano" ? "Bass Boost" : "Plano";
        applyEqPreset(nextPreset);
        showToast(nextPreset === "Plano" ? "Ecualizador desactivado" : `Ecualizador activado: ${nextPreset}`);
      }
    },
    {
      id: "gapless",
      name: "Gapless",
      active: gaplessEnabled,
      icon: Zap,
      onToggle: () => {
        playSynthBeep(550, 0.05);
        setGaplessEnabled(!gaplessEnabled);
        showToast(!gaplessEnabled ? "Gapless activado" : "Gapless desactivado");
      }
    },
    {
      id: "crossfade",
      name: "Crossfade",
      active: crossfade,
      icon: Shuffle,
      onToggle: () => {
        playSynthBeep(580, 0.05);
        setCrossfade(!crossfade);
        showToast(!crossfade ? "Crossfade activado (4s)" : "Crossfade desactivado");
      }
    },
    {
      id: "lyrics",
      name: "Letras Auto",
      active: autoLyricsEnabled,
      icon: FileText,
      onToggle: () => {
        playSynthBeep(610, 0.05);
        setAutoLyricsEnabled(!autoLyricsEnabled);
        showToast(!autoLyricsEnabled ? "Búsqueda de letras automática activa" : "Búsqueda de letras automática desactivada");
      }
    },
    {
      id: "scan",
      name: "Escaneo Auto",
      active: autoLibraryScan,
      icon: RefreshCw,
      onToggle: () => {
        playSynthBeep(640, 0.05);
        setAutoLibraryScan(!autoLibraryScan);
        showToast(!autoLibraryScan ? "Escaneo de biblioteca automático activo" : "Escaneo de biblioteca automático desactivado");
      }
    },
    {
      id: "metadata",
      name: "Metadatos Auto",
      active: autoMetadataSearch,
      icon: Search,
      onToggle: () => {
        playSynthBeep(670, 0.05);
        setAutoMetadataSearch(!autoMetadataSearch);
        showToast(!autoMetadataSearch ? "Búsqueda de metadatos automática activa" : "Búsqueda de metadatos automática desactivada");
      }
    }
  ];

  const settingsCategories = [
    { id: "biblioteca", name: "Biblioteca", desc: "Carpetas, escaneos, duplicados y lista negra", icon: Music, sum: `${tracks.length} canciones • 421 álbumes • 36 artistas` },
    { id: "reproduccion", name: "Reproducción", desc: "Crossfade, gapless, velocidades y Bluetooth", icon: Play, sum: `${crossfade ? 'Crossfade' : 'Fundido Off'} • ${gaplessEnabled ? 'Gapless' : 'Estándar'}` },
    { id: "audio", name: "Audio", desc: "Ecualizadores, Bass Boost, Hi-Res y salidas", icon: Sliders, sum: `EQ: ${eqPreset} • Bass Boost ${bassBoostLevel}% • Hi-Res` },
    { id: "apariencia", name: "Apariencia", desc: "Tema, colores principales y formas de carátulas", icon: Sparkles, sum: `Tema ${appThemeMode.toUpperCase()} • Color ${selectedMainColor.toUpperCase()}` },
    { id: "visualizador", name: "Visualizador", desc: "Estilos, sensibilidad, FPS y partículas", icon: Radio, sum: `Circular • ${visualizerFps} FPS • ${visualizerStyle}` },
    { id: "letras", name: "Letras", desc: "Karaoke, sincronización, traducción y LRC", icon: FileText, sum: "Español • Karaoke Activo • Sync LRC" },
    { id: "metadatos", name: "Metadatos", desc: "Editor de etiquetas ID3 y letras incrustadas", icon: Tag, sum: "Edición avanzada habilitada" },
    { id: "herramientas", name: "Herramientas de audio", desc: "Convertidor, recortador, analizador de espectro", icon: FileAudio, sum: "Conversión • Recorte • Procesamiento" },
    { id: "backup", name: "Copias de seguridad", desc: "Exportar/importar configuración y listas", icon: RotateCw, sum: `Último respaldo: ${lastBackupTime}` },
    { id: "avanzado", name: "Avanzado", desc: "Consola de registros, caché y rendimiento", icon: Terminal, sum: `Dev Mode ${isDeveloperMode ? 'ON' : 'OFF'}` },
    { id: "acerca", name: "Acerca de", desc: "Versión, licencias, donación y novedades", icon: HelpCircle, sum: "v2.4.0-premium • Licencia MIT" }
  ];

  return (
    <div className="min-h-screen bg-[#040508] text-gray-200 font-sans relative overflow-x-hidden select-none">
      {/* Soft color-wash background blur */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(0,229,255,0.06),transparent_45%)] pointer-events-none" />
      <div className="absolute top-1/2 left-1/4 w-[300px] h-[300px] rounded-full bg-[#FF007F]/[0.02] blur-[120px] pointer-events-none" />

      {/* Main Premium Web App Header */}
      <header className="border-b border-[#0f141f] bg-[#06080d]/90 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#00E5FF]/20 to-[#FF007F]/20 border border-[#00E5FF]/30 flex items-center justify-center shadow-[0_0_15px_rgba(0,229,255,0.1)]">
              <Music className="w-5 h-5 text-[#00E5FF] animate-pulse" />
            </div>
            <div>
              <h1 className="font-sans text-lg font-bold tracking-tight text-white flex items-center gap-2">
                ¿UNAS ROLITAS? 
                <span className="text-[9px] bg-cyan-950/60 text-[#00E5FF] border border-cyan-800/40 px-1.5 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider">
                  Android Native Code v2
                </span>
              </h1>
              <p className="text-[11px] text-gray-500 font-mono">Consola de Desarrollo e Interfaz de Simulación de Alta Fidelidad</p>
            </div>
          </div>

          {/* Navigation Controls */}
          <nav className="flex items-center gap-1 bg-[#090d15] border border-[#131926] p-1 rounded-xl">
            <button
              onClick={() => { playSynthBeep(440, 0.05); setActiveTab("reproductor"); }}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === "reproductor" 
                  ? "bg-gradient-to-r from-cyan-500/10 to-blue-500/10 text-[#00E5FF] border border-[#00E5FF]/30 shadow-[0_0_10px_rgba(0,229,255,0.05)]" 
                  : "text-gray-400 hover:text-white border border-transparent"
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Simulador Móvil</span>
            </button>
            
            <button
              onClick={() => { playSynthBeep(480, 0.05); setActiveTab("files"); }}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === "files" 
                  ? "bg-gradient-to-r from-cyan-500/10 to-blue-500/10 text-[#00E5FF] border border-[#00E5FF]/30" 
                  : "text-gray-400 hover:text-white border border-transparent"
              }`}
            >
              <Folder className="w-3.5 h-3.5" />
              <span>Código Gradle/Kotlin</span>
            </button>

            <button
              onClick={() => { playSynthBeep(520, 0.05); setActiveTab("termux"); }}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === "termux" 
                  ? "bg-gradient-to-r from-cyan-500/10 to-blue-500/10 text-[#00E5FF] border border-[#00E5FF]/30" 
                  : "text-gray-400 hover:text-white border border-transparent"
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Instalación Termux</span>
            </button>

            <button
              onClick={() => { playSynthBeep(560, 0.05); setActiveTab("specs"); }}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === "specs" 
                  ? "bg-gradient-to-r from-cyan-500/10 to-blue-500/10 text-[#00E5FF] border border-[#00E5FF]/30" 
                  : "text-gray-400 hover:text-white border border-transparent"
              }`}
            >
              <Info className="w-3.5 h-3.5" />
              <span>Ficha Técnica</span>
            </button>
          </nav>

          {/* Download & Source Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={downloadAndroidZip}
              disabled={isZipping}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                isZipping
                  ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 animate-pulse cursor-not-allowed"
                  : "bg-[#00E5FF] hover:bg-[#00c5db] text-black shadow-[0_4px_12px_rgba(0,229,255,0.2)] font-bold cursor-pointer"
              }`}
            >
              <Download className={`w-3.5 h-3.5 ${isZipping ? 'animate-spin' : ''}`} />
              <span>{isZipping ? "ZIP TRABAJANDO..." : "DESCARGAR ZIP COMPILABLE"}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Dashboard */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        
        {/* Status ticker line */}
        <div className="flex items-center justify-between mb-6 px-3 py-1.5 bg-[#06080d] border border-[#0f1420] rounded-xl text-[10px] font-mono text-gray-400">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00E5FF] animate-ping" />
            <span className="tracking-wide">COMPILADOR ANDROID CONFIGURADO CON PERMISOS DE ALMACENAMIENTO (SDK 34)</span>
          </div>
          <div className="hidden sm:flex items-center gap-4 text-gray-500">
            <span>MOTOR: EXOPLAYER JETPACK MEDIA3</span>
            <span>BASE DE DATOS: ROOM SQLITE NATIVA</span>
            <span>BLUETOOTH: MEDIASESSION COMPATIBLE</span>
          </div>
        </div>

        <AnimatePresence mode="wait">
          
          {/* TAB 1: COCKPIT / REPRODUCER (INTERACTIVE PHONE PREVIEW) */}
          {activeTab === "reproductor" && (
            <motion.div
              key="reproductor"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.18 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start"
            >
              
              {/* Left Column: Interactive Phone Mockup */}
              <div className="lg:col-span-5 flex justify-center">
                <div className="relative w-full max-w-[360px] aspect-[9/19.2] bg-black rounded-[48px] p-3.5 shadow-[0_25px_60px_rgba(0,0,0,0.8),0_0_50px_rgba(0,229,255,0.05)] border-4 border-[#121620] overflow-hidden group">
                  
                  {/* Dynamic Island / Bezel notch */}
                  <div className="absolute top-5 left-1/2 -translate-x-1/2 w-28 h-5 bg-black rounded-full z-40 flex items-center justify-center gap-1">
                    <div className="w-2 h-2 rounded-full bg-blue-950/80 border border-blue-900/40" />
                    <div className="w-6 h-1 bg-gray-900 rounded-full" />
                  </div>

                  {/* Phone Screen Canvas */}
                  <div className={`w-full h-full rounded-[38px] overflow-hidden flex flex-col relative z-20 transition-colors duration-300 ${
                    isMobileLightMode ? "bg-[#f5f7fa] text-slate-900" : "bg-[#040508] text-gray-200"
                  }`}>
                    
                    {/* Status Bar */}
                    <div className={`h-9 px-6 pt-1.5 flex items-center justify-between text-[11px] font-mono select-none z-30 ${
                      isMobileLightMode ? "bg-slate-200/50 text-slate-700" : "bg-black/10 text-gray-400"
                    }`}>
                      <div className="flex items-center gap-1">
                        <Clock className={`w-3 h-3 ${isMobileLightMode ? 'text-slate-600' : 'text-gray-500'}`} />
                        <span className="font-bold">12:35</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Bluetooth className={`w-3 h-3 ${preampWarmth ? 'text-[#00E5FF] animate-pulse' : isMobileLightMode ? 'text-slate-400' : 'text-gray-600'}`} />
                        <Wifi className={`w-3 h-3 ${isMobileLightMode ? 'text-slate-500' : 'text-gray-400'}`} />
                        <Battery className={`w-3.5 h-3.5 ${isMobileLightMode ? 'text-slate-500' : 'text-gray-400'}`} />
                      </div>
                    </div>

                    {/* INTERACTIVE MOBILE VIEWS CONTAINER */}
                    <div className="flex-1 overflow-y-auto px-4 pt-1 pb-16 scrollbar-thin relative">
                      
                      {/* TOAST ALERT OVERLAY */}
                      <AnimatePresence>
                        {toastMessage && (
                          <motion.div
                            initial={{ opacity: 0, y: 15, scale: 0.9 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: -10, scale: 0.9 }}
                            className="absolute bottom-16 left-4 right-4 bg-gradient-to-r from-cyan-900/90 to-blue-900/90 border border-[#00E5FF]/40 text-white rounded-xl py-2 px-3 flex items-center gap-2 shadow-[0_4px_20px_rgba(0,229,255,0.2)] z-50 font-sans text-[10px] font-bold tracking-tight backdrop-blur"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-[#00E5FF]" />
                            <span>{toastMessage}</span>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* SLIDING LEFT NAVIGATION DRAWER */}
                      <AnimatePresence>
                        {isDrawerOpen && (
                          <>
                            {/* Overlay shade */}
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              exit={{ opacity: 0 }}
                              onClick={() => setIsDrawerOpen(false)}
                              className="absolute inset-0 bg-black/75 z-40"
                            />
                            <motion.div
                              initial={{ x: "-100%" }}
                              animate={{ x: 0 }}
                              exit={{ x: "-100%" }}
                              transition={{ type: "spring", damping: 28, stiffness: 280 }}
                              className={`absolute inset-y-0 left-0 w-[230px] ${
                                isMobileLightMode ? "bg-white text-slate-900 border-r border-slate-200" : "bg-[#090d15] text-gray-200 border-r border-[#151c2c]"
                              } z-50 flex flex-col justify-between p-4 shadow-[10px_0_30px_rgba(0,0,0,0.6)]`}
                            >
                              <div>
                                {/* Drawer Header */}
                                <div className="flex items-center justify-between pb-3.5 border-b border-gray-800/10 mb-4 select-none">
                                  <div className="flex items-center gap-2">
                                    <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-500 flex items-center justify-center">
                                      <Music className="w-4 h-4 text-black" />
                                    </div>
                                    <div>
                                      <h3 className="text-xs font-black tracking-tight">¿UNAS ROLITAS?</h3>
                                      <span className="text-[8px] text-cyan-500 font-mono font-bold uppercase tracking-wider">NATIVE AUDIO v2</span>
                                    </div>
                                  </div>
                                  <button
                                    onClick={() => setIsDrawerOpen(false)}
                                    className="p-1 hover:bg-black/10 rounded-lg text-gray-500 hover:text-white transition-all"
                                  >
                                    <X className="w-4 h-4" />
                                  </button>
                                </div>

                                {/* Theme Toggle inside Drawer */}
                                <div className={`p-2.5 rounded-xl border mb-4 flex items-center justify-between select-none ${
                                  isMobileLightMode ? "bg-slate-100 border-slate-200" : "bg-black/30 border-gray-850"
                                }`}>
                                  <span className="text-[9px] font-black uppercase text-gray-500">Tema:</span>
                                  <button
                                    onClick={() => {
                                      playSynthBeep(isMobileLightMode ? 400 : 700, 0.08);
                                      setIsMobileLightMode(!isMobileLightMode);
                                      showToast(isMobileLightMode ? "Tema Oscuro activo" : "Tema Claro activo");
                                    }}
                                    className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[8px] font-extrabold transition-all ${
                                      isMobileLightMode ? "bg-amber-100 text-amber-700" : "bg-[#00E5FF]/20 text-[#00E5FF]"
                                    }`}
                                  >
                                    {isMobileLightMode ? <Sun className="w-3.5 h-3.5 fill-amber-500" /> : <Moon className="w-3.5 h-3.5 fill-[#00E5FF]" />}
                                    <span>{isMobileLightMode ? "CLARO" : "OSCURO"}</span>
                                  </button>
                                </div>

                                {/* Menu Items */}
                                <div className="space-y-1 select-none">
                                  <h4 className="text-[8px] font-bold text-gray-500 uppercase tracking-widest pl-2 mb-1.5">Biblioteca local</h4>
                                  {[
                                    { label: "Canciones", id: "canciones", icon: Music },
                                    { label: "Playlists", id: "playlists", icon: ListMusic },
                                    { label: "Carpetas de Música", id: "carpetas", icon: Folder },
                                    { label: "Álbumes", id: "albumes", icon: Layers },
                                    { label: "Artistas", id: "artistas", icon: User },
                                    { label: "Géneros", id: "generos", icon: Compass },
                                    { label: "Podcasts locales", id: "podcasts", icon: Radio },
                                    { label: "Audiolibros", id: "audiolibros", icon: FileText }
                                  ].map((item) => {
                                    const Icon = item.icon;
                                    return (
                                      <button
                                        key={item.id}
                                        onClick={() => {
                                          playSynthBeep(490, 0.04);
                                          setLibraryTab(item.id);
                                          setActivePlaylistName(null);
                                          setMobileTab("biblioteca");
                                          setIsDrawerOpen(false);
                                        }}
                                        className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-[11px] font-black transition-all text-left ${
                                          mobileTab === "biblioteca" && libraryTab === item.id
                                            ? "bg-[#00E5FF]/15 text-[#00E5FF] border border-[#00E5FF]/20"
                                            : isMobileLightMode ? "hover:bg-slate-100 text-slate-700 border border-transparent" : "hover:bg-white/5 text-gray-400 border border-transparent"
                                        }`}
                                      >
                                        <Icon className="w-3.5 h-3.5 shrink-0" />
                                        <span>{item.label}</span>
                                      </button>
                                    );
                                  })}
                                </div>

                                {/* General Navigation Items */}
                                <div className="space-y-1 select-none mt-4 border-t border-gray-800/10 pt-3">
                                  <h4 className="text-[8px] font-bold text-gray-500 uppercase tracking-widest pl-2 mb-1.5">Navegación</h4>
                                  <button
                                    onClick={() => {
                                      playSynthBeep(490, 0.04);
                                      setMobileTab("buscar");
                                      setIsDrawerOpen(false);
                                    }}
                                    className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-[11px] font-black transition-all text-left ${
                                      mobileTab === "buscar"
                                        ? "bg-[#00E5FF]/15 text-[#00E5FF] border border-[#00E5FF]/20"
                                        : isMobileLightMode ? "hover:bg-slate-100 text-slate-700 border border-transparent" : "hover:bg-white/5 text-gray-400 border border-transparent"
                                    }`}
                                  >
                                    <Search className="w-3.5 h-3.5 shrink-0" />
                                    <span>Buscar Música</span>
                                  </button>
                                  <button
                                    onClick={() => {
                                      playSynthBeep(490, 0.04);
                                      setMobileTab("ajustes");
                                      setIsDrawerOpen(false);
                                    }}
                                    className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-[11px] font-black transition-all text-left ${
                                      mobileTab === "ajustes"
                                        ? "bg-[#00E5FF]/15 text-[#00E5FF] border border-[#00E5FF]/20"
                                        : isMobileLightMode ? "hover:bg-slate-100 text-slate-700 border border-transparent" : "hover:bg-white/5 text-gray-400 border border-transparent"
                                    }`}
                                  >
                                    <Settings className="w-3.5 h-3.5 shrink-0" />
                                    <span>Ajustes / Opciones</span>
                                  </button>
                                </div>
                              </div>

                              {/* Drawer Footer Stats */}
                              <div className="border-t border-gray-800/10 pt-3.5 mt-auto select-none">
                                <div className="space-y-1 text-[8.5px] text-gray-500 font-mono leading-relaxed">
                                  <div className="flex justify-between"><span>Pistas locales:</span> <span className="font-extrabold text-gray-300">{tracks.length}</span></div>
                                  <div className="flex justify-between"><span>En Lista Negra:</span> <span className="font-extrabold text-red-500">{blacklistedSongs.length}</span></div>
                                  <div className="flex justify-between"><span>Ocultas:</span> <span className="font-extrabold text-yellow-500">{hiddenSongs.length}</span></div>
                                </div>
                                <button
                                  onClick={() => {
                                    playSynthBeep(650, 0.1);
                                    setTracks(simulatedTracks);
                                    setBlacklistedSongs([]);
                                    setHiddenSongs([]);
                                    setFavoriteSongs(["Luna de Octubre", "Atardecer"]);
                                    setPlaylists({
                                      "Favoritas": ["Luna de Octubre", "Atardecer"],
                                      "Sabor Latino": ["Luna de Octubre"],
                                      "Para Programar": ["Vuelo Libre", "Atardecer"],
                                      "Viaje Nocturno": ["Ritmo Urbano", "Ecos del Silencio"]
                                    });
                                    showToast("Biblioteca restaurada");
                                    setIsDrawerOpen(false);
                                  }}
                                  className="w-full mt-3 text-center text-[8.5px] font-black uppercase bg-red-650/10 hover:bg-red-500/10 text-red-400 border border-red-500/20 py-1.5 rounded-lg transition-all"
                                >
                                  Restaurar por Defecto
                                </button>
                              </div>
                            </motion.div>
                          </>
                        )}
                      </AnimatePresence>

                      {/* SONG OPTIONS BOTTOM SHEET */}
                      <AnimatePresence>
                        {activeOptionsTrack && (
                          <>
                            {/* Shade */}
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              exit={{ opacity: 0 }}
                              onClick={() => setActiveOptionsTrack(null)}
                              className="absolute inset-0 bg-black/80 z-[90]"
                            />
                            <motion.div
                              initial={{ y: "100%" }}
                              animate={{ y: 0 }}
                              exit={{ y: "100%" }}
                              transition={{ type: "spring", damping: 28, stiffness: 240 }}
                              className={`absolute bottom-0 inset-x-0 max-h-[80%] ${
                                isMobileLightMode ? "bg-white text-slate-950 border-t border-slate-200" : "bg-[#090d16] text-gray-200 border-t border-[#1a253c]"
                              } rounded-t-[32px] overflow-y-auto z-[100] p-4 scrollbar-thin shadow-[0_-8px_30px_rgba(0,0,0,0.6)] flex flex-col`}
                            >
                              {/* Header: Track Details */}
                              <div className="flex items-start justify-between pb-3 border-b border-gray-850/10 mb-3 select-none">
                                <div className="flex items-center gap-2.5">
                                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#00E5FF] to-blue-600 flex items-center justify-center border border-[#00E5FF]/30 shrink-0">
                                    <Music className="w-5 h-5 text-black" />
                                  </div>
                                  <div className="min-w-0">
                                    <h3 className="text-xs font-black truncate max-w-[170px]">{activeOptionsTrack.title}</h3>
                                    <p className="text-[9px] text-gray-500 font-bold truncate max-w-[170px] mt-0.5">{activeOptionsTrack.artist}</p>
                                  </div>
                                </div>
                                <button
                                  onClick={() => setActiveOptionsTrack(null)}
                                  className="p-1 rounded-full bg-black/10 text-gray-500 hover:text-white transition-all"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                              </div>

                              {/* Options Content Accordion Categories */}
                              <div className="space-y-2 flex-1 pb-4 select-none">
                                {[
                                  { id: "reproduccion", label: "A. Reproducción", icon: Play },
                                  { id: "biblioteca", label: "B. Biblioteca", icon: ListMusic },
                                  { id: "editar", label: "C. Editar Información", icon: FileText },
                                  { id: "archivo", label: "D. Archivo", icon: Folder },
                                  { id: "audio", label: "E. Audio", icon: Sliders },
                                  { id: "mas", label: "F. Más Opciones", icon: Plus }
                                ].map((cat) => {
                                  const isExpanded = expandedCategory === cat.id;
                                  const CatIcon = cat.icon;
                                  return (
                                    <div key={cat.id} className={`rounded-xl border transition-all ${
                                      isMobileLightMode ? "border-slate-200 bg-slate-50" : "border-[#131826] bg-black/20"
                                    }`}>
                                      <button
                                        onClick={() => {
                                          playSynthBeep(450, 0.04);
                                          setExpandedCategory(isExpanded ? null : cat.id);
                                        }}
                                        className="w-full flex items-center justify-between p-2.5 text-left text-[11px] font-black tracking-tight"
                                      >
                                        <div className="flex items-center gap-2">
                                          <CatIcon className="w-3.5 h-3.5 text-[#00E5FF]" />
                                          <span>{cat.label}</span>
                                        </div>
                                        <ChevronRight className={`w-3.5 h-3.5 text-gray-500 transition-transform ${isExpanded ? "rotate-90 text-[#00E5FF]" : ""}`} />
                                      </button>

                                      {isExpanded && (
                                        <div className={`p-3 pt-1 border-t border-dashed ${
                                          isMobileLightMode ? "border-slate-200 text-slate-800" : "border-gray-900/50 text-gray-300"
                                        } space-y-2 text-[10px]`}>
                                          
                                          {/* CATEGORY: REPRODUCCION */}
                                          {cat.id === "reproduccion" && (
                                            <div className="space-y-1.5 pt-1.5">
                                              <button
                                                onClick={() => {
                                                  playSynthBeep(650, 0.08);
                                                  playTrackFromLibrary(activeOptionsTrack);
                                                  setActiveOptionsTrack(null);
                                                }}
                                                className="w-full flex items-center gap-2 p-1.5 hover:bg-[#00E5FF]/10 hover:text-[#00E5FF] rounded-lg font-bold text-left transition-colors"
                                              >
                                                <Play className="w-3.5 h-3.5 text-green-500 fill-green-500/20" />
                                                <span>Reproducir ahora</span>
                                              </button>

                                              <button
                                                onClick={() => {
                                                  playSynthBeep(520, 0.05);
                                                  setPlaybackQueue([...playbackQueue, activeOptionsTrack]);
                                                  showToast("Canción agregada a la cola");
                                                  setActiveOptionsTrack(null);
                                                }}
                                                className="w-full flex items-center gap-2 p-1.5 hover:bg-[#00E5FF]/10 hover:text-[#00E5FF] rounded-lg font-bold text-left transition-colors"
                                              >
                                                <ListPlus className="w-3.5 h-3.5 text-[#00E5FF]" />
                                                <span>Agregar a cola de reproducción</span>
                                              </button>

                                              <button
                                                onClick={() => {
                                                  playSynthBeep(520, 0.05);
                                                  // Insert next in queue
                                                  const newQueue = [...playbackQueue];
                                                  newQueue.splice(currentQueueIndex + 1, 0, activeOptionsTrack);
                                                  setPlaybackQueue(newQueue);
                                                  showToast("Se reproducirá a continuación");
                                                  setActiveOptionsTrack(null);
                                                }}
                                                className="w-full flex items-center gap-2 p-1.5 hover:bg-[#00E5FF]/10 hover:text-[#00E5FF] rounded-lg font-bold text-left transition-colors"
                                              >
                                                <SkipForward className="w-3.5 h-3.5 text-blue-400" />
                                                <span>Reproducir después</span>
                                              </button>

                                              <button
                                                onClick={() => {
                                                  playSynthBeep(540, 0.05);
                                                  // Insert with high priority as current next
                                                  const newQueue = [...playbackQueue];
                                                  newQueue.splice(currentQueueIndex + 1, 0, activeOptionsTrack);
                                                  setPlaybackQueue(newQueue);
                                                  showToast("Prioridad alta establecida");
                                                  setActiveOptionsTrack(null);
                                                }}
                                                className="w-full flex items-center gap-2 p-1.5 hover:bg-[#00E5FF]/10 hover:text-[#00E5FF] rounded-lg font-bold text-left transition-colors"
                                              >
                                                <Sparkles className="w-3.5 h-3.5 text-yellow-500" />
                                                <span>Reproducir con prioridad</span>
                                              </button>
                                            </div>
                                          )}

                                          {/* CATEGORY: BIBLIOTECA */}
                                          {cat.id === "biblioteca" && (
                                            <div className="space-y-1.5 pt-1.5">
                                              <button
                                                onClick={() => {
                                                  toggleFavorite(activeOptionsTrack.title);
                                                  setActiveOptionsTrack(null);
                                                }}
                                                className="w-full flex items-center gap-2 p-1.5 hover:bg-[#00E5FF]/10 hover:text-[#00E5FF] rounded-lg font-bold text-left transition-colors"
                                              >
                                                <Heart className={`w-3.5 h-3.5 ${favoriteSongs.includes(activeOptionsTrack.title) ? "text-[#FF007F] fill-[#FF007F]" : ""}`} />
                                                <span>{favoriteSongs.includes(activeOptionsTrack.title) ? "Quitar de favoritos" : "Agregar a favoritos"}</span>
                                              </button>

                                              {/* Agregar a lista de reproducción */}
                                              <div className="p-1.5 bg-black/10 rounded-lg border border-white/5">
                                                <span className="font-black text-gray-500 block mb-1 uppercase text-[8px]">Agregar a lista de reproducción:</span>
                                                <div className="flex flex-wrap gap-1">
                                                  {Object.keys(playlists).map(pName => {
                                                    const inList = playlists[pName].includes(activeOptionsTrack.title);
                                                    return (
                                                      <button
                                                        key={pName}
                                                        onClick={() => {
                                                          playSynthBeep(490, 0.04);
                                                          const currentSongs = playlists[pName];
                                                          if (inList) {
                                                            setPlaylists({
                                                              ...playlists,
                                                              [pName]: currentSongs.filter(s => s !== activeOptionsTrack.title)
                                                            });
                                                            showToast(`Quitado de ${pName}`);
                                                          } else {
                                                            setPlaylists({
                                                              ...playlists,
                                                              [pName]: [...currentSongs, activeOptionsTrack.title]
                                                            });
                                                            showToast(`Agregado a ${pName}`);
                                                          }
                                                        }}
                                                        className={`px-2 py-0.5 rounded text-[8.5px] font-extrabold border transition-all ${
                                                          inList ? "bg-[#00E5FF]/10 border-[#00E5FF]/40 text-[#00E5FF]" : "bg-black/30 border-gray-800 text-gray-400"
                                                        }`}
                                                      >
                                                        {pName}
                                                      </button>
                                                    );
                                                  })}
                                                </div>
                                              </div>

                                              {/* Crear nueva lista de reproducción con esta canción */}
                                              <div className="p-1.5 bg-black/10 rounded-lg border border-white/5 space-y-1">
                                                <span className="font-black text-gray-500 block uppercase text-[8px]">Crear nueva lista con esta canción:</span>
                                                <div className="flex gap-1">
                                                  <input
                                                    type="text"
                                                    placeholder="Nueva lista..."
                                                    id="new_playlist_inline_input"
                                                    className="bg-black/40 border border-gray-800 rounded px-2 py-0.5 text-[9px] outline-none flex-1 text-gray-200 focus:border-[#00E5FF]/40"
                                                  />
                                                  <button
                                                    onClick={() => {
                                                      const inputEl = document.getElementById("new_playlist_inline_input") as HTMLInputElement;
                                                      if (inputEl && inputEl.value.trim()) {
                                                        const pName = inputEl.value.trim();
                                                        playSynthBeep(520, 0.08);
                                                        setPlaylists({
                                                          ...playlists,
                                                          [pName]: [activeOptionsTrack.title]
                                                        });
                                                        showToast(`Lista "${pName}" creada con éxito`);
                                                        inputEl.value = "";
                                                      } else {
                                                        playSynthBeep(300, 0.1);
                                                        showToast("Por favor ingresa un nombre");
                                                      }
                                                    }}
                                                    className="bg-[#00E5FF] text-black px-2 py-0.5 rounded text-[8.5px] font-black"
                                                  >
                                                    CREAR
                                                  </button>
                                                </div>
                                              </div>

                                              <button
                                                onClick={() => {
                                                  playSynthBeep(430, 0.05);
                                                  setHiddenSongs([...hiddenSongs, activeOptionsTrack.title]);
                                                  showToast("Canción oculta de biblioteca");
                                                  setActiveOptionsTrack(null);
                                                }}
                                                className="w-full flex items-center gap-2 p-1.5 hover:bg-yellow-500/10 text-yellow-500 rounded-lg font-bold text-left transition-colors"
                                              >
                                                <EyeOff className="w-3.5 h-3.5" />
                                                <span>Ocultar canción</span>
                                              </button>

                                              {!blacklistedSongs.includes(activeOptionsTrack.title) ? (
                                                <button
                                                  onClick={() => {
                                                    playSynthBeep(320, 0.08);
                                                    setBlacklistedSongs([...blacklistedSongs, activeOptionsTrack.title]);
                                                    showToast("Agregada a Lista Negra");
                                                    setActiveOptionsTrack(null);
                                                  }}
                                                  className="w-full flex items-center gap-2 p-1.5 hover:bg-red-500/10 text-red-500 rounded-lg font-bold text-left transition-colors"
                                                >
                                                  <Ban className="w-3.5 h-3.5" />
                                                  <span>Agregar a lista negra (Black List)</span>
                                                </button>
                                              ) : (
                                                <button
                                                  onClick={() => {
                                                    playSynthBeep(520, 0.08);
                                                    setBlacklistedSongs(blacklistedSongs.filter(s => s !== activeOptionsTrack.title));
                                                    showToast("Quitada de Lista Negra");
                                                    setActiveOptionsTrack(null);
                                                  }}
                                                  className="w-full flex items-center gap-2 p-1.5 hover:bg-green-500/10 text-green-500 rounded-lg font-bold text-left transition-colors"
                                                >
                                                  <CheckCircle className="w-3.5 h-3.5" />
                                                  <span>Quitar de lista negra</span>
                                                </button>
                                              )}
                                            </div>
                                          )}

                                          {/* CATEGORY: EDITAR INFORMACION */}
                                          {cat.id === "editar" && (
                                            <div className="space-y-2 pt-1.5">
                                              
                                              {/* A. EDITAR PORTADA (COLOR PALETTE) */}
                                              <div className="p-1.5 bg-black/15 rounded-lg border border-white/5 space-y-1">
                                                <span className="font-black text-gray-500 block uppercase text-[8px] flex items-center gap-1">
                                                  <Image className="w-3 h-3 text-[#00E5FF]" /> EDITAR PORTADA DEL ÁLBUM:
                                                </span>
                                                <div className="flex gap-1.5 justify-between">
                                                  {[
                                                    { id: "violeta", color: "bg-purple-500" },
                                                    { id: "esmeralda", color: "bg-emerald-500" },
                                                    { id: "dorado", color: "bg-yellow-500" },
                                                    { id: "cian", color: "bg-cyan-500" },
                                                    { id: "rosa", color: "bg-pink-500" },
                                                    { id: "coral", color: "bg-orange-500" },
                                                    { id: "ambar", color: "bg-amber-500" }
                                                  ].map(plt => (
                                                    <button
                                                      key={plt.id}
                                                      onClick={() => {
                                                        playSynthBeep(600, 0.06);
                                                        setTracks(tracks.map(t => {
                                                          if (t.title === activeOptionsTrack.title) {
                                                            return { ...t, coverColor: plt.id };
                                                          }
                                                          return t;
                                                        }));
                                                        showToast(`Portada cambiada a tono: ${plt.id}`);
                                                      }}
                                                      className={`w-4 h-4 rounded-full ${plt.color} border border-white/20 hover:scale-125 transition-transform`}
                                                      title={plt.id}
                                                    />
                                                  ))}
                                                </div>
                                              </div>

                                              {/* B. DETAILED EDIT BUTTON FOR EACH FIELD */}
                                              <div className="space-y-1.5">
                                                <span className="font-black text-gray-500 block uppercase text-[8px] flex items-center gap-1">
                                                  <Edit className="w-3 h-3 text-[#00E5FF]" /> EDITAR CAMPOS ID3:
                                                </span>

                                                {[
                                                  { field: "title", label: "Editar título", val: activeOptionsTrack.title, icon: Edit },
                                                  { field: "artist", label: "Editar artista", val: activeOptionsTrack.artist, icon: User },
                                                  { field: "album", label: "Editar álbum", val: activeOptionsTrack.album, icon: Disc },
                                                  { field: "genre", label: "Editar género", val: activeOptionsTrack.genre, icon: Compass },
                                                  { field: "year", label: "Editar año", val: activeOptionsTrack.year || "2026", icon: Calendar },
                                                  { field: "composer", label: "Editar compositor", val: activeOptionsTrack.composer || "Autogestionado", icon: User }
                                                ].map((fld) => (
                                                  <div key={fld.field} className="flex flex-col gap-0.5 bg-black/10 p-1.5 rounded-lg border border-white/5">
                                                    <label className="text-[7.5px] font-mono font-bold uppercase text-gray-500 flex items-center gap-1">
                                                      <fld.icon className="w-2.5 h-2.5" /> {fld.label}
                                                    </label>
                                                    <div className="flex gap-1.5">
                                                      <input
                                                        type="text"
                                                        defaultValue={fld.val}
                                                        id={`meta_input_${fld.field}`}
                                                        className="bg-black/60 border border-gray-800 rounded px-1.5 py-0.5 text-[9px] text-gray-200 outline-none flex-1 focus:border-[#00E5FF]/40"
                                                      />
                                                      <button
                                                        onClick={() => {
                                                          const inputEl = document.getElementById(`meta_input_${fld.field}`) as HTMLInputElement;
                                                          if (inputEl) {
                                                            const newVal = inputEl.value;
                                                            playSynthBeep(640, 0.06);
                                                            setTracks(tracks.map(t => {
                                                              if (t.title === activeOptionsTrack.title) {
                                                                return { ...t, [fld.field]: newVal };
                                                              }
                                                              return t;
                                                            }));
                                                            showToast(`Campo guardado`);
                                                          }
                                                        }}
                                                        className="bg-cyan-950 hover:bg-cyan-900 text-[#00E5FF] border border-cyan-800/40 px-2 rounded text-[8px] font-black uppercase"
                                                      >
                                                        OK
                                                      </button>
                                                    </div>
                                                  </div>
                                                ))}

                                                {/* C. EDITAR METADATOS (COMPLETE EDIT) */}
                                                <button
                                                  onClick={() => {
                                                    playSynthBeep(600, 0.05);
                                                    showToast("Guardando metadatos completos...");
                                                    // Trigger all fields save simulation
                                                    const fields = ["title", "artist", "album", "genre", "year", "composer"];
                                                    let updatedFields: any = {};
                                                    fields.forEach(f => {
                                                      const el = document.getElementById(`meta_input_${f}`) as HTMLInputElement;
                                                      if (el) {
                                                        updatedFields[f] = el.value;
                                                      }
                                                    });
                                                    setTracks(tracks.map(t => {
                                                      if (t.title === activeOptionsTrack.title) {
                                                        return { ...t, ...updatedFields };
                                                      }
                                                      return t;
                                                    }));
                                                    showToast("Metadatos actualizados con éxito");
                                                    setActiveOptionsTrack(null);
                                                  }}
                                                  className="w-full py-1.5 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-[#00E5FF] border border-[#00E5FF]/30 rounded-lg font-black text-center text-[9px] uppercase"
                                                >
                                                  Guardar todos los metadatos
                                                </button>

                                                {/* D. AÑADIR ETIQUETAS PERSONALIZADAS */}
                                                <div className="p-1.5 bg-black/10 rounded-lg border border-white/5 space-y-1">
                                                  <span className="font-black text-gray-500 block uppercase text-[8px] flex items-center gap-1">
                                                    <Tag className="w-2.5 h-2.5 text-pink-400" /> Añadir etiquetas personalizadas:
                                                  </span>
                                                  <div className="flex gap-1">
                                                    <input
                                                      type="text"
                                                      placeholder="E.g., relax, urbano, clasico"
                                                      id="custom_tags_input"
                                                      className="bg-black/40 border border-gray-800 rounded px-1.5 py-0.5 text-[8.5px] outline-none flex-1 text-gray-200 focus:border-[#00E5FF]/40"
                                                    />
                                                    <button
                                                      onClick={() => {
                                                        const inputEl = document.getElementById("custom_tags_input") as HTMLInputElement;
                                                        if (inputEl && inputEl.value.trim()) {
                                                          const newTags = inputEl.value.split(",").map(t => t.trim().toLowerCase());
                                                          playSynthBeep(520, 0.08);
                                                          setTracks(tracks.map(t => {
                                                            if (t.title === activeOptionsTrack.title) {
                                                              const currentTags = t.customTags || [];
                                                              return { ...t, customTags: Array.from(new Set([...currentTags, ...newTags])) };
                                                            }
                                                            return t;
                                                          }));
                                                          showToast(`Etiquetas agregadas`);
                                                          inputEl.value = "";
                                                        }
                                                      }}
                                                      className="bg-pink-600 hover:bg-pink-700 text-white px-2 py-0.5 rounded text-[8px] font-black"
                                                    >
                                                      AÑADIR
                                                    </button>
                                                  </div>
                                                  {activeOptionsTrack.customTags && activeOptionsTrack.customTags.length > 0 && (
                                                    <div className="flex flex-wrap gap-1 mt-1">
                                                      {activeOptionsTrack.customTags.map(tg => (
                                                        <span key={tg} className="bg-pink-950/40 text-pink-300 px-1.5 py-0.2 rounded text-[7.5px] font-mono border border-pink-900/30">
                                                          #{tg}
                                                        </span>
                                                      ))}
                                                    </div>
                                                  )}
                                                </div>
                                              </div>
                                            </div>
                                          )}

                                          {/* CATEGORY: ARCHIVO */}
                                          {cat.id === "archivo" && (
                                            <div className="space-y-2 pt-1.5">
                                              
                                              {/* Ver archivo en almacenamiento */}
                                              <div className="bg-black/40 border border-gray-850 p-2 rounded-lg text-[9px] font-mono leading-relaxed space-y-0.5">
                                                <div className="text-[7.5px] text-[#00E5FF] font-black mb-1 uppercase tracking-wider">Ver archivo en almacenamiento:</div>
                                                <div><span className="text-gray-500">Ubicación Absoluta:</span> <span className="text-gray-300 font-bold">{activeOptionsTrack.folder || "/storage/Music/Descargas"}/{activeOptionsTrack.title.replace(/ /g, "_")}.mp3</span></div>
                                                <div><span className="text-gray-500">MIME Type:</span> <span className="text-gray-300">audio/mpeg</span></div>
                                                <div><span className="text-gray-500">Tamaño Físico:</span> <span className="text-gray-300 font-bold">{activeOptionsTrack.size}</span></div>
                                                <div><span className="text-gray-500">Permisos:</span> <span className="text-green-400 font-bold">Lectura/Escritura (R/W)</span></div>
                                              </div>

                                              {/* Abrir ubicación del archivo */}
                                              <button
                                                onClick={() => {
                                                  playSynthBeep(520, 0.05);
                                                  showToast(`Carpeta abierta: ${activeOptionsTrack.folder || "/storage/Music/Descargas"}`);
                                                  addLiveLog(`Explorador abierto en: ${activeOptionsTrack.folder || "/storage/Music/Descargas"}`);
                                                }}
                                                className="w-full flex items-center gap-2 p-1.5 hover:bg-[#00E5FF]/10 hover:text-[#00E5FF] rounded-lg font-bold text-left transition-colors"
                                              >
                                                <FolderOpen className="w-3.5 h-3.5 text-amber-500" />
                                                <span>Abrir ubicación del archivo</span>
                                              </button>

                                              {/* Compartir canción */}
                                              <button
                                                onClick={() => {
                                                  playSynthBeep(520, 0.05);
                                                  showToast("Enlace virtual copiado!");
                                                  addLiveLog(`Canción "${activeOptionsTrack.title}" compartida`);
                                                  setActiveOptionsTrack(null);
                                                }}
                                                className="w-full flex items-center gap-2 p-1.5 hover:bg-[#00E5FF]/10 hover:text-[#00E5FF] rounded-lg font-bold text-left transition-colors"
                                              >
                                                <Share2 className="w-3.5 h-3.5 text-green-400" />
                                                <span>Compartir canción</span>
                                              </button>

                                              {/* Renombrar archivo */}
                                              <div className="p-1.5 bg-black/10 rounded-lg border border-white/5 space-y-1">
                                                <span className="font-black text-gray-500 block uppercase text-[8px] flex items-center gap-1">
                                                  <PenTool className="w-2.5 h-2.5 text-yellow-400" /> Renombrar archivo físico:
                                                </span>
                                                <div className="flex gap-1">
                                                  <input
                                                    type="text"
                                                    defaultValue={`${activeOptionsTrack.title.replace(/ /g, "_")}.mp3`}
                                                    id="rename_file_input"
                                                    className="bg-black/40 border border-gray-800 rounded px-1.5 py-0.5 text-[8.5px] outline-none flex-1 text-gray-200 focus:border-[#00E5FF]/40 font-mono"
                                                  />
                                                  <button
                                                    onClick={() => {
                                                      const inputEl = document.getElementById("rename_file_input") as HTMLInputElement;
                                                      if (inputEl && inputEl.value.trim()) {
                                                        const newName = inputEl.value.trim();
                                                        playSynthBeep(600, 0.08);
                                                        showToast(`Archivo renombrado a ${newName}`);
                                                        addLiveLog(`Archivo renombrado a: ${newName}`);
                                                      }
                                                    }}
                                                    className="bg-yellow-500 text-black px-2 py-0.5 rounded text-[8px] font-black"
                                                  >
                                                    OK
                                                  </button>
                                                </div>
                                              </div>

                                              {/* Mover archivo */}
                                              <div className="p-1.5 bg-black/10 rounded-lg border border-white/5 space-y-1">
                                                <span className="font-black text-gray-500 block uppercase text-[8px] flex items-center gap-1">
                                                  <Move className="w-2.5 h-2.5 text-purple-400" /> Mover archivo a:
                                                </span>
                                                <select
                                                  onChange={(e) => {
                                                    const dest = e.target.value;
                                                    playSynthBeep(520, 0.06);
                                                    setTracks(tracks.map(t => {
                                                      if (t.title === activeOptionsTrack.title) {
                                                        return { ...t, folder: dest };
                                                      }
                                                      return t;
                                                    }));
                                                    showToast(`Archivo movido a: ${dest}`);
                                                    addLiveLog(`Archivo movido a: ${dest}`);
                                                  }}
                                                  className="bg-black text-gray-200 text-[8.5px] font-bold py-1 px-1.5 rounded border border-gray-800 outline-none w-full"
                                                >
                                                  <option value="/storage/Music/Descargas">/storage/Music/Descargas</option>
                                                  <option value="/storage/Music/Favoritas">/storage/Music/Favoritas</option>
                                                  <option value="/storage/Music/Clásicos">/storage/Music/Clásicos</option>
                                                  <option value="/storage/Music/Podcasts">/storage/Music/Podcasts</option>
                                                </select>
                                              </div>

                                              {/* Eliminar archivo */}
                                              <button
                                                onClick={() => {
                                                  playSynthBeep(300, 0.1);
                                                  setTracks(tracks.filter(t => t.title !== activeOptionsTrack.title));
                                                  showToast("Canción eliminada de biblioteca");
                                                  setActiveOptionsTrack(null);
                                                }}
                                                className="w-full flex items-center gap-2 p-1.5 hover:bg-red-500/10 text-red-500 rounded-lg font-bold text-left transition-colors"
                                              >
                                                <Trash2 className="w-3.5 h-3.5 text-red-500" />
                                                <span>Eliminar archivo</span>
                                              </button>
                                            </div>
                                          )}

                                          {/* CATEGORY: AUDIO */}
                                          {cat.id === "audio" && (
                                            <div className="space-y-2 pt-1.5">
                                              
                                              {/* Ver propiedades de audio */}
                                              <div className="bg-black/40 border border-gray-850 p-2 rounded-lg text-[9px] font-mono leading-relaxed space-y-0.5">
                                                <div className="text-[7.5px] text-[#00E5FF] font-black mb-1 uppercase tracking-wider">Propiedades de audio y codec:</div>
                                                <div><span className="text-gray-500">Bitrate de audio:</span> <span className="text-cyan-400 font-bold">320 kbps (Simetría CBR)</span></div>
                                                <div><span className="text-gray-500">Frecuencia de muestreo:</span> <span>44,100 Hz (CD Audio)</span></div>
                                                <div><span className="text-gray-500">Canales de salida:</span> <span>Estéreo (Joint-Stereo)</span></div>
                                                <div><span className="text-gray-500">Dynamic Range (Loudness):</span> <span className="text-yellow-500">-14.2 LUFS</span></div>
                                              </div>

                                              {/* Analizar calidad del audio */}
                                              <div className="space-y-1.5">
                                                <button
                                                  onClick={() => {
                                                    if (isAnalyzing) return;
                                                    setIsAnalyzing(true);
                                                    setAnalysisResult(null);
                                                    
                                                    playSynthBeep(180, 0.12, "triangle");
                                                    setTimeout(() => playSynthBeep(360, 0.12, "triangle"), 150);
                                                    setTimeout(() => playSynthBeep(720, 0.12, "triangle"), 300);
                                                    setTimeout(() => playSynthBeep(1440, 0.18, "sine"), 450);
                                                    
                                                    setTimeout(() => {
                                                      setIsAnalyzing(false);
                                                      setAnalysisResult("Fidelidad: 100% Excelente espectro (CBR original)");
                                                      playSynthBeep(880, 0.08);
                                                    }, 1200);
                                                  }}
                                                  className="w-full py-1 px-2.5 bg-cyan-950 text-[#00E5FF] border border-cyan-800/40 hover:bg-[#00E5FF]/20 rounded-lg font-black flex items-center justify-center gap-2"
                                                >
                                                  <Activity className="w-3.5 h-3.5 animate-pulse text-[#00E5FF]" />
                                                  <span>{isAnalyzing ? "Analizando Hertz..." : "Analizar calidad del audio"}</span>
                                                </button>
                                                
                                                {analysisResult && (
                                                  <div className="text-[8.5px] text-green-400 font-bold bg-green-950/20 border border-green-900/30 p-1.5 rounded-lg text-center font-mono">
                                                    ✓ {analysisResult}
                                                  </div>
                                                )}
                                              </div>

                                              {/* Convertir formato de audio */}
                                              <div className="border-t border-gray-800/25 pt-2">
                                                <span className="font-extrabold text-gray-500 block mb-1 uppercase text-[8px]">Convertir formato de audio:</span>
                                                <div className="flex gap-1">
                                                  {["FLAC", "OGG", "WAV", "AAC"].map((fmt) => (
                                                    <button
                                                      key={fmt}
                                                      onClick={() => {
                                                        if (isConverting) return;
                                                        setConversionTarget(fmt);
                                                        setIsConverting(true);
                                                        setConversionProgress(0);
                                                        
                                                        playSynthBeep(420, 0.1, "sawtooth");
                                                        
                                                        const interval = setInterval(() => {
                                                          setConversionProgress(prev => {
                                                            if (prev >= 100) {
                                                              clearInterval(interval);
                                                              setIsConverting(false);
                                                              showToast(`Transcodificado a ${fmt}`);
                                                              playSynthBeep(880, 0.12, "sine");
                                                              return 100;
                                                            }
                                                            playSynthBeep(250 + (prev * 7), 0.02, "triangle");
                                                            return prev + 25;
                                                          });
                                                        }, 350);
                                                      }}
                                                      className="flex-1 bg-black/40 hover:bg-[#00E5FF]/10 text-gray-400 hover:text-[#00E5FF] border border-gray-800 hover:border-[#00E5FF]/40 rounded py-0.5 text-[8.5px] font-black"
                                                    >
                                                      {fmt}
                                                    </button>
                                                  ))}
                                                </div>

                                                {isConverting && (
                                                  <div className="mt-2 space-y-1">
                                                    <div className="flex justify-between text-[7.5px] font-mono text-gray-400">
                                                      <span>Codificando a {conversionTarget}...</span>
                                                      <span>{conversionProgress}%</span>
                                                    </div>
                                                    <div className="w-full h-1 bg-gray-900 rounded-full overflow-hidden">
                                                      <div className="h-full bg-gradient-to-r from-[#00E5FF] to-cyan-500" style={{ width: `${conversionProgress}%` }} />
                                                    </div>
                                                  </div>
                                                )}
                                              </div>

                                              {/* Escanear nuevamente información multimedia */}
                                              <button
                                                onClick={() => {
                                                  playSynthBeep(600, 0.05);
                                                  showToast("Escaneando etiquetas de audio...");
                                                  setTimeout(() => {
                                                    playSynthBeep(880, 0.08);
                                                    showToast("Etiquetas multimedia sincronizadas");
                                                  }, 800);
                                                }}
                                                className="w-full flex items-center justify-center gap-2 p-1.5 hover:bg-[#00E5FF]/10 hover:text-[#00E5FF] rounded-lg font-bold border border-white/5 bg-black/10 transition-colors"
                                              >
                                                <RefreshCw className="w-3.5 h-3.5 text-pink-400" />
                                                <span>Escanear nuevamente información multimedia</span>
                                              </button>
                                            </div>
                                          )}

                                          {/* CATEGORY: MAS */}
                                          {cat.id === "mas" && (
                                            <div className="space-y-1.5 pt-1.5">
                                              
                                              {/* Marcar como reproducida/no reproducida */}
                                              <button
                                                onClick={() => {
                                                  playSynthBeep(520, 0.05);
                                                  setTracks(tracks.map(t => {
                                                    if (t.title === activeOptionsTrack.title) {
                                                      const currentPlays = t.plays || 0;
                                                      return { ...t, plays: currentPlays > 0 ? 0 : 1 };
                                                    }
                                                    return t;
                                                  }));
                                                  showToast(activeOptionsTrack.plays ? "Marcada como NO reproducida" : "Marcada como reproducida");
                                                  setActiveOptionsTrack(null);
                                                }}
                                                className="w-full flex items-center gap-2 p-1.5 hover:bg-[#00E5FF]/10 hover:text-[#00E5FF] rounded-lg font-bold text-left transition-colors"
                                              >
                                                <Check className="w-3.5 h-3.5 text-green-400" />
                                                <span>{activeOptionsTrack.plays ? "Marcar como no reproducida" : "Marcar como reproducida"}</span>
                                              </button>

                                              {/* Ver historial de reproducción */}
                                              <button
                                                onClick={() => {
                                                  playSynthBeep(520, 0.05);
                                                  showToast(`Escuchada ${activeOptionsTrack.plays || 0} veces`);
                                                  addLiveLog(`Historial de "${activeOptionsTrack.title}": ${activeOptionsTrack.plays || 0} reproducciones`);
                                                  setActiveOptionsTrack(null);
                                                }}
                                                className="w-full flex items-center gap-2 p-1.5 hover:bg-[#00E5FF]/10 hover:text-[#00E5FF] rounded-lg font-bold text-left transition-colors"
                                              >
                                                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                                                <span>Ver historial de reproducción</span>
                                              </button>

                                              {/* Buscar canciones similares */}
                                              <button
                                                onClick={() => {
                                                  playSynthBeep(520, 0.05);
                                                  setSearchQuery(activeOptionsTrack.genre);
                                                  setLibraryTab("canciones");
                                                  showToast(`Filtro por género: ${activeOptionsTrack.genre}`);
                                                  setActiveOptionsTrack(null);
                                                }}
                                                className="w-full flex items-center gap-2 p-1.5 hover:bg-[#00E5FF]/10 hover:text-[#00E5FF] rounded-lg font-bold text-left transition-colors"
                                              >
                                                <Compass className="w-3.5 h-3.5 text-pink-500" />
                                                <span>Buscar canciones similares</span>
                                              </button>

                                              {/* Buscar más canciones del mismo artista */}
                                              <button
                                                onClick={() => {
                                                  playSynthBeep(520, 0.05);
                                                  setSearchQuery(activeOptionsTrack.artist);
                                                  setLibraryTab("canciones");
                                                  showToast(`Filtro por artista: ${activeOptionsTrack.artist}`);
                                                  setActiveOptionsTrack(null);
                                                }}
                                                className="w-full flex items-center gap-2 p-1.5 hover:bg-[#00E5FF]/10 hover:text-[#00E5FF] rounded-lg font-bold text-left transition-colors"
                                              >
                                                <User className="w-3.5 h-3.5 text-[#00E5FF]" />
                                                <span>Buscar más canciones del mismo artista</span>
                                              </button>

                                              {/* Actualizar información multimedia */}
                                              <button
                                                onClick={() => {
                                                  playSynthBeep(600, 0.05);
                                                  showToast("Actualizando información en red...");
                                                  setTimeout(() => {
                                                    playSynthBeep(880, 0.08);
                                                    showToast("Información multimedia actualizada!");
                                                  }, 600);
                                                  setActiveOptionsTrack(null);
                                                }}
                                                className="w-full flex items-center gap-2 p-1.5 hover:bg-[#00E5FF]/10 hover:text-[#00E5FF] rounded-lg font-bold text-left transition-colors"
                                              >
                                                <RefreshCw className="w-3.5 h-3.5 text-indigo-400" />
                                                <span>Actualizar información multimedia</span>
                                              </button>
                                            </div>
                                          )}

                                        </div>
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            </motion.div>
                          </>
                        )}
                      </AnimatePresence>
                      
                      {/* VIEW 1: BIBLIOTECA */}
                      {mobileTab === "biblioteca" && (
                        <div className="animate-fadeIn flex flex-col h-full">
                          {/* REDESIGNED PREMIUM TOP BAR */}
                          <div className={`flex items-center justify-between py-2 border-b sticky top-0 z-30 transition-colors select-none ${
                            isMobileLightMode ? "border-slate-100 bg-white/90 backdrop-blur" : "border-gray-900/40 bg-[#090d15]/95 backdrop-blur"
                          }`}>
                            <button
                              onClick={() => {
                                playSynthBeep(450, 0.05);
                                setIsDrawerOpen(true);
                              }}
                              className={`p-1.5 rounded-xl transition-all ${
                                isMobileLightMode ? "hover:bg-slate-100 text-slate-800" : "hover:bg-cyan-950/20 text-gray-300 hover:text-[#00E5FF]"
                              }`}
                              title="Menú Lateral"
                            >
                              <Menu className="w-5 h-5" />
                            </button>
                            
                            <div className="flex flex-col items-center">
                              <h2 className={`text-[13px] font-black tracking-tight flex items-center gap-1.5 ${
                                isMobileLightMode ? "text-slate-900" : "text-white"
                              }`}>
                                <span className="bg-gradient-to-r from-[#00E5FF] to-blue-500 bg-clip-text text-transparent">¿UNAS ROLITAS?</span>
                              </h2>
                              <span className="text-[7.5px] text-gray-500 font-mono uppercase tracking-wider font-semibold">REPRODUCTOR DE AUDIO</span>
                            </div>

                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => {
                                  playSynthBeep(450, 0.05);
                                  setMobileTab("buscar");
                                }}
                                className={`p-1.5 rounded-xl transition-all ${
                                  isMobileLightMode ? "hover:bg-slate-100 text-slate-800" : "hover:bg-cyan-950/20 text-gray-300 hover:text-[#00E5FF]"
                                }`}
                                title="Buscar"
                              >
                                <Search className="w-4.5 h-4.5" />
                              </button>
                            </div>
                          </div>

                          {/* SCROLLABLE HORIZONTAL NAVIGATION TABS - MODERN GAUGE LOOK */}
                          <div className={`py-3 overflow-x-auto flex gap-2 scrollbar-none sticky top-[42px] z-30 select-none shrink-0 ${
                            isMobileLightMode ? "bg-white" : "bg-transparent"
                          }`}>
                            {[
                              { id: "canciones", label: "Canciones" },
                              { id: "playlists", label: "Listas de reproducción" },
                              { id: "carpetas", label: "Carpetas" },
                              { id: "albumes", label: "Álbumes" },
                              { id: "artistas", label: "Artistas" },
                              { id: "generos", label: "Géneros" },
                              { id: "favoritos", label: "Favoritas" },
                              { id: "mas_reproducidas", label: "Más escuchadas" },
                              { id: "recientes", label: "Recientes" },
                              { id: "historial", label: "Historial" }
                            ].map((tab) => {
                              const isActive = libraryTab === tab.id;
                              return (
                                <button
                                  key={tab.id}
                                  onClick={() => {
                                    playSynthBeep(480 + (tab.id.charCodeAt(0) % 80), 0.04);
                                    setLibraryTab(tab.id);
                                    setActivePlaylistName(null); // Reset nesting
                                  }}
                                  className={`text-[10px] px-4 py-1.5 rounded-xl border shrink-0 transition-all font-black tracking-tight ${
                                    isActive 
                                      ? isMobileLightMode 
                                        ? "bg-cyan-50 text-cyan-600 border-cyan-200 shadow-sm" 
                                        : "bg-[#00E5FF]/10 text-[#00E5FF] border-[#00E5FF]/30 shadow-[0_0_12px_rgba(0,229,255,0.05)]"
                                      : isMobileLightMode 
                                        ? "bg-slate-100 text-slate-500 border-transparent hover:text-slate-800" 
                                        : "bg-[#090d15]/50 text-gray-400 border-transparent hover:text-gray-200"
                                  }`}
                                >
                                  {tab.label}
                                </button>
                              );
                            })}
                          </div>

                          {/* PREMIUM ACTION CONTROLS & SCALABILITY PANEL */}
                          <div className="flex items-center justify-between mb-3.5 select-none shrink-0 gap-2">
                            <div className="flex items-center gap-1.5">
                              <button
                                onClick={() => {
                                  playSynthBeep(650, 0.1, "triangle");
                                  const list = getProcessedTracks();
                                  if (list.length > 0) {
                                    setShuffleOn(true);
                                    const randIdx = Math.floor(Math.random() * list.length);
                                    playTrackFromLibrary(list[randIdx], list);
                                    showToast("Reproducción aleatoria iniciada");
                                  } else {
                                    showToast("No hay canciones disponibles");
                                  }
                                }}
                                className="flex items-center gap-1.5 bg-gradient-to-r from-[#00E5FF] to-blue-500 text-black text-[9.5px] font-black px-4 py-2 rounded-xl shadow-lg hover:brightness-110 active:scale-95 transition-all"
                              >
                                <Shuffle className="w-3.5 h-3.5" />
                                <span>REPRODUCIR TODO ALEATORIAMENTE</span>
                              </button>
                            </div>

                            <div className="flex items-center gap-1">
                              {/* Future Expansion: Equalizer Shortcut */}
                              <button
                                onClick={() => {
                                  playSynthBeep(700, 0.08);
                                  showToast("Ajuste de Audio (Próximamente)");
                                }}
                                className={`p-2 rounded-xl border transition-all ${
                                  isMobileLightMode ? "bg-slate-100 border-slate-200 text-slate-600" : "bg-[#0c1018] border-gray-900/40 text-gray-400 hover:text-[#00E5FF]"
                                }`}
                                title="Ecualizador Avanzado"
                              >
                                <Sliders className="w-3.5 h-3.5" />
                              </button>

                              {/* Sorting Trigger */}
                              <div className="relative">
                                <button
                                  onClick={() => {
                                    playSynthBeep(520, 0.05);
                                    setIsSortDropdownOpen(!isSortDropdownOpen);
                                  }}
                                  className={`flex items-center gap-1.5 text-[9px] font-black py-2 px-3 rounded-xl border ${
                                    isMobileLightMode 
                                      ? "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200" 
                                      : "bg-[#0c1018] border-gray-900/40 text-gray-300 hover:text-white"
                                  } transition-all`}
                                >
                                  <SlidersHorizontal className="w-3.5 h-3.5 text-[#00E5FF]" />
                                  <span>ORDENAR</span>
                                </button>

                                {/* Sorting dropdown menu */}
                                {isSortDropdownOpen && (
                                  <div className={`absolute right-0 mt-1 w-36 rounded-xl border p-1.5 shadow-2xl z-40 transition-all ${
                                    isMobileLightMode ? "bg-white border-slate-200 text-slate-800" : "bg-[#090d15] border-gray-900/40 text-gray-300"
                                  }`}>
                                    {[
                                      { id: "titulo_az", label: "Título (A-Z)" },
                                      { id: "titulo_za", label: "Título (Z-A)" },
                                      { id: "artista_az", label: "Artista (A-Z)" },
                                      { id: "artista_za", label: "Artista (Z-A)" },
                                      { id: "album_az", label: "Álbum (A-Z)" },
                                      { id: "album_za", label: "Álbum (Z-A)" },
                                      { id: "duracion_corta", label: "Duración (Corta)" },
                                      { id: "duracion_larga", label: "Duración (Larga)" },
                                      { id: "tamano", label: "Tamaño" },
                                      { id: "reproducciones", label: "Escuchadas" },
                                      { id: "fecha_reciente", label: "Recientes" }
                                    ].map((opt) => (
                                      <button
                                        key={opt.id}
                                        onClick={() => {
                                          playSynthBeep(500, 0.04);
                                          setSortBy(opt.id);
                                          setIsSortDropdownOpen(false);
                                          showToast(`Orden: ${opt.label}`);
                                        }}
                                        className={`w-full text-left text-[9px] px-2.5 py-1.5 rounded-lg hover:bg-[#00E5FF]/10 hover:text-[#00E5FF] font-black block truncate transition-colors ${
                                          sortBy === opt.id ? "text-[#00E5FF] bg-[#00E5FF]/10" : ""
                                        }`}
                                      >
                                        {opt.label}
                                      </button>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* DYNAMIC TAB BODY */}
                          <div className="space-y-2.5 flex-1 pb-4">
                            {/* Playlists view */}
                            {libraryTab === "playlists" && !activePlaylistName && (
                              <div className="space-y-3 animate-fadeIn">
                                <div className="grid grid-cols-2 gap-2.5">
                                  {Object.keys(playlists).map((playlistName) => {
                                    const songsCount = playlists[playlistName].length;
                                    return (
                                      <div
                                        key={playlistName}
                                        onClick={() => {
                                          playSynthBeep(530, 0.05);
                                          setActivePlaylistName(playlistName);
                                        }}
                                        className={`p-3 rounded-2xl border transition-all cursor-pointer ${
                                          isMobileLightMode ? "bg-white border-slate-200 hover:bg-slate-50" : "bg-[#0d1321] border-[#0f1420] hover:bg-[#12192c]"
                                        }`}
                                      >
                                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 flex items-center justify-center mb-2">
                                          <ListMusic className="w-5 h-5 text-[#00E5FF]" />
                                        </div>
                                        <h4 className={`text-xs font-black truncate ${isMobileLightMode ? "text-slate-950" : "text-white"}`}>{playlistName}</h4>
                                        <p className="text-[9px] text-gray-500 font-mono mt-0.5">{songsCount} rolitas</p>
                                      </div>
                                    );
                                  })}

                                  {/* Create New Playlist button */}
                                  <div
                                    onClick={() => {
                                      playSynthBeep(600, 0.08);
                                      const pName = prompt("Ingresa el nombre de la nueva lista de reproducción:");
                                      if (pName && pName.trim()) {
                                        if (playlists[pName]) {
                                          showToast("Esa lista ya existe");
                                        } else {
                                          setPlaylists({ ...playlists, [pName.trim()]: [] });
                                          showToast(`Lista "${pName}" creada`);
                                        }
                                      }
                                    }}
                                    className={`p-3 rounded-2xl border border-dashed flex flex-col items-center justify-center transition-all cursor-pointer ${
                                      isMobileLightMode ? "bg-slate-100 border-slate-300 text-slate-600 hover:bg-slate-200" : "bg-black/20 border-[#151c2d] text-gray-400 hover:text-[#00E5FF] hover:border-[#00E5FF]/40"
                                    }`}
                                  >
                                    <Plus className="w-5 h-5 mb-1 text-[#00E5FF]" />
                                    <span className="text-[9px] font-black uppercase">CREAR NUEVA</span>
                                  </div>
                                </div>
                              </div>
                            )}

                            {/* Nested view inside a single playlist */}
                            {libraryTab === "playlists" && activePlaylistName && (
                              <div className="animate-fadeIn">
                                <div className="flex items-center gap-1.5 mb-3 pb-2 border-b border-dashed border-gray-800/10">
                                  <button
                                    onClick={() => {
                                      playSynthBeep(450, 0.04);
                                      setActivePlaylistName(null);
                                    }}
                                    className="text-[9px] font-black bg-cyan-950/40 text-[#00E5FF] border border-cyan-900/40 px-2 py-0.5 rounded-full"
                                  >
                                    ← Volver
                                  </button>
                                  <span className={`text-xs font-black ${isMobileLightMode ? "text-slate-900" : "text-white"}`}>
                                    Lista: {activePlaylistName}
                                  </span>
                                </div>
                                {getProcessedTracks().length === 0 ? (
                                  <p className="text-center py-6 text-[10px] text-gray-500 font-mono">Esta lista de reproducción está vacía.</p>
                                ) : null}
                              </div>
                            )}

                            {/* Folders view */}
                            {libraryTab === "carpetas" && (
                              <div className="space-y-2 animate-fadeIn">
                                {[
                                  { path: "/storage/Music/Descargas", count: 3 },
                                  { path: "/storage/Music/Clásicos", count: 2 },
                                  { path: "/storage/Music/Grabaciones", count: 0 }
                                ].map((fold) => (
                                  <div
                                    key={fold.path}
                                    onClick={() => {
                                      playSynthBeep(490, 0.05);
                                      showToast(`Abriendo carpeta: ${fold.path}`);
                                    }}
                                    className={`p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                                      isMobileLightMode ? "bg-white border-slate-200 hover:bg-slate-50" : "bg-[#0c1018] border-[#0f1420] hover:bg-[#12192c]"
                                    }`}
                                  >
                                    <div className="flex items-center gap-2.5 min-w-0">
                                      <Folder className="w-4 h-4 text-amber-500 fill-amber-500/25 shrink-0" />
                                      <div className="min-w-0">
                                        <h4 className={`text-xs font-bold truncate ${isMobileLightMode ? "text-slate-950" : "text-white"}`}>{fold.path.split("/").pop()}</h4>
                                        <p className="text-[9px] text-gray-500 font-mono truncate">{fold.path}</p>
                                      </div>
                                    </div>
                                    <span className="text-[9px] font-mono text-gray-500 bg-black/40 border border-gray-800/40 px-2.5 py-0.5 rounded-full shrink-0">
                                      {fold.count} MP3
                                    </span>
                                  </div>
                                ))}
                              </div>
                            )}

                            {/* Albums view */}
                            {libraryTab === "albumes" && (
                              <div className="grid grid-cols-2 gap-2.5 animate-fadeIn">
                                {Array.from(new Set(tracks.map(t => t.album))).map((albumName) => {
                                  const matchingSongs = tracks.filter(t => t.album === albumName);
                                  return (
                                    <div
                                      key={albumName}
                                      onClick={() => {
                                        playSynthBeep(520, 0.05);
                                        showToast(`Álbum: ${albumName}`);
                                      }}
                                      className={`p-2.5 rounded-2xl border transition-all cursor-pointer ${
                                        isMobileLightMode ? "bg-white border-slate-200 hover:bg-slate-50" : "bg-[#0d1321] border-[#0f1420] hover:bg-[#12192c]"
                                      }`}
                                    >
                                      <div className="w-full aspect-square rounded-xl bg-gradient-to-tr from-slate-950 to-black border border-gray-850 flex items-center justify-center mb-2 relative overflow-hidden shadow-inner group">
                                        <div className="absolute inset-2.5 rounded-full border border-gray-800/40 flex items-center justify-center">
                                          <div className="w-8 h-8 rounded-full bg-[#00E5FF]/10 flex items-center justify-center">
                                            <Music className="w-4 h-4 text-[#00E5FF]/50" />
                                          </div>
                                        </div>
                                      </div>
                                      <h4 className={`text-xs font-black truncate ${isMobileLightMode ? "text-slate-950" : "text-white"}`}>{albumName}</h4>
                                      <p className="text-[9px] text-gray-500 truncate mt-0.5">{matchingSongs[0]?.artist || "Varios artistas"}</p>
                                    </div>
                                  );
                                })}
                              </div>
                            )}

                            {/* Artists view */}
                            {libraryTab === "artistas" && (
                              <div className="space-y-2 animate-fadeIn">
                                {Array.from(new Set(tracks.map(t => t.artist))).map((artName) => {
                                  const songCount = tracks.filter(t => t.artist === artName).length;
                                  return (
                                    <div
                                      key={artName}
                                      onClick={() => {
                                        playSynthBeep(510, 0.05);
                                        showToast(`Artista: ${artName}`);
                                      }}
                                      className={`p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                                        isMobileLightMode ? "bg-white border-slate-200 hover:bg-slate-50" : "bg-[#0c1018] border-[#0f1420] hover:bg-[#12192c]"
                                      }`}
                                    >
                                      <div className="flex items-center gap-2.5">
                                        <div className="w-8 h-8 rounded-full bg-cyan-950/40 border border-cyan-800/40 flex items-center justify-center">
                                          <User className="w-4 h-4 text-[#00E5FF]" />
                                        </div>
                                        <div>
                                          <h4 className={`text-xs font-bold ${isMobileLightMode ? "text-slate-950" : "text-white"}`}>{artName}</h4>
                                          <p className="text-[9px] text-gray-500 font-mono">{songCount} rolitas locales</p>
                                        </div>
                                      </div>
                                      <ChevronRight className="w-3.5 h-3.5 text-gray-600" />
                                    </div>
                                  );
                                })}
                              </div>
                            )}

                            {/* Genres view */}
                            {libraryTab === "generos" && (
                              <div className="grid grid-cols-2 gap-2 animate-fadeIn">
                                {Array.from(new Set(tracks.map(t => t.genre))).map((genreName) => (
                                  <div
                                    key={genreName}
                                    onClick={() => {
                                      playSynthBeep(480, 0.05);
                                      showToast(`Género: ${genreName}`);
                                    }}
                                    className={`p-3 rounded-xl border transition-all cursor-pointer text-center ${
                                      isMobileLightMode ? "bg-white border-slate-200 hover:bg-slate-50" : "bg-[#0c1018] border-[#0f1420] hover:bg-[#12192c]"
                                    }`}
                                  >
                                    <Compass className="w-5 h-5 text-[#FF007F] mx-auto mb-1.5" />
                                    <span className={`text-[10px] font-black ${isMobileLightMode ? "text-slate-800" : "text-gray-200"}`}>{genreName}</span>
                                  </div>
                                ))}
                              </div>
                            )}

                            {/* Podcasts view */}
                            {libraryTab === "podcasts" && (
                              <div className="space-y-2 animate-fadeIn">
                                {[
                                  { title: "Charla Semanal Android", ep: "Ep. 42 - ExoPlayer vs Media3", duration: "45 min" },
                                  { title: "El Algoritmo de la Música", ep: "Ep. 15 - El encanto analógico", duration: "58 min" }
                                ].map((pod) => (
                                  <div
                                    key={pod.title}
                                    onClick={() => {
                                      playSynthBeep(600, 0.05);
                                      showToast(`Reproduciendo podcast: ${pod.title}`);
                                    }}
                                    className={`p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                                      isMobileLightMode ? "bg-white border-slate-200 hover:bg-slate-50" : "bg-[#0c1018] border-[#0f1420] hover:bg-[#12192c]"
                                    }`}
                                  >
                                    <div className="flex items-center gap-2.5 min-w-0">
                                      <div className="w-8 h-8 rounded bg-[#FF007F]/10 flex items-center justify-center border border-[#FF007F]/20 shrink-0">
                                        <Radio className="w-4 h-4 text-[#FF007F]" />
                                      </div>
                                      <div className="min-w-0">
                                        <h4 className={`text-xs font-bold truncate ${isMobileLightMode ? "text-slate-950" : "text-white"}`}>{pod.title}</h4>
                                        <p className="text-[9px] text-gray-500 font-mono truncate">{pod.ep}</p>
                                      </div>
                                    </div>
                                    <span className="text-[9px] font-mono text-gray-500 shrink-0">{pod.duration}</span>
                                  </div>
                                ))}
                              </div>
                            )}

                            {/* Audiobooks view */}
                            {libraryTab === "audiolibros" && (
                              <div className="space-y-2 animate-fadeIn">
                                {[
                                  { title: "Don Quijote de la Mancha", chap: "Capítulo I - El hidalgo", duration: "12 min" },
                                  { title: "El Principito", chap: "Narración completa para dormir", duration: "1 h 14 min" }
                                ].map((bk) => (
                                  <div
                                    key={bk.title}
                                    onClick={() => {
                                      playSynthBeep(580, 0.05);
                                      showToast(`Reproduciendo audiolibro: ${bk.title}`);
                                    }}
                                    className={`p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                                      isMobileLightMode ? "bg-white border-slate-200 hover:bg-slate-50" : "bg-[#0c1018] border-[#0f1420] hover:bg-[#12192c]"
                                    }`}
                                  >
                                    <div className="flex items-center gap-2.5 min-w-0">
                                      <div className="w-8 h-8 rounded bg-[#00E5FF]/10 flex items-center justify-center border border-[#00E5FF]/20 shrink-0">
                                        <FileText className="w-4 h-4 text-[#00E5FF]" />
                                      </div>
                                      <div className="min-w-0">
                                        <h4 className={`text-xs font-bold truncate ${isMobileLightMode ? "text-slate-950" : "text-white"}`}>{bk.title}</h4>
                                        <p className="text-[9px] text-gray-500 font-mono truncate">{bk.chap}</p>
                                      </div>
                                    </div>
                                    <span className="text-[9px] font-mono text-gray-500 shrink-0">{bk.duration}</span>
                                  </div>
                                ))}
                              </div>
                            )}

                            {/* Render matching songs for relevant tabs */}
                            {libraryTab !== "playlists" && libraryTab !== "carpetas" && libraryTab !== "albumes" && libraryTab !== "artistas" && libraryTab !== "generos" && libraryTab !== "podcasts" && libraryTab !== "audiolibros" && (
                              <div className="space-y-2 animate-fadeIn">
                                {filteredTracks.length > 0 ? (
                                  filteredTracks.map((track) => {
                                    const isCurrent = currentTrack.title === track.title;
                                    const trColors = getTrackColors(track);
                                    return (
                                      <div
                                        key={track.title}
                                        onClick={() => {
                                          playTrackFromLibrary(track, filteredTracks);
                                        }}
                                        className={`flex items-center justify-between p-2.5 rounded-2xl border transition-all cursor-pointer ${
                                          isCurrent
                                            ? isMobileLightMode
                                              ? "bg-[#00E5FF]/5 border-[#00E5FF]/40 shadow-sm"
                                              : "bg-cyan-950/20 border-[#00E5FF]/40 shadow-[0_0_15px_rgba(0,229,255,0.04)]"
                                            : isMobileLightMode 
                                              ? "bg-white border-slate-100 hover:bg-slate-50 hover:border-slate-200" 
                                              : "bg-[#0a0e17] border-gray-950/60 hover:bg-[#101625] hover:border-gray-900/40"
                                        } hover:scale-[1.01] active:scale-[0.99]`}
                                      >
                                        <div className="flex items-center gap-3 min-w-0">
                                          {/* Square rounded album art style thumbnail with dynamic glow color */}
                                          <div 
                                            className={`w-10 h-10 rounded-xl flex items-center justify-center border shrink-0 relative overflow-hidden transition-all duration-350 ${
                                              isCurrent 
                                                ? "scale-105" 
                                                : "scale-100"
                                            }`}
                                            style={{
                                              background: isCurrent 
                                                ? `radial-gradient(circle at center, ${trColors.glow}20, #000000)` 
                                                : 'radial-gradient(circle at center, #1b253b, #090d15)',
                                              borderColor: isCurrent ? trColors.glow : 'transparent',
                                              boxShadow: isCurrent ? `0 0 10px ${trColors.glow}30` : 'none'
                                            }}
                                          >
                                            {isCurrent && isPlaying ? (
                                              /* Animated soundwaves */
                                              <div className="flex items-end gap-0.5 h-3">
                                                <div className="w-0.5 bg-[#00E5FF] animate-music-bar-1" style={{ backgroundColor: trColors.glow }} />
                                                <div className="w-0.5 bg-[#00E5FF] animate-music-bar-2" style={{ backgroundColor: trColors.glow }} />
                                                <div className="w-0.5 bg-[#00E5FF] animate-music-bar-3" style={{ backgroundColor: trColors.glow }} />
                                              </div>
                                            ) : (
                                              /* Vinyl disk replica with spindle hole */
                                              <div className="absolute inset-0.5 rounded-full border border-white/5 flex items-center justify-center bg-black animate-spin-slow">
                                                <div className="w-5 h-5 rounded-full border border-dashed border-white/10 flex items-center justify-center" style={{ borderColor: `${trColors.glow}20` }}>
                                                  <div className="w-2 h-2 rounded-full bg-[#090d15] border border-white/5 flex items-center justify-center">
                                                    <div className="w-0.5 h-0.5 rounded-full bg-white/40" />
                                                  </div>
                                                </div>
                                              </div>
                                            )}
                                          </div>

                                          <div className="min-w-0">
                                            <h4 
                                              className={`text-xs font-black truncate transition-colors ${
                                                isCurrent 
                                                  ? "text-[#00E5FF]" 
                                                  : isMobileLightMode 
                                                    ? "text-slate-900" 
                                                    : "text-gray-100"
                                              }`}
                                              style={{ color: isCurrent ? trColors.glow : undefined }}
                                            >
                                              {track.title}
                                            </h4>
                                            
                                            <div className="flex items-center gap-1.5 mt-0.5">
                                              <p className="text-[9px] text-gray-500 truncate font-mono">
                                                {track.artist} <span className="text-gray-600/60">•</span> {track.album}
                                              </p>
                                              
                                              {/* Custom tag chips if available */}
                                              {track.customTags && track.customTags.slice(0, 1).map((tg: string) => (
                                                <span key={tg} className="bg-cyan-950/40 text-[#00E5FF] px-1 rounded-[4px] text-[7px] font-mono border border-[#00E5FF]/20 uppercase">
                                                  #{tg}
                                                </span>
                                              ))}
                                            </div>
                                          </div>
                                        </div>

                                        <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                                          <button
                                            onClick={(e) => toggleFavorite(track.title, e)}
                                            className="p-1.5 hover:bg-black/10 rounded-lg transition-all"
                                            title="Favorito"
                                          >
                                            <Heart className={`w-3.5 h-3.5 transition-colors ${favoriteSongs.includes(track.title) ? 'text-[#FF007F] fill-[#FF007F]' : 'text-gray-500 hover:text-gray-300'}`} />
                                          </button>
                                          
                                          {/* THREE DOTS MENU TRIGGER */}
                                          <button
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setActiveOptionsTrack(track);
                                              setExpandedCategory(null); // Reset option sheet accordions
                                              setEditingField(null);
                                              setIsConverting(false);
                                              setIsAnalyzing(false);
                                              setAnalysisResult(null);
                                            }}
                                            className="p-1.5 hover:bg-black/10 rounded-lg transition-all text-gray-500 hover:text-gray-300"
                                            title="Opciones"
                                          >
                                            <MoreVertical className="w-4 h-4" />
                                          </button>
                                        </div>
                                      </div>
                                    );
                                  })
                                ) : (
                                  <div className="text-center py-10 text-gray-500 text-[10px] font-mono leading-relaxed">
                                    No hay rolitas en esta sección o fueron ocultadas / añadidas a la lista negra.
                                  </div>
                                )}
                              </div>
                            )}

                          </div>
                        </div>
                      )}

                      {/* VIEW 2: BUSCAR */}
                      {mobileTab === "buscar" && (
                        <div className="animate-fadeIn flex flex-col h-full">
                          {/* TOP BAR */}
                          <div className="flex items-center justify-between py-2 border-b border-gray-800/10 sticky top-0 z-30 transition-colors select-none mb-3">
                            <button
                              onClick={() => {
                                playSynthBeep(450, 0.05);
                                setIsDrawerOpen(true);
                              }}
                              className={`p-1.5 rounded-lg transition-all ${
                                isMobileLightMode ? "hover:bg-slate-200 text-slate-700" : "hover:bg-[#131a26] text-gray-300"
                              }`}
                            >
                              <Menu className="w-5 h-5" />
                            </button>
                            <h2 className={`text-sm font-black tracking-tight ${isMobileLightMode ? "text-slate-900" : "text-white"}`}>
                              BUSCAR MÚSICA
                            </h2>
                            <button
                              onClick={() => {
                                playSynthBeep(450, 0.05);
                                setMobileTab("biblioteca");
                              }}
                              className={`p-1.5 rounded-lg transition-all ${
                                isMobileLightMode ? "hover:bg-slate-200 text-slate-700" : "hover:bg-[#131a26] text-gray-300"
                              }`}
                            >
                              <ArrowLeft className="w-4.5 h-4.5" />
                            </button>
                          </div>
                          
                          {/* Simulated Search input */}
                          <div className="relative mb-4">
                            <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-gray-500" />
                            <input
                              type="text"
                              value={searchQuery}
                              onChange={(e) => setSearchQuery(e.target.value)}
                              placeholder="Filtra por título, artista..."
                              className="w-full bg-[#0c1018] border border-[#0f1420] text-xs text-white rounded-xl py-2 pl-9 pr-8 outline-none focus:border-[#00E5FF]/40 font-medium transition-all"
                            />
                            {searchQuery && (
                              <button 
                                onClick={() => setSearchQuery("")}
                                className="absolute right-2.5 top-2 text-[10px] bg-[#1a202c] text-gray-400 px-1.5 py-0.5 rounded-md hover:text-white"
                              >
                                borrar
                              </button>
                            )}
                          </div>

                          {/* Filtered list */}
                          <div className="space-y-2">
                            {filteredTracks.length > 0 ? (
                              filteredTracks.map((track) => {
                                const idx = simulatedTracks.indexOf(track);
                                const isCurrent = currentTrackIndex === idx;
                                return (
                                  <div
                                    key={track.title}
                                    onClick={() => {
                                      playTrackFromLibrary(track, filteredTracks);
                                    }}
                                    className={`flex items-center justify-between p-2.5 rounded-xl border cursor-pointer ${
                                      isCurrent 
                                        ? "bg-[#00E5FF]/5 border-[#00E5FF]/20" 
                                        : "bg-[#0c1018] border-[#0f1420] hover:bg-[#101522]"
                                    }`}
                                  >
                                    <div className="flex items-center gap-2.5">
                                      <div className="w-7 h-7 rounded bg-black/40 flex items-center justify-center">
                                        <Music className="w-3.5 h-3.5 text-gray-500" />
                                      </div>
                                      <div>
                                        <h4 className="text-xs font-bold text-gray-200">{track.title}</h4>
                                        <p className="text-[10px] text-gray-500">{track.artist}</p>
                                      </div>
                                    </div>
                                    <span className="text-[9px] font-mono text-gray-500">{track.duration}</span>
                                  </div>
                                );
                              })
                            ) : (
                              <div className="text-center py-10 text-gray-500 text-xs font-medium">
                                No se encontraron canciones para tu búsqueda.
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* VIEW 3: AJUSTES */}
                      {mobileTab === "ajustes" && (
                        <div className="animate-fadeIn space-y-5 flex flex-col h-full overflow-y-auto pb-28 scrollbar-none select-none">
                            {/* TOP BAR */}
                            <div className="flex items-center justify-between py-2.5 border-b border-gray-800/10 sticky top-0 z-30 bg-[#060911]/90 backdrop-blur-md transition-colors select-none mb-1">
                              <button
                                onClick={() => {
                                  playSynthBeep(450, 0.05);
                                  setIsDrawerOpen(true);
                                }}
                                className={`p-2 rounded-xl transition-all ${
                                  isMobileLightMode ? "hover:bg-slate-200 text-slate-700" : "hover:bg-[#131a26] text-gray-300"
                                }`}
                              >
                                <Menu className="w-5 h-5" />
                              </button>
                              <div className="text-center">
                                <h2 className={`text-xs font-black tracking-widest ${isMobileLightMode ? "text-slate-900" : "text-white"} uppercase flex items-center justify-center gap-1.5`}>
                                  <span className={`w-1.5 h-1.5 rounded-full ${themeColorBg} animate-ping`} />
                                  AJUSTES
                                </h2>
                                <p className="text-[9px] text-gray-500 font-bold mt-0.5">Personaliza la aplicación a tu manera.</p>
                              </div>
                              <button
                                onClick={() => {
                                  playSynthBeep(450, 0.05);
                                  setMobileTab("biblioteca");
                                }}
                                className={`p-2 rounded-xl transition-all ${
                                  isMobileLightMode ? "hover:bg-slate-200 text-slate-700" : "hover:bg-[#131a26] text-gray-300"
                                }`}
                              >
                                <ArrowLeft className="w-4.5 h-4.5" />
                              </button>
                            </div>

                            {/* ACCIONES RÁPIDAS (CONTROL CENTER STYLE) */}
                            <div className={`rounded-3xl p-4.5 space-y-3.5 shadow-xl border transition-all duration-300 ${
                              isMobileLightMode ? "bg-white border-slate-100" : "bg-[#0a0d16]/80 border-white/5"
                            }`}
                            style={{
                              boxShadow: isMobileLightMode 
                                ? "0 10px 25px -5px rgba(0,0,0,0.05)" 
                                : `0 15px 30px -10px rgba(0,0,0,0.6), 0 0 15px ${themeColorHex}05`
                            }}>
                              <div className="flex items-center justify-between border-b border-gray-800/10 pb-2.5">
                                <h3 className="text-[10px] font-black tracking-wider text-gray-400 uppercase flex items-center gap-2">
                                  <Zap className={`w-4 h-4 ${themeColorText}`} /> ACCIONES RÁPIDAS
                                </h3>
                                <span className={`text-[8px] font-mono font-black uppercase px-2 py-0.5 rounded-md ${
                                  isMobileLightMode ? "bg-slate-100 text-slate-600" : "bg-white/5 text-gray-400"
                                }`}>
                                  Centro de Control
                                </span>
                              </div>

                              <div className="grid grid-cols-2 gap-2.5">
                                {quickActionsList.map((action) => {
                                  const ActionIcon = action.icon;
                                  return (
                                    <button
                                      key={action.id}
                                      onClick={action.onToggle}
                                      className={`flex items-center justify-between p-3 rounded-2xl border transition-all duration-300 text-left relative overflow-hidden group select-none hover:scale-[1.015] active:scale-[0.985] ${
                                        action.active
                                          ? isMobileLightMode 
                                            ? "bg-slate-50 border-slate-200" 
                                            : "bg-white/[0.03] border-white/10"
                                          : isMobileLightMode 
                                            ? "bg-white border-slate-100 opacity-60 hover:opacity-100" 
                                            : "bg-black/10 border-white/5 opacity-55 hover:opacity-85"
                                      }`}
                                      style={{
                                        boxShadow: action.active && !isMobileLightMode
                                          ? `inset 0 0 12px ${themeColorHex}10`
                                          : undefined
                                      }}
                                    >
                                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                                        <div className={`p-2 rounded-xl shrink-0 transition-all duration-300 ${
                                          action.active 
                                            ? `${themeColorBg} text-black font-black` 
                                            : isMobileLightMode ? "bg-slate-100 text-slate-500" : "bg-white/5 text-gray-400"
                                        }`}>
                                          <ActionIcon className="w-3.5 h-3.5" />
                                        </div>
                                        <div className="flex flex-col min-w-0">
                                          <span className={`text-[10px] font-black uppercase tracking-wider ${
                                            isMobileLightMode ? "text-slate-800" : "text-gray-200"
                                          } truncate`}>
                                            {action.name}
                                          </span>
                                          <span className={`text-[8px] font-extrabold uppercase mt-0.5 ${
                                            action.active 
                                              ? themeColorText 
                                              : "text-gray-500"
                                          }`}>
                                            {action.active ? "Activado" : "Apagado"}
                                          </span>
                                        </div>
                                      </div>

                                      {/* Tactile Pill Switch */}
                                      <div className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${
                                        action.active ? themeColorBg : "bg-gray-700/60"
                                      }`}>
                                        <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${
                                          action.active ? "translate-x-3.5" : "translate-x-0"
                                        }`} />
                                      </div>
                                    </button>
                                  );
                                })}
                              </div>
                            </div>

                            {/* CATEGORÍAS */}
                            <div className="space-y-3">
                              <div className="flex items-center justify-between px-1">
                                <h3 className="text-[10px] font-black tracking-wider text-gray-500 uppercase">CATEGORÍAS DE AJUSTES</h3>
                                <span className="text-[8px] text-gray-500 font-mono font-semibold">{settingsCategories.length} MÓDULOS</span>
                              </div>

                              <div className="grid grid-cols-1 gap-3">
                                {settingsCategories.map((cat) => {
                                  const CatIcon = cat.icon;
                                  const isSelected = activeSettingsCategory === cat.id;
                                  return (
                                    <button
                                      key={cat.id}
                                      onClick={() => {
                                        playSynthBeep(550, 0.05);
                                        setActiveSettingsCategory(isSelected ? null : cat.id);
                                      }}
                                      className={`flex items-center gap-4 w-full p-4 rounded-3xl border text-left transition-all duration-300 relative overflow-hidden group select-none hover:scale-[1.015] active:scale-[0.985] ${
                                        isMobileLightMode 
                                          ? "bg-white border-slate-100 text-slate-800 hover:shadow-xl hover:shadow-black/5" 
                                          : "bg-[#0c1018]/60 border-white/5 text-white hover:bg-[#0f1521]/80"
                                      } ${isSelected ? "ring-2 ring-cyan-400" : ""}`}
                                      style={{
                                        boxShadow: isMobileLightMode 
                                          ? "0 4px 14px -4px rgba(0,0,0,0.05), 0 0 10px rgba(0,0,0,0.02)" 
                                          : `0 4px 20px -6px rgba(0,0,0,0.3), 0 0 14px ${themeColorHex}12`
                                      }}
                                    >
                                      {/* Side theme indicator line */}
                                      <div className={`absolute left-0 top-0 bottom-0 w-1 ${themeColorBg} opacity-60 group-hover:opacity-100 group-hover:w-1.5 transition-all duration-300`} />

                                      {/* Large Category Icon */}
                                      <div className={`p-3.5 rounded-2xl shrink-0 transition-all duration-300 ${
                                        isMobileLightMode 
                                          ? "bg-slate-100 text-slate-700 group-hover:bg-slate-200" 
                                          : "bg-white/[0.04] text-gray-300 group-hover:bg-white/[0.08] group-hover:text-white"
                                      }`}>
                                        <CatIcon className="w-5.5 h-5.5 transition-transform duration-300 group-hover:scale-110" />
                                      </div>

                                      {/* Description & Dynamic Status Summary */}
                                      <div className="flex-1 min-w-0">
                                        <h4 className={`text-xs font-black uppercase tracking-wider ${
                                          isMobileLightMode ? "text-slate-900" : "text-white"
                                        } group-hover:text-[#00E5FF] transition-all`}>
                                          {cat.name}
                                        </h4>
                                        <p className="text-[10px] text-gray-500 font-medium truncate mt-0.5">
                                          {cat.desc}
                                        </p>
                                        
                                        {/* Dynamic pill container */}
                                        <div className="flex items-center gap-1.5 mt-2">
                                          <span className={`text-[8px] font-mono font-bold uppercase tracking-wider ${themeColorText} bg-white/[0.03] px-2 py-0.5 rounded-md border ${themeColorBorder}`}>
                                            {cat.sum}
                                          </span>
                                        </div>
                                      </div>

                                      {/* Chevron Right indicator */}
                                      <div className={`p-2 rounded-full transition-all duration-300 ${
                                        isMobileLightMode 
                                          ? "bg-slate-50 text-slate-400 group-hover:text-slate-700 group-hover:bg-slate-100" 
                                          : "bg-white/5 text-gray-400 group-hover:text-white group-hover:bg-white/10"
                                      } group-hover:translate-x-1 shrink-0`}>
                                        <ChevronRight className={`w-4 h-4 transition-all duration-300 ${isSelected ? "rotate-90 text-cyan-400" : ""}`} />
                                      </div>
                                    </button>
                                  );
                                })}
                              </div>
                            </div>

                          {/* OVERLAY / EXPANDED CATEGORY DRAWER MODAL */}
                          {activeSettingsCategory && (
                            <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex flex-col justify-end">
                              <div className="bg-[#080b12] border-t border-white/10 rounded-t-[2.5rem] p-6 max-h-[90%] flex flex-col space-y-4 animate-slideUp">
                                {/* Header */}
                                <div className="flex items-center justify-between pb-3 border-b border-white/5">
                                  <div>
                                    <h3 className="text-sm font-black text-white tracking-widest uppercase">
                                      {activeSettingsCategory}
                                    </h3>
                                    <p className="text-[10px] text-gray-400">Panel de Configuración Avanzado</p>
                                  </div>
                                  <button
                                    onClick={() => {
                                      playSynthBeep(350, 0.05);
                                      setActiveSettingsCategory(null);
                                    }}
                                    className="p-1.5 bg-white/5 rounded-full text-gray-400 hover:text-white"
                                  >
                                    <X className="w-5 h-5" />
                                  </button>
                                </div>

                                {/* Content Scroll Area */}
                                <div className="flex-1 overflow-y-auto space-y-4 pr-1 scrollbar-none pb-8 text-xs text-gray-300">
                                  
                                  {/* A. BIBLIOTECA */}
                                  {activeSettingsCategory === "biblioteca" && (
                                    <div className="space-y-4 animate-fadeIn">
                                      {/* Carpetas de Música Card */}
                                      <div className={`rounded-2xl p-4 border ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase mb-3 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Carpetas de Música</h4>
                                        <div className="space-y-2">
                                          {musicFolders.map((fold, idx) => (
                                            <div key={idx} className={`flex items-center justify-between p-3 rounded-xl border text-[10px] font-mono ${
                                              isMobileLightMode ? "bg-slate-100/80 border-slate-200" : "bg-black/30 border-white/5"
                                            }`}>
                                              <span className="truncate pr-4">{fold}</span>
                                              <button 
                                                onClick={() => {
                                                  playSynthBeep(350, 0.05);
                                                  setMusicFolders(prev => prev.filter((_, i) => i !== idx));
                                                  addLiveLog(`Carpeta eliminada: ${fold}`);
                                                }}
                                                className="text-red-500 font-black tracking-wider text-[9px] hover:underline shrink-0"
                                              >
                                                ELIMINAR
                                              </button>
                                            </div>
                                          ))}
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(500, 0.05);
                                              const path = prompt("Ingresa la ruta de la nueva carpeta de música:");
                                              if (path) {
                                                setMusicFolders(prev => [...prev, path]);
                                                addLiveLog(`Carpeta agregada: ${path}`);
                                                showToast("Carpeta de música agregada");
                                              }
                                            }}
                                            className={`w-full py-2.5 border border-dashed rounded-xl text-center text-[10px] font-black transition-all ${
                                              isMobileLightMode 
                                                ? "border-slate-300 text-slate-700 hover:bg-slate-100" 
                                                : "border-white/10 text-gray-400 hover:text-white hover:bg-white/5"
                                            }`}
                                          >
                                            + AGREGAR CARPETA
                                          </button>
                                        </div>
                                      </div>

                                      {/* Escaneo de Biblioteca Card */}
                                      <div className={`rounded-2xl p-4 border space-y-3.5 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <div className="flex items-center justify-between">
                                          <h4 className={`text-xs font-black tracking-wider uppercase ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Escaneo de Biblioteca</h4>
                                          <span className={`text-[8px] font-mono px-2 py-0.5 rounded-md font-bold ${isMobileLightMode ? "bg-slate-200 text-slate-600" : "bg-white/5 text-gray-400"}`}>Estadísticas</span>
                                        </div>
                                        <p className="text-[10px] text-gray-400 leading-relaxed">Escanea tus directorios para encontrar nuevos archivos de audio y sincronizar metadatos de canciones en tu reproductor.</p>
                                        
                                        {libraryScanning ? (
                                          <div className="space-y-2 bg-black/10 p-3 rounded-xl border border-white/5">
                                            <div className="flex justify-between text-[10px] font-mono">
                                              <span className={themeColorText}>{scanStepText}</span>
                                              <span className="font-bold">{scanProgress}%</span>
                                            </div>
                                            <div className="w-full h-2 bg-gray-900 rounded-full overflow-hidden">
                                              <div className={`h-full ${themeColorBg} transition-all duration-300`} style={{ width: `${scanProgress}%` }} />
                                            </div>
                                          </div>
                                        ) : (
                                          <button 
                                            onClick={() => {
                                              setLibraryScanning(true);
                                              setScanProgress(0);
                                              setScanStepText("Escaneando almacenamiento...");
                                              const steps = [
                                                { progress: 20, text: "Analizando carpetas de audio..." },
                                                { progress: 50, text: "Buscando archivos .mp3, .flac..." },
                                                { progress: 80, text: "Organizando álbumes y artistas..." },
                                                { progress: 100, text: "¡Actualización de biblioteca exitosa!" }
                                              ];
                                              steps.forEach((st, idx) => {
                                                setTimeout(() => {
                                                  setScanProgress(st.progress);
                                                  setScanStepText(st.text);
                                                  playSynthBeep(450 + idx * 40, 0.05);
                                                  if (st.progress === 100) {
                                                    setLibraryScanning(false);
                                                    showToast("Se agregó 1 canción: 'Noches de Neón'");
                                                    addLiveLog("Escaneo de biblioteca finalizado");
                                                  }
                                                }, (idx + 1) * 500);
                                              });
                                            }}
                                            className={`w-full py-3 text-black font-black rounded-xl text-center text-[10px] tracking-wider transition-all hover:scale-[1.01] active:scale-[0.99] shadow-md ${themeColorBg}`}
                                          >
                                            ESCANEAR AHORA
                                          </button>
                                        )}

                                        <div className="flex items-center justify-between border-t border-gray-800/10 pt-3 text-[11px]">
                                          <span className="font-semibold">Escaneo automático en segundo plano</span>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setAutoLibraryScan(!autoLibraryScan);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${autoLibraryScan ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${autoLibraryScan ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>
                                      </div>

                                      {/* Archivos Duplicados Card */}
                                      <div className={`rounded-2xl p-4 border space-y-3.5 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Buscar Archivos Duplicados</h4>
                                        <button 
                                          onClick={() => {
                                            playSynthBeep(520, 0.05);
                                            setDuplicatesFinderRunning(true);
                                            setTimeout(() => {
                                              setDuplicatesFinderRunning(false);
                                              setDuplicateScanCompleted(true);
                                              playSynthBeep(650, 0.08);
                                            }, 1200);
                                          }}
                                          className={`w-full py-2.5 rounded-xl text-[10px] text-center font-bold transition-all ${
                                            isMobileLightMode ? "bg-slate-200 text-slate-800 hover:bg-slate-300" : "bg-white/5 text-white hover:bg-white/10"
                                          }`}
                                        >
                                          {duplicatesFinderRunning ? "Buscando duplicados..." : "Analizar Almacenamiento"}
                                        </button>

                                        {duplicateScanCompleted && (
                                          <div className="bg-red-500/5 border border-red-500/15 rounded-xl p-3.5 space-y-2">
                                            <span className="text-[10px] text-red-400 font-bold tracking-wider flex items-center gap-1.5 uppercase">
                                              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                                              ¡Duplicados Encontrados ({foundDuplicates.length})!
                                            </span>
                                            {foundDuplicates.map((dup, i) => (
                                              <div key={i} className={`flex justify-between items-center text-[9px] font-mono p-2 rounded-lg border ${
                                                isMobileLightMode ? "bg-white border-slate-100 text-slate-700" : "bg-black/30 border-white/5 text-gray-400"
                                              }`}>
                                                <span className="truncate pr-3">{dup}</span>
                                                <button 
                                                  onClick={() => {
                                                    playSynthBeep(400, 0.05);
                                                    setFoundDuplicates(prev => prev.filter(item => item !== dup));
                                                    showToast(`Eliminado: ${dup}`);
                                                  }}
                                                  className="text-red-500 font-black hover:underline shrink-0"
                                                >
                                                  ELIMINAR
                                                </button>
                                              </div>
                                            ))}
                                          </div>
                                        )}
                                      </div>

                                      {/* Biblioteca Actions Card */}
                                      <div className="grid grid-cols-2 gap-2">
                                        <button 
                                          onClick={() => { playSynthBeep(400, 0.05); showToast("Biblioteca Actualizada"); }} 
                                          className={`py-3 rounded-xl text-[10px] font-black tracking-wider uppercase transition-all hover:scale-[1.01] active:scale-[0.99] border ${
                                            isMobileLightMode ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/5 border-white/5 text-white"
                                          }`}
                                        >
                                          Actualizar Lista
                                        </button>
                                        <button 
                                          onClick={() => { playSynthBeep(350, 0.08); showToast("Biblioteca restablecida"); }} 
                                          className={`py-3 rounded-xl text-[10px] font-black tracking-wider uppercase transition-all hover:scale-[1.01] active:scale-[0.99] border ${
                                            isMobileLightMode ? "bg-red-50 border-red-100 text-red-600" : "bg-red-500/10 border-red-500/10 text-red-400"
                                          }`}
                                        >
                                          Restablecer
                                        </button>
                                      </div>
                                    </div>
                                  )}

                                  {/* B. REPRODUCCIÓN */}
                                  {activeSettingsCategory === "reproduccion" && (
                                    <div className="space-y-4 animate-fadeIn">
                                      {/* Fundidos y Pausas Panel */}
                                      <div className={`rounded-2xl p-4 border space-y-4 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Motor de Fundidos</h4>
                                        
                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Efecto Fundido Cruzado (Crossfade)</span>
                                            <span className="text-[9px] text-gray-500">Transición suave de 4 segundos entre canciones.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setCrossfade(!crossfade);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${crossfade ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${crossfade ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Reproducción sin pausas (Gapless)</span>
                                            <span className="text-[9px] text-gray-500">Elimina el silencio molesto al final de cada canción.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setGaplessEnabled(!gaplessEnabled);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${gaplessEnabled ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${gaplessEnabled ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>
                                      </div>

                                      {/* Persistencia de Estado Panel */}
                                      <div className={`rounded-2xl p-4 border space-y-4 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Persistencia de Estado</h4>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Reanudar reproducción automática</span>
                                            <span className="text-[9px] text-gray-500">Inicia la música al abrir la aplicación.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setResumePlayAuto(!resumePlayAuto);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${resumePlayAuto ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${resumePlayAuto ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Recordar posición exacta</span>
                                            <span className="text-[9px] text-gray-500">Guarda el segundo preciso de la última canción escuchada.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setRememberPlayPos(!rememberPlayPos);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${rememberPlayPos ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${rememberPlayPos ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Nivelación ReplayGain</span>
                                            <span className="text-[9px] text-gray-500">Evita cambios bruscos de volumen entre álbumes.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setReplayGainEnabled(!replayGainEnabled);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${replayGainEnabled ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${replayGainEnabled ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>
                                      </div>

                                      {/* Velocidad, Pitch y Balance Panel */}
                                      <div className={`rounded-2xl p-4 border space-y-4.5 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Motor de Audio Avanzado</h4>

                                        <div className="space-y-1.5">
                                          <div className="flex justify-between text-[10px]">
                                            <span className="font-semibold">Balance Izquierda/Derecha</span>
                                            <span className={`font-mono font-bold ${themeColorText}`}>
                                              {audioBalance === 0 ? "Centro" : audioBalance > 0 ? `Derecha +${audioBalance}` : `Izquierda ${audioBalance}`}
                                            </span>
                                          </div>
                                          <input 
                                            type="range" min="-10" max="10" value={audioBalance} 
                                            onChange={(e) => setAudioBalance(parseInt(e.target.value))} 
                                            className={`w-full h-1.5 rounded-full outline-none transition-all ${
                                              isMobileLightMode ? "accent-slate-700 bg-slate-200" : "accent-[#00E5FF] bg-black/40"
                                            }`}
                                            style={{ accentColor: themeColorHex }}
                                          />
                                        </div>

                                        <div className={`flex justify-between items-center p-3 rounded-xl border text-[11px] ${
                                          isMobileLightMode ? "bg-slate-100/50 border-slate-200" : "bg-black/20 border-white/5"
                                        }`}>
                                          <span className="font-semibold">Canales de Salida</span>
                                          <div className="flex gap-1">
                                            <button 
                                              onClick={() => { playSynthBeep(450, 0.05); setAudioMono(false); }} 
                                              className={`px-3 py-1.5 text-[9px] rounded-lg font-black transition-all ${
                                                !audioMono 
                                                  ? `shadow-sm text-black ${themeColorBg}` 
                                                  : isMobileLightMode ? "bg-white border-slate-200 text-slate-500" : "bg-white/5 text-gray-400"
                                              }`}
                                            >
                                              Estéreo
                                            </button>
                                            <button 
                                              onClick={() => { playSynthBeep(450, 0.05); setAudioMono(true); }} 
                                              className={`px-3 py-1.5 text-[9px] rounded-lg font-black transition-all ${
                                                audioMono 
                                                  ? `shadow-sm text-black ${themeColorBg}` 
                                                  : isMobileLightMode ? "bg-white border-slate-200 text-slate-500" : "bg-white/5 text-gray-400"
                                              }`}
                                            >
                                              Mono
                                            </button>
                                          </div>
                                        </div>

                                        <div className="space-y-1.5">
                                          <div className="flex justify-between text-[10px]">
                                            <span className="font-semibold">Velocidad predeterminada</span>
                                            <span className={`font-mono font-bold ${themeColorText}`}>{playbackSpeed}x</span>
                                          </div>
                                          <input 
                                            type="range" min="0.5" max="2.5" step="0.1" value={playbackSpeed} 
                                            onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))} 
                                            className={`w-full h-1.5 rounded-full outline-none transition-all ${
                                              isMobileLightMode ? "accent-slate-700 bg-slate-200" : "accent-[#00E5FF] bg-black/40"
                                            }`}
                                            style={{ accentColor: themeColorHex }}
                                          />
                                        </div>

                                        <div className="space-y-1.5">
                                          <div className="flex justify-between text-[10px]">
                                            <span className="font-semibold">Ajuste de Tono (Pitch)</span>
                                            <span className={`font-mono font-bold ${themeColorText}`}>{pitchAdjust > 0 ? `+${pitchAdjust}` : pitchAdjust} semitonos</span>
                                          </div>
                                          <input 
                                            type="range" min="-5" max="5" value={pitchAdjust} 
                                            onChange={(e) => setPitchAdjust(parseInt(e.target.value))} 
                                            className={`w-full h-1.5 rounded-full outline-none transition-all ${
                                              isMobileLightMode ? "accent-slate-700 bg-slate-200" : "accent-[#00E5FF] bg-black/40"
                                            }`}
                                            style={{ accentColor: themeColorHex }}
                                          />
                                        </div>
                                      </div>

                                      {/* Bluetooth y Auriculares Panel */}
                                      <div className={`rounded-2xl p-4 border space-y-4 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Dispositivos Externos</h4>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Pausar al desconectar Bluetooth</span>
                                            <span className="text-[9px] text-gray-500">Evita reproducir audio por los altavoces integrados.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setPauseOnBluetoothDisconnect(!pauseOnBluetoothDisconnect);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${pauseOnBluetoothDisconnect ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${pauseOnBluetoothDisconnect ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Reanudar al conectar auriculares</span>
                                            <span className="text-[9px] text-gray-500">Inicia la reproducción de forma inteligente.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setResumeOnHeadphonesConnect(!resumeOnHeadphonesConnect);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${resumeOnHeadphonesConnect ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${resumeOnHeadphonesConnect ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                  )}

                                 {/* C. AUDIO */}
                                  {activeSettingsCategory === "audio" && (
                                    <div className="space-y-4 animate-fadeIn">
                                      {/* Complete EQ Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4.5 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <div className="flex justify-between items-center border-b border-gray-800/5 pb-2">
                                          <h4 className={`text-xs font-black tracking-wider uppercase ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Ecualizador Gráfico</h4>
                                          <span className={`text-[8px] font-mono font-black px-2 py-0.5 rounded-full ${
                                            isMobileLightMode ? "bg-slate-200 text-slate-700" : "bg-white/5 text-cyan-400"
                                          }`}>
                                            {eqPreset}
                                          </span>
                                        </div>

                                        {/* Presets List */}
                                        <div className="grid grid-cols-4 gap-1">
                                          {(["Clásico", "Bass Boost", "Vocal Boost", "Plano"] as const).map((preset) => (
                                            <button
                                              key={preset}
                                              onClick={() => applyEqPreset(preset)}
                                              className={`text-[8px] py-1.5 px-0.5 rounded-lg border font-black transition-all truncate text-center ${
                                                eqPreset === preset
                                                  ? `shadow-sm text-black border-transparent ${themeColorBg}`
                                                  : isMobileLightMode ? "bg-white border-slate-200 text-slate-600 hover:bg-slate-50" : "bg-black/30 border-transparent text-gray-400 hover:text-white"
                                              }`}
                                            >
                                              {preset}
                                            </button>
                                          ))}
                                        </div>

                                        {/* Verticals Sliders */}
                                        <div className="flex justify-between items-end h-24 px-1 pb-1">
                                          {["60Hz", "230Hz", "910Hz", "4kHz", "14kHz"].map((freq, index) => (
                                            <div key={freq} className="flex flex-col items-center gap-1.5 h-full justify-end">
                                              <div className={`text-[7px] font-mono font-bold ${isMobileLightMode ? "text-slate-600" : "text-gray-400"}`}>
                                                {eqBands[index] > 0 ? `+${eqBands[index]}` : eqBands[index]}
                                              </div>
                                              <div className={`w-2 h-16 rounded-full relative flex justify-center ${
                                                isMobileLightMode ? "bg-slate-200" : "bg-black/50"
                                              }`}>
                                                <div 
                                                  className={`absolute bottom-0 w-full rounded-full ${themeColorBg}`} 
                                                  style={{ height: `${((eqBands[index] + 12) / 24) * 100}%` }} 
                                                />
                                                <input
                                                  type="range" min="-12" max="12" value={eqBands[index]}
                                                  onChange={(e) => handleEqBandChange(index, parseInt(e.target.value))}
                                                  className="absolute inset-y-0 w-full opacity-0 cursor-ns-resize"
                                                  style={{ writingMode: "bt-lr" } as any}
                                                />
                                              </div>
                                              <span className="text-[7px] text-gray-500 font-mono font-semibold">{freq}</span>
                                            </div>
                                          ))}
                                        </div>

                                        {/* Save EQ Profile */}
                                        <div className="space-y-2 border-t border-gray-800/5 pt-3">
                                          <div className="flex gap-1.5">
                                            <input 
                                              type="text" value={newPresetInput} onChange={(e) => setNewPresetInput(e.target.value)} 
                                              placeholder="Guardar perfil como..."
                                              className={`flex-1 rounded-xl p-2.5 text-[10px] outline-none border ${
                                                isMobileLightMode ? "bg-white border-slate-200 text-slate-800" : "bg-black/40 border-white/5 text-white"
                                              }`}
                                            />
                                            <button 
                                              onClick={() => {
                                                if (newPresetInput.trim()) {
                                                  setSavedPresets(prev => [...prev, newPresetInput.trim()]);
                                                  setEqPreset("Personalizado");
                                                  setNewPresetInput("");
                                                  showToast("Perfil EQ guardado");
                                                }
                                              }}
                                              className={`px-4 text-black font-black rounded-xl text-[10px] tracking-wider transition-all hover:scale-[1.01] ${themeColorBg}`}
                                            >
                                              GUARDAR
                                            </button>
                                          </div>

                                          <div className={`flex gap-1 p-1 rounded-xl border ${
                                            isMobileLightMode ? "bg-slate-100 border-slate-200/40" : "bg-black/20 border-white/5"
                                          }`}>
                                            <button 
                                              onClick={() => {
                                                playSynthBeep(600, 0.05);
                                                const json = JSON.stringify({ preset: eqPreset, bands: eqBands });
                                                alert(`Perfil exportado:\n\n${json}`);
                                              }}
                                              className={`flex-1 text-[8px] font-black uppercase text-center py-1.5 rounded transition-all ${
                                                isMobileLightMode ? "hover:bg-white text-slate-600" : "hover:bg-white/5 text-gray-400"
                                              }`}
                                            >
                                              Exportar Perfil
                                            </button>
                                            <button 
                                              onClick={() => {
                                                playSynthBeep(550, 0.05);
                                                const raw = prompt("Pega el JSON del perfil de ecualización:");
                                                if (raw) {
                                                  try {
                                                    const parsed = JSON.parse(raw);
                                                    if (parsed.bands) {
                                                      setEqBands(parsed.bands);
                                                      setEqPreset("Personalizado");
                                                      showToast("Perfil EQ importado con éxito");
                                                    }
                                                  } catch(e) {
                                                    showToast("Formato de perfil no válido");
                                                  }
                                                }
                                              }}
                                              className={`flex-1 text-[8px] font-black uppercase text-center py-1.5 rounded transition-all ${
                                                isMobileLightMode ? "hover:bg-white text-slate-600" : "hover:bg-white/5 text-gray-400"
                                              }`}
                                            >
                                              Importar Perfil
                                            </button>
                                          </div>
                                        </div>
                                      </div>

                                      {/* Audio Effects Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4.5 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Efectos y Especialización</h4>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Ecualizador Paramétrico</span>
                                            <span className="text-[9px] text-gray-500">Ajuste fino de frecuencias con factor Q dinámico.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setEqParametricEnabled(!eqParametricEnabled);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${eqParametricEnabled ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${eqParametricEnabled ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="space-y-1.5">
                                          <div className="flex justify-between text-[10px]">
                                            <span className="font-semibold">Refuerzo de Bajos (Bass Boost)</span>
                                            <span className={`font-mono font-bold ${themeColorText}`}>{bassBoostLevel}%</span>
                                          </div>
                                          <input 
                                            type="range" min="0" max="100" value={bassBoostLevel} 
                                            onChange={(e) => setBassBoostLevel(parseInt(e.target.value))} 
                                            className={`w-full h-1.5 rounded-full outline-none transition-all ${
                                              isMobileLightMode ? "accent-slate-700 bg-slate-200" : "accent-[#00E5FF] bg-black/40"
                                            }`}
                                            style={{ accentColor: themeColorHex }}
                                          />
                                        </div>

                                        <div className="space-y-1.5">
                                          <div className="flex justify-between text-[10px]">
                                            <span className="font-semibold">Virtualizador Espacial 3D</span>
                                            <span className={`font-mono font-bold ${themeColorText}`}>{virtualizerLevel}%</span>
                                          </div>
                                          <input 
                                            type="range" min="0" max="100" value={virtualizerLevel} 
                                            onChange={(e) => setVirtualizerLevel(parseInt(e.target.value))} 
                                            className={`w-full h-1.5 rounded-full outline-none transition-all ${
                                              isMobileLightMode ? "accent-slate-700 bg-slate-200" : "accent-[#00E5FF] bg-black/40"
                                            }`}
                                            style={{ accentColor: themeColorHex }}
                                          />
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Efecto Surround 3D de Audio</span>
                                            <span className="text-[9px] text-gray-500">Expande la escena sonora estéreo.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setSurround3D(!surround3D);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${surround3D ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${surround3D ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Efecto Reverberación (Reverb)</span>
                                            <span className="text-[9px] text-gray-500">Emula la acústica de distintos entornos físicos.</span>
                                          </div>
                                          <select 
                                            value={reverbPreset} onChange={(e) => setReverbPreset(e.target.value)}
                                            className={`text-[10px] py-1.5 px-2.5 rounded-lg border outline-none font-bold ${
                                              isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black text-gray-300 border-white/5"
                                            }`}
                                          >
                                            <option value="Ninguno">Ninguno</option>
                                            <option value="Sala Pequeña">Sala Pequeña</option>
                                            <option value="Sala de Estar">Sala de Estar</option>
                                            <option value="Auditorio">Auditorio</option>
                                            <option value="Catedral">Catedral</option>
                                          </select>
                                        </div>
                                      </div>

                                      {/* Audio Dynamics Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Compresión y Dinámica</h4>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Limitador de Señal de Salida</span>
                                            <span className="text-[9px] text-gray-500">Previene la distorsión y saturación digital.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setLimiterEnabled(!limiterEnabled);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${limiterEnabled ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${limiterEnabled ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Compresor Dinámico Inteligente</span>
                                            <span className="text-[9px] text-gray-500">Mantiene un volumen promedio uniforme.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setDynamicCompressor(!dynamicCompressor);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${dynamicCompressor ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${dynamicCompressor ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Crossfeed para Auriculares</span>
                                            <span className="text-[9px] text-gray-500">Reduce la fatiga auditiva mezclando canales sutilmente.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setCrossfeedHeadphones(!crossfeedHeadphones);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${crossfeedHeadphones ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${crossfeedHeadphones ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>
                                      </div>

                                      {/* Audio Output Settings Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Calidad y Salida de Hardware</h4>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Perfil de Calidad de Stream</span>
                                            <span className="text-[9px] text-gray-500">Tasa de bits máxima de decodificación.</span>
                                          </div>
                                          <select 
                                            value={audioQuality} onChange={(e) => setAudioQuality(e.target.value as any)}
                                            className={`text-[10px] py-1.5 px-2.5 rounded-lg border outline-none font-bold ${
                                              isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black text-gray-300 border-white/5"
                                            }`}
                                          >
                                            <option value="Alta (320kbps)">Alta (320kbps)</option>
                                            <option value="Estándar (192kbps)">Estándar (192kbps)</option>
                                            <option value="Ahorro (96kbps)">Ahorro (96kbps)</option>
                                          </select>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Salida de Alta Resolución (Hi-Res)</span>
                                            <span className="text-[9px] text-gray-500">Habilita renderizado de audio en 32-bit de punto flotante.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setHiResOutput(!hiResOutput);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${hiResOutput ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${hiResOutput ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Frecuencia de Muestreo</span>
                                            <span className="text-[9px] text-gray-500">Tasa de muestreo nativa del hardware.</span>
                                          </div>
                                          <select 
                                            value={sampleRate} onChange={(e) => setSampleRate(e.target.value)}
                                            className={`text-[10px] py-1.5 px-2.5 rounded-lg border outline-none font-bold ${
                                              isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black text-gray-300 border-white/5"
                                            }`}
                                          >
                                            <option value="44.1 kHz">44.1 kHz</option>
                                            <option value="48 kHz">48 kHz</option>
                                            <option value="96 kHz">96 kHz</option>
                                            <option value="192 kHz">192 kHz</option>
                                          </select>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Profundidad de Bits</span>
                                            <span className="text-[9px] text-gray-500">Bits por muestra del DAC de salida.</span>
                                          </div>
                                          <select 
                                            value={bitDepth} onChange={(e) => setBitDepth(e.target.value)}
                                            className={`text-[10px] py-1.5 px-2.5 rounded-lg border outline-none font-bold ${
                                              isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black text-gray-300 border-white/5"
                                            }`}
                                          >
                                            <option value="16-bit">16-bit</option>
                                            <option value="24-bit">24-bit</option>
                                            <option value="32-bit">32-bit float</option>
                                          </select>
                                        </div>
                                      </div>
                                    </div>
                                  )}

                                  {/* D. APARIENCIA */}
                                  {activeSettingsCategory === "apariencia" && (
                                    <div className="space-y-4 animate-fadeIn">
                                      {/* Theme Selection Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Paleta y Colores</h4>

                                        <div className="space-y-1.5">
                                          <span className="font-semibold text-[11px] block">Tema Visual General</span>
                                          <div className="grid grid-cols-3 gap-1.5">
                                            {(["claro", "oscuro", "automatico"] as const).map(mode => (
                                              <button
                                                key={mode}
                                                onClick={() => {
                                                  playSynthBeep(450, 0.05);
                                                  setAppThemeMode(mode);
                                                  setIsMobileLightMode(mode === "claro");
                                                }}
                                                className={`py-2 rounded-xl border text-[9px] font-black text-center capitalize transition-all ${
                                                  appThemeMode === mode
                                                    ? `shadow-sm text-black border-transparent ${themeColorBg}`
                                                    : isMobileLightMode ? "bg-white border-slate-200 text-slate-600 hover:bg-slate-50" : "bg-black/30 border-transparent text-gray-400 hover:text-white"
                                                }`}
                                              >
                                                {mode}
                                              </button>
                                            ))}
                                          </div>
                                        </div>

                                        <div className="space-y-1.5 pt-2">
                                          <span className="font-semibold text-[11px] block">Color de Énfasis del Tema</span>
                                          <div className="flex gap-2">
                                            {["cyan", "magenta", "violet", "emerald", "amber"].map(col => (
                                              <button
                                                key={col}
                                                onClick={() => {
                                                  playSynthBeep(500, 0.05);
                                                  setSelectedMainColor(col);
                                                  showToast(`Color principal cambiado a: ${col}`);
                                                }}
                                                className={`w-8 h-8 rounded-full transition-all border-2 relative hover:scale-105 active:scale-95 ${
                                                  selectedMainColor === col ? "border-white shadow-md scale-105" : "border-transparent opacity-80"
                                                }`}
                                                style={{
                                                  backgroundColor: 
                                                    col === "cyan" ? "#00E5FF" : 
                                                    col === "magenta" ? "#FF007F" : 
                                                    col === "violet" ? "#8B5CF6" : 
                                                    col === "emerald" ? "#10B981" : "#F59E0B"
                                                }}
                                              >
                                                {selectedMainColor === col && (
                                                  <div className="absolute inset-0 flex items-center justify-center">
                                                    <Check className="w-4 h-4 text-black font-black" />
                                                  </div>
                                                )}
                                              </button>
                                            ))}
                                          </div>
                                        </div>
                                      </div>

                                      {/* Interface Effects Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Efectos y Estilos de Fondo</h4>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Material Design Integrado</span>
                                            <span className="text-[9px] text-gray-500">Usa componentes de Material Design 3.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setMaterialDesignEnabled(!materialDesignEnabled);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${materialDesignEnabled ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${materialDesignEnabled ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Transparencias y Efectos Glass</span>
                                            <span className="text-[9px] text-gray-500">Aplica desenfoques acrílicos esmerilados.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setTransparenciesEnabled(!transparenciesEnabled);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${transparenciesEnabled ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${transparenciesEnabled ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Fondo Dinámico Basado en Carátula</span>
                                            <span className="text-[9px] text-gray-500">Adapta el fondo al color de la portada actual.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setDynamicBackground(!dynamicBackground);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${dynamicBackground ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${dynamicBackground ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Animaciones del Reproductor</span>
                                            <span className="text-[9px] text-gray-500">Transiciones fluidas de los botones de control.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setAnimationsEnabled(!animationsEnabled);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${animationsEnabled ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${animationsEnabled ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>
                                      </div>

                                      {/* Typo and Styles Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Tipografía y Layout</h4>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Tamaño de Texto</span>
                                            <span className="text-[9px] text-gray-500">Escala de fuentes de toda la aplicación.</span>
                                          </div>
                                          <select 
                                            value={uiFontSize} onChange={(e) => setUiFontSize(e.target.value)}
                                            className={`text-[10px] py-1.5 px-2.5 rounded-lg border outline-none font-bold ${
                                              isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black text-gray-300 border-white/5"
                                            }`}
                                          >
                                            <option value="Chico">Chico</option>
                                            <option value="Mediano">Mediano</option>
                                            <option value="Grande">Grande</option>
                                          </select>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Estilo de Iconos</span>
                                            <span className="text-[9px] text-gray-500">Familia visual de indicadores e iconos.</span>
                                          </div>
                                          <select 
                                            value={uiIconStyle} onChange={(e) => setUiIconStyle(e.target.value)}
                                            className={`text-[10px] py-1.5 px-2.5 rounded-lg border outline-none font-bold ${
                                              isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black text-gray-300 border-white/5"
                                            }`}
                                          >
                                            <option value="Contorneado">Contorneado</option>
                                            <option value="Relleno">Relleno</option>
                                            <option value="Minimalista">Minimalista</option>
                                          </select>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Forma de las Carátulas</span>
                                            <span className="text-[9px] text-gray-500">Bordes de las portadas en la biblioteca.</span>
                                          </div>
                                          <select 
                                            value={coverArtShape} onChange={(e) => setCoverArtShape(e.target.value)}
                                            className={`text-[10px] py-1.5 px-2.5 rounded-lg border outline-none font-bold ${
                                              isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black text-gray-300 border-white/5"
                                            }`}
                                          >
                                            <option value="Circular">Circular</option>
                                            <option value="Cuadrada">Cuadrada</option>
                                            <option value="Redondeada">Redondeada</option>
                                          </select>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Estilo del Reproductor</span>
                                            <span className="text-[9px] text-gray-500">Diseño global de los controles principales.</span>
                                          </div>
                                          <select 
                                            value={playerStyle} onChange={(e) => setPlayerStyle(e.target.value)}
                                            className={`text-[10px] py-1.5 px-2.5 rounded-lg border outline-none font-bold ${
                                              isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black text-gray-300 border-white/5"
                                            }`}
                                          >
                                            <option value="Premium">Premium</option>
                                            <option value="Retro Vinilo">Retro Vinilo</option>
                                            <option value="Minimalista">Minimalista</option>
                                          </select>
                                        </div>
                                      </div>
                                    </div>
                                  )}

                                  {/* E. VISUALIZADOR */}
                                  {activeSettingsCategory === "visualizador" && (
                                    <div className="space-y-4 animate-fadeIn">
                                      {/* Visualizer Modes Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Estilo y Renderizado</h4>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Visualizador Predeterminado</span>
                                            <span className="text-[9px] text-gray-500">Forma de onda reactiva principal.</span>
                                          </div>
                                          <select 
                                            value={visualizerStyle} onChange={(e) => setVisualizerStyle(e.target.value as any)}
                                            className={`text-[10px] py-1.5 px-2.5 rounded-lg border outline-none font-bold uppercase font-mono ${
                                              isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black text-gray-300 border-white/5"
                                            }`}
                                          >
                                            <option value="barras">Barras Clásicas</option>
                                            <option value="espectro">Espectro Radial</option>
                                            <option value="ondas">Ondas de Fluido</option>
                                            <option value="particulas">Partículas Orbitantes</option>
                                            <option value="lineas">Líneas Neón</option>
                                            <option value="luces">Luces Ambientales</option>
                                          </select>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Paleta de Colores</span>
                                            <span className="text-[9px] text-gray-500">Combinación tonal del espectro dinámico.</span>
                                          </div>
                                          <select 
                                            value={visualizerColorPalette} onChange={(e) => setVisualizerColorPalette(e.target.value)}
                                            className={`text-[10px] py-1.5 px-2.5 rounded-lg border outline-none font-bold ${
                                              isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black text-gray-300 border-white/5"
                                            }`}
                                          >
                                            <option value="Dinámico">Dinámico</option>
                                            <option value="Neón">Neón Eléctrico</option>
                                            <option value="Monocromo">Monocromo</option>
                                          </select>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Calidad Gráfica</span>
                                            <span className="text-[9px] text-gray-500">Antialiasing y suavizado de bordes.</span>
                                          </div>
                                          <select 
                                            value={visualizerQuality} onChange={(e) => setVisualizerQuality(e.target.value)}
                                            className={`text-[10px] py-1.5 px-2.5 rounded-lg border outline-none font-bold ${
                                              isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black text-gray-300 border-white/5"
                                            }`}
                                          >
                                            <option value="Baja">Baja</option>
                                            <option value="Media">Media</option>
                                            <option value="Alta">Alta (Glow Habilitado)</option>
                                          </select>
                                        </div>
                                      </div>

                                      {/* Physics Parameters Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4.5 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Física de Partículas</h4>

                                        <div className="space-y-1.5">
                                          <div className="flex justify-between text-[10px]">
                                            <span className="font-semibold">Sensibilidad de Entrada</span>
                                            <span className={`font-mono font-bold ${themeColorText}`}>{visualizerSensitivity}%</span>
                                          </div>
                                          <input 
                                            type="range" min="20" max="150" value={visualizerSensitivity} 
                                            onChange={(e) => setVisualizerSensitivity(parseInt(e.target.value))} 
                                            className={`w-full h-1.5 rounded-full outline-none transition-all ${
                                              isMobileLightMode ? "accent-slate-700 bg-slate-200" : "accent-[#00E5FF] bg-black/40"
                                            }`}
                                            style={{ accentColor: themeColorHex }}
                                          />
                                        </div>

                                        <div className="space-y-1.5">
                                          <div className="flex justify-between text-[10px]">
                                            <span className="font-semibold">Velocidad de Animación</span>
                                            <span className={`font-mono font-bold ${themeColorText}`}>{visualizerSpeed}%</span>
                                          </div>
                                          <input 
                                            type="range" min="10" max="100" value={visualizerSpeed} 
                                            onChange={(e) => setVisualizerSpeed(parseInt(e.target.value))} 
                                            className={`w-full h-1.5 rounded-full outline-none transition-all ${
                                              isMobileLightMode ? "accent-slate-700 bg-slate-200" : "accent-[#00E5FF] bg-black/40"
                                            }`}
                                            style={{ accentColor: themeColorHex }}
                                          />
                                        </div>

                                        <div className="space-y-1.5">
                                          <div className="flex justify-between text-[10px]">
                                            <span className="font-semibold">Intensidad de Brillo (Bloom)</span>
                                            <span className={`font-mono font-bold ${themeColorText}`}>{visualizerIntensity}%</span>
                                          </div>
                                          <input 
                                            type="range" min="10" max="100" value={visualizerIntensity} 
                                            onChange={(e) => setVisualizerIntensity(parseInt(e.target.value))} 
                                            className={`w-full h-1.5 rounded-full outline-none transition-all ${
                                              isMobileLightMode ? "accent-slate-700 bg-slate-200" : "accent-[#00E5FF] bg-black/40"
                                            }`}
                                            style={{ accentColor: themeColorHex }}
                                          />
                                        </div>
                                      </div>

                                      {/* Performance Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Rendimiento y Pantalla</h4>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Límite de Fotogramas (FPS)</span>
                                            <span className="text-[9px] text-gray-500">Reduce el consumo de batería limitando los FPS.</span>
                                          </div>
                                          <div className="flex gap-1 font-mono">
                                            {[30, 60, 90, 120].map(fps => (
                                              <button
                                                key={fps}
                                                onClick={() => { playSynthBeep(450, 0.05); setVisualizerFps(fps); }}
                                                className={`px-2 py-1 rounded-lg text-[9px] font-black transition-all ${
                                                  visualizerFps === fps 
                                                    ? `shadow-sm text-black ${themeColorBg}` 
                                                    : isMobileLightMode ? "bg-slate-200 text-slate-700" : "bg-white/5 text-gray-400"
                                                }`}
                                              >
                                                {fps}
                                              </button>
                                            ))}
                                          </div>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Motor de Partículas reactivo</span>
                                            <span className="text-[9px] text-gray-500">Agrega partículas orbitantes al compás.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setVisualizerParticles(!visualizerParticles);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${visualizerParticles ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${visualizerParticles ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                  )}

                                  {/* F. LETRAS */}
                                  {activeSettingsCategory === "letras" && (
                                    <div className="space-y-4 animate-fadeIn">
                                      {/* Search and Metadata Lyrics Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Búsqueda y Descarga</h4>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Buscar letras automáticamente</span>
                                            <span className="text-[9px] text-gray-500">Busca líricas en internet al reproducir canciones.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setAutoLyricsEnabled(!autoLyricsEnabled);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${autoLyricsEnabled ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${autoLyricsEnabled ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Idioma de Búsqueda</span>
                                            <span className="text-[9px] text-gray-500">Prioriza resultados en este idioma.</span>
                                          </div>
                                          <select 
                                            className={`text-[10px] py-1.5 px-2.5 rounded-lg border outline-none font-bold ${
                                              isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black text-gray-300 border-white/5"
                                            }`}
                                          >
                                            <option>Español</option>
                                            <option>Inglés</option>
                                            <option>Portugués</option>
                                            <option>Japonés</option>
                                          </select>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Traducción Simultánea</span>
                                            <span className="text-[9px] text-gray-500">Muestra la traducción al español en línea.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setLyricsTranslationEnabled(!lyricsTranslationEnabled);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${lyricsTranslationEnabled ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${lyricsTranslationEnabled ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>
                                      </div>

                                      {/* Sync Offset Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4.5 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Alineación y Tiempos</h4>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Sincronización Automática</span>
                                            <span className="text-[9px] text-gray-500">Intenta auto-alinear la letra con la voz principal.</span>
                                          </div>
                                          <button 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${themeColorBg}`}
                                          >
                                            <div className="w-3.5 h-3.5 rounded-full bg-white shadow-md translate-x-3.5" />
                                          </button>
                                        </div>

                                        <div className="space-y-1.5">
                                          <div className="flex justify-between text-[10px]">
                                            <span className="font-semibold">Ajustar Sincronización Manual</span>
                                            <span className={`font-mono font-bold ${themeColorText}`}>{lyricsSyncOffset} ms</span>
                                          </div>
                                          <input 
                                            type="range" min="-1000" max="1000" step="50" value={lyricsSyncOffset} 
                                            onChange={(e) => setLyricsSyncOffset(parseInt(e.target.value))} 
                                            className={`w-full h-1.5 rounded-full outline-none transition-all ${
                                              isMobileLightMode ? "accent-slate-700 bg-slate-200" : "accent-[#00E5FF] bg-black/40"
                                            }`}
                                            style={{ accentColor: themeColorHex }}
                                          />
                                        </div>
                                      </div>

                                      {/* Lyrics View Options Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Estilo de Letra y Flujo</h4>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Desplazamiento Automático (Auto-Scroll)</span>
                                            <span className="text-[9px] text-gray-500">Mantiene la línea actual centrada automáticamente.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setLyricsAutoScrollEnabled(!lyricsAutoScrollEnabled);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${lyricsAutoScrollEnabled ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${lyricsAutoScrollEnabled ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Modo Karaoke (Focus de Letra)</span>
                                            <span className="text-[9px] text-gray-500">Destaca la palabra exacta según la sílaba de canto.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setLyricsKaraokeEnabled(!lyricsKaraokeEnabled);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${lyricsKaraokeEnabled ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${lyricsKaraokeEnabled ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Compatibilidad con LRC Avanzado</span>
                                            <span className="text-[9px] text-gray-500">Soporte completo para marcas de tiempo por sílabas.</span>
                                          </div>
                                          <button 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${themeColorBg}`}
                                          >
                                            <div className="w-3.5 h-3.5 rounded-full bg-white shadow-md translate-x-3.5" />
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                  )}

                                  {/* G. METADATOS */}
                                  {activeSettingsCategory === "metadatos" && (
                                    <div className="space-y-4 animate-fadeIn">
                                      {/* ID3 Tag Editor Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Editor de Etiquetas ID3</h4>

                                        <div className="space-y-2">
                                          <label className="text-[9px] text-gray-500 font-bold uppercase tracking-wider block">Seleccionar Canción de la Biblioteca</label>
                                          <select 
                                            value={selectedID3TrackTitle} 
                                            onChange={(e) => {
                                              const title = e.target.value;
                                              setSelectedID3TrackTitle(title);
                                              const tr = tracks.find(t => t.title === title);
                                              if (tr) {
                                                setId3TitleInput(tr.title);
                                                setId3ArtistInput(tr.artist);
                                                setId3AlbumInput(tr.album);
                                              }
                                            }}
                                            className={`w-full text-xs font-bold p-3 rounded-xl border outline-none ${
                                              isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black text-gray-300 border-white/5"
                                            }`}
                                          >
                                            <option value="">-- Elige una canción --</option>
                                            {tracks.map(t => (
                                              <option key={t.title} value={t.title}>{t.title} ({t.artist})</option>
                                            ))}
                                          </select>
                                        </div>

                                        {selectedID3TrackTitle && (
                                          <div className="space-y-3 pt-3 border-t border-gray-800/5">
                                            <div className="space-y-1">
                                              <label className="text-[9px] text-gray-500 font-bold uppercase tracking-wider block">Título de la Pista</label>
                                              <input 
                                                type="text" value={id3TitleInput} onChange={(e) => setId3TitleInput(e.target.value)}
                                                className={`w-full text-xs font-semibold p-2.5 rounded-lg border outline-none ${
                                                  isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black/60 text-white border-white/5"
                                                }`}
                                              />
                                            </div>
                                            <div className="space-y-1">
                                              <label className="text-[9px] text-gray-500 font-bold uppercase tracking-wider block">Artista / Intérprete</label>
                                              <input 
                                                type="text" value={id3ArtistInput} onChange={(e) => setId3ArtistInput(e.target.value)}
                                                className={`w-full text-xs font-semibold p-2.5 rounded-lg border outline-none ${
                                                  isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black/60 text-white border-white/5"
                                                }`}
                                              />
                                            </div>
                                            <div className="space-y-1">
                                              <label className="text-[9px] text-gray-500 font-bold uppercase tracking-wider block">Álbum</label>
                                              <input 
                                                type="text" value={id3AlbumInput} onChange={(e) => setId3AlbumInput(e.target.value)}
                                                className={`w-full text-xs font-semibold p-2.5 rounded-lg border outline-none ${
                                                  isMobileLightMode ? "bg-white text-slate-800 border-slate-200" : "bg-black/60 text-white border-white/5"
                                                }`}
                                              />
                                            </div>
                                            <button 
                                              onClick={() => {
                                                playSynthBeep(650, 0.08);
                                                setTracks(prev => prev.map(t => {
                                                  if (t.title === selectedID3TrackTitle) {
                                                    return { ...t, title: id3TitleInput, artist: id3ArtistInput, album: id3AlbumInput };
                                                  }
                                                  return t;
                                                }));
                                                showToast("Metadatos ID3 guardados");
                                                addLiveLog(`Metadatos actualizados para: ${id3TitleInput}`);
                                                setSelectedID3TrackTitle("");
                                              }}
                                              className={`w-full py-2.5 font-black rounded-xl text-center text-[10px] tracking-wider transition-all shadow-sm ${
                                                isMobileLightMode ? "bg-slate-800 text-white" : "bg-cyan-400 text-black"
                                              }`}
                                              style={isMobileLightMode ? {} : { backgroundColor: themeColorHex }}
                                            >
                                              GUARDAR CAMBIOS ID3
                                            </button>
                                          </div>
                                        )}
                                      </div>

                                      {/* Automated Metadata Options Card */}
                                      <div className={`rounded-2xl p-4 border space-y-4 ${
                                        isMobileLightMode ? "bg-slate-50/60 border-slate-100 text-slate-800" : "bg-white/[0.02] border-white/5 text-gray-300"
                                      }`}>
                                        <h4 className={`text-xs font-black tracking-wider uppercase border-b border-gray-800/5 pb-2 ${isMobileLightMode ? "text-slate-800" : "text-gray-100"}`}>Scraping y Automatización</h4>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Descargar portadas de álbum automáticamente</span>
                                            <span className="text-[9px] text-gray-500">Busca portadas en alta resolución mediante MusicBrainz.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setMetadataAutoDownloadCovers(!metadataAutoDownloadCovers);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${metadataAutoDownloadCovers ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${metadataAutoDownloadCovers ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Buscar información de canción automáticamente</span>
                                            <span className="text-[9px] text-gray-500">Completa géneros y año con escaneo acústico de huella.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setAutoMetadataSearch(!autoMetadataSearch);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${autoMetadataSearch ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${autoMetadataSearch ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Renombrar archivos automáticamente</span>
                                            <span className="text-[9px] text-gray-500">Aplica nomenclatura estándar: "Artista - Título.mp3".</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setMetadataAutoRename(!metadataAutoRename);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${metadataAutoRename ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${metadataAutoRename ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>

                                        <div className="flex items-center justify-between text-[11px]">
                                          <div>
                                            <span className="font-semibold block">Organización automática de carpetas</span>
                                            <span className="text-[9px] text-gray-500">Agrupa las pistas en subcarpetas de Género / Artista.</span>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              playSynthBeep(450, 0.05);
                                              setMetadataAutoOrganize(!metadataAutoOrganize);
                                            }} 
                                            className={`w-8 h-4.5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${metadataAutoOrganize ? themeColorBg : "bg-gray-700/60"}`}
                                          >
                                            <div className={`w-3.5 h-3.5 rounded-full bg-white shadow-md transition-all duration-300 ${metadataAutoOrganize ? 'translate-x-3.5' : 'translate-x-0'}`} />
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                  )}

                                  {/* H. HERRAMIENTAS */}
                                  {activeSettingsCategory === "herramientas" && (
                                    <div className="space-y-4">
                                      {/* Audio Converter Form */}
                                      <div className="bg-black/30 p-3.5 rounded-2xl border border-white/5 space-y-2.5">
                                        <h4 className="font-bold text-[10px] text-gray-100 uppercase tracking-wider">Convertidor de Audio</h4>
                                        
                                        <div className="space-y-1">
                                          <label className="text-[9px] text-gray-400">PISTA DE ORIGEN</label>
                                          <select 
                                            value={convertToolSourceTitle} onChange={(e) => setConvertToolSourceTitle(e.target.value)}
                                            className="w-full bg-black border border-white/5 p-2 rounded-xl text-xs text-white"
                                          >
                                            <option value="">-- Elige una canción --</option>
                                            {tracks.map(t => (
                                              <option key={t.title} value={t.title}>{t.title} ({t.artist})</option>
                                            ))}
                                          </select>
                                        </div>

                                        <div className="grid grid-cols-2 gap-2">
                                          <div className="space-y-0.5">
                                            <label className="text-[9px] text-gray-400">FORMATO DE SALIDA</label>
                                            <select 
                                              value={audioToolConvertFormat} onChange={(e) => setAudioToolConvertFormat(e.target.value)}
                                              className="w-full bg-black border border-white/5 p-1.5 rounded-lg text-xs"
                                            >
                                              <option value="MP3">MP3 (.mp3)</option>
                                              <option value="AAC">AAC (.m4a)</option>
                                              <option value="FLAC">FLAC Lossless (.flac)</option>
                                              <option value="WAV">WAV (.wav)</option>
                                              <option value="OGG">OGG Vorbis (.ogg)</option>
                                              <option value="OPUS">OPUS (.opus)</option>
                                            </select>
                                          </div>

                                          <div className="space-y-0.5">
                                            <label className="text-[9px] text-gray-400">BITRATE</label>
                                            <select 
                                              value={audioToolBitrate} onChange={(e) => setAudioToolBitrate(e.target.value)}
                                              className="w-full bg-black border border-white/5 p-1.5 rounded-lg text-xs"
                                            >
                                              <option value="128 kbps">128 kbps (Ahorro)</option>
                                              <option value="192 kbps">192 kbps (Estándar)</option>
                                              <option value="320 kbps">320 kbps (HQ)</option>
                                            </select>
                                          </div>
                                        </div>

                                        {convertToolRunning ? (
                                          <div className="space-y-1.5 pt-2">
                                            <div className="flex justify-between text-[10px] font-mono text-cyan-400">
                                              <span>{convertToolStep}</span>
                                              <span>{convertToolProgress}%</span>
                                            </div>
                                            <div className="w-full h-1 bg-gray-900 rounded-full overflow-hidden">
                                              <div className="h-full bg-cyan-400 transition-all duration-200" style={{ width: `${convertToolProgress}%` }} />
                                            </div>
                                          </div>
                                        ) : (
                                          <button 
                                            onClick={() => {
                                              if (!convertToolSourceTitle) {
                                                showToast("Elige una pista de origen");
                                                return;
                                              }
                                              setConvertToolRunning(true);
                                              setConvertToolProgress(0);
                                              setConvertToolStep("Decodificando PCM original...");
                                              playSynthBeep(450, 0.1);

                                              const csteps = [
                                                { p: 25, s: "Filtrando frecuencias analógicas..." },
                                                { p: 60, s: `Compilando codificador ${audioToolConvertFormat}...` },
                                                { p: 85, s: "Escribiendo etiquetas ID3 incrustadas..." },
                                                { p: 100, s: "Sincronizando contenedor contenedor..." }
                                              ];

                                              csteps.forEach((st, idx) => {
                                                setTimeout(() => {
                                                  setConvertToolProgress(st.p);
                                                  setConvertToolStep(st.s);
                                                  playSynthBeep(480 + idx * 30, 0.05);
                                                  if (st.p === 100) {
                                                    setConvertToolRunning(false);
                                                    const out = `${convertToolSourceTitle}_convertido.${audioToolConvertFormat.toLowerCase()}`;
                                                    setConvertedTracksList(prev => [...prev, out]);
                                                    showToast(`Guardado: ${out}`);
                                                    addLiveLog(`Convertido '${convertToolSourceTitle}' a ${audioToolConvertFormat}`);
                                                    setConvertToolSourceTitle("");
                                                  }
                                                }, (idx + 1) * 500);
                                              });
                                            }}
                                            className="w-full py-2 bg-cyan-400 text-black font-black rounded-xl text-center text-[10px]"
                                          >
                                            INICIAR CONVERSIÓN DE AUDIO
                                          </button>
                                        )}
                                      </div>

                                      {/* Audio Trimmer */}
                                      <div className="bg-black/30 p-3.5 rounded-2xl border border-white/5 space-y-2.5">
                                        <h4 className="font-bold text-[10px] text-gray-100 uppercase tracking-wider">Recortador de Audio (Trimmer)</h4>
                                        <select 
                                          value={trimToolSourceTitle} onChange={(e) => setTrimToolSourceTitle(e.target.value)}
                                          className="w-full bg-black border border-white/5 p-2 rounded-xl text-xs text-white"
                                        >
                                          <option value="">-- Seleccionar canción --</option>
                                          {tracks.map(t => (
                                            <option key={t.title} value={t.title}>{t.title}</option>
                                          ))}
                                        </select>

                                        {trimToolSourceTitle && (
                                          <div className="space-y-2.5">
                                            {/* Trimming Waveform Graphic */}
                                            <div className="h-10 bg-black/60 rounded-xl relative overflow-hidden flex items-center justify-between px-3 border border-white/5">
                                              <div className="absolute inset-y-0 bg-cyan-400/15" style={{ left: `${(trimToolStartSec / 200) * 100}%`, right: `${100 - (trimToolEndSec / 200) * 100}%` }} />
                                              {[...Array(24)].map((_, i) => (
                                                <div key={i} className="w-1 bg-gray-700 rounded-full" style={{ height: `${Math.sin(i * 0.5) * 60 + 40}%` }} />
                                              ))}
                                            </div>

                                            <div className="grid grid-cols-2 gap-2 text-[10px]">
                                              <div className="space-y-0.5">
                                                <span>Punto Inicio: {trimToolStartSec}s</span>
                                                <input type="range" min="0" max="100" value={trimToolStartSec} onChange={(e) => setTrimToolStartSec(parseInt(e.target.value))} className="w-full accent-cyan-400 bg-black/40 h-1" />
                                              </div>
                                              <div className="space-y-0.5">
                                                <span>Punto Final: {trimToolEndSec}s</span>
                                                <input type="range" min="100" max="200" value={trimToolEndSec} onChange={(e) => setTrimToolEndSec(parseInt(e.target.value))} className="w-full accent-cyan-400 bg-black/40 h-1" />
                                              </div>
                                            </div>

                                            <button 
                                              onClick={() => {
                                                playSynthBeep(650, 0.08);
                                                showToast(`Recortado: '${trimToolSourceTitle}' de ${trimToolStartSec}s a ${trimToolEndSec}s`);
                                                addLiveLog(`Recortado '${trimToolSourceTitle}' (${trimToolStartSec}s - ${trimToolEndSec}s)`);
                                                setTrimToolSourceTitle("");
                                              }}
                                              className="w-full py-2 bg-cyan-400 text-black font-black rounded-xl text-[10px]"
                                            >
                                              RECORTAR Y GUARDAR
                                            </button>
                                          </div>
                                        )}
                                      </div>

                                      {/* Quality Analyzer */}
                                      <div className="bg-black/30 p-3.5 rounded-2xl border border-white/5 space-y-2.5">
                                        <h4 className="font-bold text-[10px] text-gray-100 uppercase tracking-wider">Analizador de Calidad</h4>
                                        <div className="flex gap-1.5">
                                          <select 
                                            value={audioAnalysisTitle} onChange={(e) => setAudioAnalysisTitle(e.target.value)}
                                            className="flex-1 bg-black border border-white/5 p-1.5 rounded-xl text-xs text-white"
                                          >
                                            <option value="">-- Elige canción --</option>
                                            {tracks.map(t => (
                                              <option key={t.title} value={t.title}>{t.title}</option>
                                            ))}
                                          </select>
                                          <button 
                                            onClick={() => {
                                              if (!audioAnalysisTitle) return;
                                              playSynthBeep(500, 0.05);
                                              setAudioAnalysisRunning(true);
                                              setTimeout(() => {
                                                setAudioAnalysisRunning(false);
                                                setAudioAnalysisReport({
                                                  codec: audioAnalysisTitle === "Luna de Octubre" ? "FLAC Lossless" : "MPEG Layer-3",
                                                  sample: "44.1 kHz",
                                                  bitrate: audioAnalysisTitle === "Luna de Octubre" ? "1042 kbps" : "320 kbps",
                                                  range: "96.4 dB",
                                                  verdict: audioAnalysisTitle === "Luna de Octubre" ? "Excelente (Audiófilo)" : "Muy Buena (HQ MP3)"
                                                });
                                                playSynthBeep(620, 0.08);
                                                addLiveLog(`Analizada calidad espectral de: ${audioAnalysisTitle}`);
                                              }, 1000);
                                            }}
                                            className="px-3 bg-cyan-400 text-black font-black rounded-xl text-[10px]"
                                          >
                                            ANALIZAR
                                          </button>
                                        </div>

                                        {audioAnalysisRunning && <span className="text-[10px] text-cyan-400 font-mono block">Escaneando espectro espectral...</span>}
                                        {audioAnalysisReport && (
                                          <div className="bg-black/40 p-2.5 rounded-xl border border-white/5 text-[9px] font-mono space-y-1">
                                            <div>Codec: <span className="text-cyan-400">{audioAnalysisReport.codec}</span></div>
                                            <div>Bitrate: <span className="text-cyan-400">{audioAnalysisReport.bitrate}</span></div>
                                            <div>Rango Dinámico: <span className="text-cyan-400">{audioAnalysisReport.range}</span></div>
                                            <div className="font-bold text-[10px] text-white pt-1">Veredicto: <span className="text-emerald-400">{audioAnalysisReport.verdict}</span></div>
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  )}

                                  {/* I. COPIAS DE SEGURIDAD */}
                                  {activeSettingsCategory === "backup" && (
                                    <div className="space-y-4">
                                      <p className="text-[10px] text-gray-400">Exporta tu configuración del ecualizador, playlists locales y parámetros del reproductor en un formato JSON seguro.</p>
                                      
                                      <div className="space-y-2">
                                        <h4 className="font-bold text-gray-100">Configuración Actual (JSON)</h4>
                                        <textarea 
                                          readOnly 
                                          value={JSON.stringify({ eqPreset, eqBands, appThemeMode, selectedMainColor, playbackVolume, lastBackupTime }, null, 2)}
                                          className="w-full bg-black/60 border border-white/5 p-2 rounded-xl text-[10px] font-mono h-24 resize-none text-cyan-400"
                                        />
                                        <button 
                                          onClick={() => {
                                            playSynthBeep(500, 0.05);
                                            navigator.clipboard?.writeText(JSON.stringify({ eqPreset, eqBands, appThemeMode, selectedMainColor }));
                                            showToast("Configuración copiada");
                                          }}
                                          className="w-full py-2 bg-cyan-400 text-black font-black rounded-xl text-[10px]"
                                        >
                                          COPIAR CONFIGURACIÓN
                                        </button>
                                      </div>

                                      <div className="space-y-2 pt-2 border-t border-white/5">
                                        <h4 className="font-bold text-gray-100">Importar Copia de Seguridad</h4>
                                        <button 
                                          onClick={() => {
                                            playSynthBeep(520, 0.05);
                                            const r = prompt("Pega el JSON de tu copia de seguridad:");
                                            if (r) {
                                              try {
                                                const p = JSON.parse(r);
                                                if (p.selectedMainColor) setSelectedMainColor(p.selectedMainColor);
                                                if (p.appThemeMode) setAppThemeMode(p.appThemeMode);
                                                showToast("Configuración restaurada");
                                                addLiveLog("Copia de seguridad importada");
                                              } catch(e) {
                                                showToast("Formato JSON no válido");
                                              }
                                            }
                                          }}
                                          className="w-full py-2 bg-white/5 hover:bg-white/10 rounded-xl text-[10px]"
                                        >
                                          Restaurar Copia de Seguridad
                                        </button>
                                      </div>

                                      <div className="grid grid-cols-2 gap-2">
                                        <button onClick={() => { playSynthBeep(500, 0.05); setLastBackupTime("Justo ahora"); showToast("Listas respaldadas"); }} className="py-2 bg-white/5 rounded-xl text-[10px] font-bold">Respaldar Playlists</button>
                                        <button onClick={() => { playSynthBeep(450, 0.05); showToast("Restauración completada"); }} className="py-2 bg-white/5 rounded-xl text-[10px] font-bold">Restaurar Respaldo</button>
                                      </div>
                                    </div>
                                  )}

                                  {/* J. AVANZADO */}
                                  {activeSettingsCategory === "avanzado" && (
                                    <div className="space-y-4">
                                      {/* Logs system */}
                                      <div className="space-y-1.5">
                                        <h4 className="font-bold text-gray-100">Consola de Registros del Sistema (Live Logs)</h4>
                                        <div className="bg-black text-[9px] font-mono p-3 rounded-2xl border border-white/5 h-28 overflow-y-auto space-y-1 scrollbar-none text-cyan-400">
                                          {liveLogLines.map((log, i) => (
                                            <div key={i}>{log}</div>
                                          ))}
                                        </div>
                                      </div>

                                      {/* Performance Monitor */}
                                      <div className="bg-black/30 p-3.5 rounded-2xl border border-white/5 space-y-2.5">
                                        <h4 className="font-bold text-[10px] text-gray-100 uppercase tracking-wider">Monitor de Rendimiento</h4>
                                        <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-mono">
                                          <div className="bg-black/40 p-2 rounded-xl">
                                            <span className="text-gray-500 block">CPU</span>
                                            <span className="text-cyan-400 font-bold">1.2%</span>
                                          </div>
                                          <div className="bg-black/40 p-2 rounded-xl">
                                            <span className="text-gray-500 block">MEMORIA</span>
                                            <span className="text-cyan-400 font-bold">42.5 MB</span>
                                          </div>
                                          <div className="bg-black/40 p-2 rounded-xl">
                                            <span className="text-gray-500 block">BATERÍA</span>
                                            <span className="text-emerald-400 font-bold">94%</span>
                                          </div>
                                        </div>
                                      </div>

                                      {/* Caché */}
                                      <div className="flex justify-between items-center bg-black/20 p-2 rounded-xl">
                                        <div>
                                          <span className="block font-bold">Caché de Carátulas y Letras</span>
                                          <span className="text-[10px] text-gray-500 font-mono">24.5 MB ocupados</span>
                                        </div>
                                        <button 
                                          onClick={() => {
                                            playSynthBeep(450, 0.05);
                                            showToast("Caché limpiada con éxito (0.0 B)");
                                            addLiveLog("Limpieza de caché de carátulas finalizada");
                                          }}
                                          className="px-3 py-1.5 bg-red-500/10 text-red-400 font-bold rounded-lg text-[10px]"
                                        >
                                          LIMPIAR CACHÉ
                                        </button>
                                      </div>

                                      <div className="flex items-center justify-between">
                                        <span>Modo Desarrollador Habilitado</span>
                                        <button onClick={() => setIsDeveloperMode(!isDeveloperMode)} className={`w-7 h-4 rounded-full p-0.5 ${isDeveloperMode ? 'bg-cyan-400' : 'bg-gray-800'}`}>
                                          <div className={`w-3 h-3 bg-white rounded-full transition-all ${isDeveloperMode ? 'translate-x-3' : 'translate-x-0'}`} />
                                        </button>
                                      </div>
                                    </div>
                                  )}

                                  {/* K. ACERCA DE */}
                                  {activeSettingsCategory === "acerca" && (
                                    <div className="space-y-4">
                                      <div className="bg-black/30 p-3.5 rounded-2xl border border-white/5 text-center space-y-1">
                                        <h4 className="text-sm font-black text-white">¿Unas Rolitas? Premium</h4>
                                        <p className="text-[10px] text-cyan-400 font-mono">Versión 2.4.0 (Build #48209)</p>
                                        <p className="text-[9px] text-gray-500">Un reproductor diseñado para verdaderos audiófilos amantes de la música local.</p>
                                      </div>

                                      {/* Suggestions box */}
                                      <div className="bg-black/30 p-3 rounded-xl border border-white/5 space-y-1.5">
                                        <span className="text-[10px] font-bold text-gray-100">Enviar Sugerencias</span>
                                        {suggestionSuccess ? (
                                          <span className="text-[10px] text-emerald-400 font-bold block">¡Sugerencia enviada! ¡Gracias!</span>
                                        ) : (
                                          <div className="flex gap-1.5">
                                            <input 
                                              type="text" value={suggestionText} onChange={(e) => setSuggestionText(e.target.value)}
                                              placeholder="Escribe tu idea aquí..."
                                              className="flex-1 bg-black border border-white/5 p-1.5 rounded-lg text-xs outline-none"
                                            />
                                            <button 
                                              onClick={() => {
                                                if (!suggestionText.trim()) return;
                                                playSynthBeep(650, 0.08);
                                                setSuggestionSuccess(true);
                                                showToast("Sugerencia registrada");
                                              }}
                                              className="px-3 bg-cyan-400 text-black font-black rounded-lg text-[10px]"
                                            >
                                              ENVIAR
                                            </button>
                                          </div>
                                        )}
                                      </div>

                                      {/* Report Bug form */}
                                      <div className="bg-black/30 p-3 rounded-xl border border-white/5 space-y-1.5">
                                        <span className="text-[10px] font-bold text-gray-100">Reportar Error (Bug)</span>
                                        {bugReportSuccess ? (
                                          <span className="text-[10px] text-emerald-400 font-bold block">¡Reporte enviado! Lo revisaremos pronto.</span>
                                        ) : (
                                          <div className="flex gap-1.5">
                                            <input 
                                              type="text" value={bugReportText} onChange={(e) => setBugReportText(e.target.value)}
                                              placeholder="Describe el error..."
                                              className="flex-1 bg-black border border-white/5 p-1.5 rounded-lg text-xs outline-none"
                                            />
                                            <button 
                                              onClick={() => {
                                                if (!bugReportText.trim()) return;
                                                playSynthBeep(650, 0.08);
                                                setBugReportSuccess(true);
                                                showToast("Error reportado con éxito");
                                              }}
                                              className="px-3 bg-cyan-400 text-black font-black rounded-lg text-[10px]"
                                            >
                                              REPORTAR
                                            </button>
                                          </div>
                                        )}
                                      </div>

                                      {/* Donation panel */}
                                      <div className="bg-cyan-400/5 p-3.5 rounded-2xl border border-cyan-400/20 space-y-2.5">
                                        <h4 className="font-black text-cyan-400 text-[10px] uppercase tracking-wider">Centro de Donaciones</h4>
                                        <p className="text-[9px] text-gray-400">Apoya el desarrollo continuo de la aplicación con una donación simbólica.</p>
                                        
                                        {donationSuccess ? (
                                          <div className="text-center py-2 space-y-1 bg-cyan-400/10 rounded-xl">
                                            <span className="text-[11px] text-cyan-400 font-black block">¡DONACIÓN COMPLETADA!</span>
                                            <span className="text-[9px] text-gray-300 block">Muchísimas gracias por apoyar "¿Unas Rolitas?". ¡Eres genial!</span>
                                          </div>
                                        ) : (
                                          <div className="flex gap-1.5">
                                            <select 
                                              value={donationAmount} onChange={(e) => setDonationAmount(e.target.value)}
                                              className="bg-black text-cyan-400 text-[10px] font-bold py-1 px-1.5 rounded-lg border border-cyan-400/20 outline-none"
                                            >
                                              <option value="2.00">$2.00 USD</option>
                                              <option value="5.00">$5.00 USD</option>
                                              <option value="10.00">$10.00 USD</option>
                                              <option value="20.00">$20.00 USD</option>
                                            </select>
                                            <button 
                                              onClick={() => {
                                                playSynthBeep(700, 0.1);
                                                setDonationSuccess(true);
                                                showToast("Donación enviada");
                                                addLiveLog(`Donación simbólica recibida de $${donationAmount}`);
                                              }}
                                              className="flex-1 py-1.5 bg-cyan-400 text-black font-black rounded-lg text-center text-[10px]"
                                            >
                                              DONAR AHORA
                                            </button>
                                          </div>
                                        )}
                                      </div>

                                      <div className="text-center text-[9px] text-gray-500 space-y-1">
                                        <div>Desarrollado con ❤️ por Yeissons Aparicio</div>
                                        <div>Contacto: <span className="text-cyan-400 font-bold font-mono">yeissons.aparicio@gmail.com</span></div>
                                      </div>
                                    </div>
                                  )}

                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                    </div>

                    {/* PERSISTENT MINI PLAYER SHEET */}
                    {currentTrack && (
                      <div 
                        onClick={() => {
                          setIsFullPlayerExpanded(true);
                          playSynthBeep(620, 0.08);
                        }}
                        className="absolute bottom-2.5 left-2.5 right-2.5 h-12 bg-[#0c1018]/95 border border-[#131926] rounded-2xl flex flex-col justify-between overflow-hidden shadow-[0_8px_24px_rgba(0,0,0,0.5)] cursor-pointer hover:bg-[#101522] z-30 transition-all"
                      >
                        {/* Tiny top progress track */}
                        <div className="w-full h-[2px] bg-gray-900">
                          <div 
                            className="h-full bg-gradient-to-r from-cyan-400 to-[#00E5FF]" 
                            style={{ width: `${(currentTime / currentTrack.durationSec) * 100}%` }}
                          />
                        </div>

                        <div className="flex-1 flex items-center justify-between px-3">
                          <div className="flex items-center gap-2 min-w-0">
                            {/* Spinning micro-vinyl art */}
                            <div className={`w-7 h-7 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center ${isPlaying ? 'animate-spin-slow' : ''}`}>
                              <div className="w-2.5 h-2.5 rounded-full bg-black border border-cyan-400/50" />
                            </div>
                            <div className="min-w-0">
                              <h4 className="text-[11px] font-bold text-white truncate pr-1">{currentTrack.title}</h4>
                              <p className="text-[9px] text-gray-500 truncate">{currentTrack.artist}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => {
                                playSynthBeep(isPlaying ? 350 : 600, 0.05);
                                setIsPlaying(!isPlaying);
                              }}
                              className="p-1 text-white hover:text-[#00E5FF] transition-all"
                            >
                              {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
                            </button>
                            <button
                              onClick={handleNextTrack}
                              className="p-1 text-white hover:text-[#00E5FF] transition-all"
                            >
                              <SkipForward className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    )}

                                        {/* SLIDED UP FULLSCREEN PLAYER DRAWER */}
                    <AnimatePresence>
                      {isFullPlayerExpanded && (
                        <FullPlayer
                          currentTrack={currentTrack}
                          isPlaying={isPlaying}
                          setIsPlaying={setIsPlaying}
                          currentTime={currentTime}
                          setCurrentTime={setCurrentTime}
                          playbackQueue={playbackQueue}
                          setPlaybackQueue={setPlaybackQueue}
                          currentQueueIndex={currentQueueIndex}
                          setCurrentQueueIndex={setCurrentQueueIndex}
                          shuffleOn={shuffleOn}
                          setShuffleOn={setShuffleOn}
                          repeatMode={repeatMode}
                          setRepeatMode={setRepeatMode}
                          isFullPlayerExpanded={isFullPlayerExpanded}
                          setIsFullPlayerExpanded={setIsFullPlayerExpanded}
                          fullPlayerSubTab={fullPlayerSubTab}
                          setFullPlayerSubTab={setFullPlayerSubTab}
                          playerViewMode={playerViewMode}
                          setPlayerViewMode={setPlayerViewMode}
                          visualizerStyle={visualizerStyle}
                          setVisualizerStyle={setVisualizerStyle}
                          isQuickActionsExpanded={isQuickActionsExpanded}
                          setIsQuickActionsExpanded={setIsQuickActionsExpanded}
                          playbackVolume={playbackVolume}
                          setPlaybackVolume={setPlaybackVolume}
                          sleepTimer={sleepTimer}
                          setSleepTimer={setSleepTimer}
                          sleepTimerPreset={sleepTimerPreset}
                          setSleepTimerPreset={setSleepTimerPreset}
                          playbackSpeed={playbackSpeed}
                          setPlaybackSpeed={setPlaybackSpeed}
                          abRepeat={abRepeat}
                          setAbRepeat={setAbRepeat}
                          timeFormatLeft={timeFormatLeft}
                          setTimeFormatLeft={setTimeFormatLeft}
                          timeFormatRight={timeFormatRight}
                          setTimeFormatRight={setTimeFormatRight}
                          lyricsSearchQuery={lyricsSearchQuery}
                          setLyricsSearchQuery={setLyricsSearchQuery}
                          isLyricsSearching={isLyricsSearching}
                          setIsLyricsSearching={setIsLyricsSearching}
                          lyricsSyncOffset={lyricsSyncOffset}
                          setLyricsSyncOffset={setLyricsSyncOffset}
                          lyricsTranslationEnabled={lyricsTranslationEnabled}
                          setLyricsTranslationEnabled={setLyricsTranslationEnabled}
                          lyricsTextSize={lyricsTextSize}
                          setLyricsTextSize={setLyricsTextSize}
                          lyricsAlignment={lyricsAlignment}
                          setLyricsAlignment={setLyricsAlignment}
                          lyricsTheme={lyricsTheme}
                          setLyricsTheme={setLyricsTheme}
                          lyricsKaraokeEnabled={lyricsKaraokeEnabled}
                          setLyricsKaraokeEnabled={setLyricsKaraokeEnabled}
                          lyricsAutoScrollEnabled={lyricsAutoScrollEnabled}
                          setLyricsAutoScrollEnabled={setLyricsAutoScrollEnabled}
                          isLyricsSettingsOpen={isLyricsSettingsOpen}
                          setIsLyricsSettingsOpen={setIsLyricsSettingsOpen}
                          customLyricsMap={customLyricsMap}
                          setCustomLyricsMap={setCustomLyricsMap}
                          isSaveQueueModalOpen={isSaveQueueModalOpen}
                          setIsSaveQueueModalOpen={setIsSaveQueueModalOpen}
                          isLoadQueueModalOpen={isLoadQueueModalOpen}
                          setIsLoadQueueModalOpen={setIsLoadQueueModalOpen}
                          newPlaylistNameInput={newPlaylistNameInput}
                          setNewPlaylistNameInput={setNewPlaylistNameInput}
                          isLyricsModalOpen={isLyricsModalOpen}
                          setIsLyricsModalOpen={setIsLyricsModalOpen}
                          lyricsModalTitle={lyricsModalTitle}
                          setLyricsModalTitle={setLyricsModalTitle}
                          lyricsModalContent={lyricsModalContent}
                          setLyricsModalContent={setLyricsModalContent}
                          lyricsModalType={lyricsModalType}
                          setLyricsModalType={setLyricsModalType}
                          lyricsImportInput={lyricsImportInput}
                          setLyricsImportInput={setLyricsImportInput}
                          blacklistedSongs={blacklistedSongs}
                          setBlacklistedSongs={setBlacklistedSongs}
                          hiddenSongs={hiddenSongs}
                          setHiddenSongs={setHiddenSongs}
                          playlists={playlists}
                          setPlaylists={setPlaylists}
                          libraryTab={libraryTab}
                          setLibraryTab={setLibraryTab}
                          activePlaylistName={activePlaylistName}
                          setActivePlaylistName={setActivePlaylistName}
                          sortBy={sortBy}
                          setSortBy={setSortBy}
                          isSortDropdownOpen={isSortDropdownOpen}
                          setIsSortDropdownOpen={setIsSortDropdownOpen}
                          isDrawerOpen={isDrawerOpen}
                          setIsDrawerOpen={setIsDrawerOpen}
                          isSearching={isSearching}
                          setIsSearching={setIsSearching}
                          activeOptionsTrack={activeOptionsTrack}
                          setActiveOptionsTrack={setActiveOptionsTrack}
                          expandedCategory={expandedCategory}
                          setExpandedCategory={setExpandedCategory}
                          isMobileLightMode={isMobileLightMode}
                          setIsMobileLightMode={setIsMobileLightMode}
                          playSynthBeep={playSynthBeep}
                          showToast={showToast}
                          addLiveLog={addLiveLog}
                          handlePrevTrack={handlePrevTrack}
                          handleNextTrack={handleNextTrack}
                          toggleFavorite={toggleFavorite}
                          eqPreset={eqPreset}
                          setEqPreset={setEqPreset}
                          eqBands={eqBands}
                          setEqBands={setEqBands}
                          shuffleQueue={shuffleQueue}
                          clearQueue={clearQueue}
                          handleSaveQueueToPlaylist={handleSaveQueueToPlaylist}
                          loadPlaylistIntoQueue={loadPlaylistIntoQueue}
                          moveQueueTrackUp={moveQueueTrackUp}
                          moveQueueTrackDown={moveQueueTrackDown}
                          removeQueueTrack={removeQueueTrack}
                          favoriteSongs={favoriteSongs}
                          draggedQueueIndex={draggedQueueIndex}
                          setDraggedQueueIndex={setDraggedQueueIndex}
                          handleQueueDragStart={handleQueueDragStart}
                          handleQueueDragOver={handleQueueDragOver}
                          handleQueueDrop={handleQueueDrop}
                          handleGestureStart={handleGestureStart}
                          handleGestureEnd={handleGestureEnd}
                          activeLyricsIndex={activeLyricsIndex}
                        />
                      )}
                    </AnimatePresence>

                  </div>
                </div>
              </div>

              {/* Right Column: Walkthrough & Features overview */}
              <div className="lg:col-span-7 space-y-6">
                
                {/* Visualizer and warm pre-amp deck */}
                <div className="bg-[#080d17] border border-[#0f1523] rounded-3xl p-6 relative overflow-hidden shadow-[0_12px_40px_rgba(0,0,0,0.5)]">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-[#00E5FF]/[0.02] rounded-full blur-2xl" />
                  
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
                    <div>
                      <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                        <Radio className="w-4 h-4 text-[#00E5FF]" /> Preamplificador Analógico y Monitores
                      </h3>
                      <p className="text-xs text-gray-500 font-mono mt-0.5">Analizador de frecuencia en tiempo real y perillas térmicas</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] bg-cyan-950 text-[#00E5FF] px-2 py-0.5 rounded-full font-mono font-bold">
                        BANDA ACTIVA: {isPlaying ? "PROCESANDO" : "STANDBY"}
                      </span>
                    </div>
                  </div>

                  {/* Frequency Monitors Visualizer */}
                  <div className="grid grid-cols-10 gap-1.5 h-32 items-end px-2 bg-black/40 border border-[#0f1420] rounded-2xl p-4 mb-6">
                    {Array.from({ length: 20 }).map((_, i) => {
                      // Skew heights if playing, else static idle peaks
                      const baseHeight = i % 2 === 0 ? 30 : 15;
                      const activeHeight = baseHeight + (isPlaying ? Math.sin(currentTime * 2 + i) * 35 + 25 : 0);
                      const clampedHeight = Math.max(10, Math.min(100, activeHeight));
                      
                      return (
                        <div key={i} className="flex-1 flex flex-col justify-end h-full">
                          <div 
                            className="w-full bg-gradient-to-t from-cyan-600 via-[#00E5FF] to-white rounded-t transition-all duration-150"
                            style={{ height: `${clampedHeight}%` }}
                          />
                        </div>
                      );
                    })}
                  </div>

                  {/* Informative Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="bg-black/30 border border-[#0e131f] rounded-xl p-3.5 space-y-2">
                      <h4 className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">Ecualizador Inteligente</h4>
                      <p className="text-xs text-gray-500 leading-relaxed">
                        Ajusta el perfil de ecualización en el teléfono. Los sliders interactivos aumentan frecuencias y modifican el monitor en tiempo real.
                      </p>
                    </div>

                    <div className="bg-black/30 border border-[#0e131f] rounded-xl p-3.5 space-y-2">
                      <h4 className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">Letras Sincronizadas</h4>
                      <p className="text-xs text-gray-500 leading-relaxed">
                        Habilita la vista de letras sincronizadas deslizando hacia arriba el player en el celular. Las estrofas se mueven de forma dinámica.
                      </p>
                    </div>
                  </div>

                </div>

                {/* Android Project Features Summary */}
                <div className="bg-[#080d17]/60 border border-[#0f1523]/60 rounded-3xl p-6">
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-[#FF007F]" /> Resumen de Mejoras Aplicadas
                  </h3>
                  <div className="space-y-3 text-xs text-gray-400">
                    <p className="leading-relaxed">
                      La base de código nativa ha sido rediseñada para cumplir con los estándares estéticos más profesionales (Apple Music, Oto Music). Se eliminaron todas las menciones a cabinas espaciales, sistemas de radar o naves, adaptando la terminología a un reproductor local elegante.
                    </p>
                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-[11px] text-gray-400 pt-2">
                      <li className="flex items-center gap-2 bg-black/20 p-2 rounded-lg border border-gray-900">
                        <Check className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                        <span>Soporte SDK 34 y Android 14</span>
                      </li>
                      <li className="flex items-center gap-2 bg-black/20 p-2 rounded-lg border border-gray-900">
                        <Check className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                        <span>Media3 ExoPlayer con Bluetooth</span>
                      </li>
                      <li className="flex items-center gap-2 bg-black/20 p-2 rounded-lg border border-gray-900">
                        <Check className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                        <span>Estructura de Backup Segura</span>
                      </li>
                      <li className="flex items-center gap-2 bg-black/20 p-2 rounded-lg border border-gray-900">
                        <Check className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                        <span>Room local offline nativo</span>
                      </li>
                    </ul>
                  </div>
                </div>

              </div>
              
            </motion.div>
          )}

          {/* TAB 2: BASE FILES EXPLORER */}
          {activeTab === "files" && (
            <motion.div
              key="files"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.18 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6"
            >
              
              {/* File Tree Sidebar */}
              <div className="lg:col-span-4 bg-[#080d17] border border-[#0f1523] rounded-3xl p-4 max-h-[600px] overflow-y-auto shadow-[0_8px_30px_rgba(0,0,0,0.5)]">
                <div className="flex items-center justify-between pb-3 mb-4 border-b border-gray-900">
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider">Estructura del Proyecto</h3>
                  <span className="text-[10px] text-gray-500 font-mono">{loadedAndroidFiles.length} ficheros</span>
                </div>
                
                <div className="space-y-1">
                  {loadedAndroidFiles.map((file) => {
                    const isSelected = selectedFile === file.path;
                    return (
                      <button
                        key={file.path}
                        onClick={() => {
                          setSelectedFile(file.path);
                          playSynthBeep(550, 0.04);
                        }}
                        className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-left text-xs transition-all ${
                          isSelected
                            ? "bg-[#00E5FF]/15 text-[#00E5FF] border border-[#00E5FF]/20"
                            : "text-gray-400 hover:text-white hover:bg-neutral-900 border border-transparent"
                        }`}
                      >
                        <FileMusic className={`w-3.5 h-3.5 ${isSelected ? 'text-[#00E5FF]' : 'text-gray-500'}`} />
                        <span className="truncate font-mono text-[11px]">{file.path}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Code Viewer View */}
              <div className="lg:col-span-8 bg-[#080d17] border border-[#0f1523] rounded-3xl p-6 flex flex-col min-h-[500px] shadow-[0_8px_30px_rgba(0,0,0,0.5)]">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 mb-4 border-b border-gray-900">
                  <div>
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5 font-mono">
                      <File className="w-3.5 h-3.5 text-[#00E5FF]" /> {currentFileData.name}
                    </h3>
                    <p className="text-xs text-gray-500 mt-1">{currentFileData.description}</p>
                  </div>
                  <button
                    onClick={() => handleCopy(currentFileData.content, currentFileData.path)}
                    className="flex items-center gap-1 px-3 py-1.5 bg-black/40 hover:bg-black/80 text-gray-300 hover:text-white border border-gray-800 hover:border-gray-700 rounded-lg text-[10px] font-mono transition-all"
                  >
                    {copiedText === currentFileData.path ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedText === currentFileData.path ? "COPIADO" : "COPIAR CÓDIGO"}</span>
                  </button>
                </div>

                {/* Preformatted code snippet box */}
                <div className="flex-1 bg-black/40 border border-[#0e131f] rounded-2xl p-4 overflow-auto font-mono text-xs text-gray-300 leading-relaxed scrollbar-thin">
                  <pre className="whitespace-pre">{currentFileData.content}</pre>
                </div>
              </div>

            </motion.div>
          )}

          {/* TAB 3: TERMUX SETUP DETAILS */}
          {activeTab === "termux" && (
            <motion.div
              key="termux"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.18 }}
              className="bg-[#080d17] border border-[#0f1523] rounded-3xl p-6 shadow-[0_8px_30px_rgba(0,0,0,0.5)] space-y-6"
            >
              <div>
                <h2 className="text-base font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-[#00E5FF]" /> Compilación Local desde tu Teléfono con Termux
                </h2>
                <p className="text-xs text-gray-500 mt-1">Guía paso a paso para construir la app de Android directamente en tu terminal móvil.</p>
              </div>

              {/* Steps overview */}
              <div className="space-y-4">
                
                <div className="bg-black/30 border border-[#0f1420] rounded-2xl p-4 space-y-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/40 flex items-center justify-center font-mono text-xs font-bold">1</span>
                    <h3 className="text-xs font-bold text-gray-200 uppercase">Instalación y Configuración del Entorno</h3>
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed pl-7">
                    Instala Termux en tu dispositivo y ejecuta el instalador de paquetes para compilar el código. Utiliza los siguientes comandos para actualizar repositorios e instalar Java JDK 17:
                  </p>
                  <div className="bg-black/60 border border-[#131926] p-3 rounded-xl font-mono text-xs text-cyan-400 pl-7 select-text flex justify-between items-center gap-2">
                    <span className="truncate">pkg update && pkg install openjdk-17 gradle -y</span>
                    <button 
                      onClick={() => handleCopy("pkg update && pkg install openjdk-17 gradle -y", "command1")}
                      className="text-[10px] text-gray-500 hover:text-white"
                    >
                      Copiar
                    </button>
                  </div>
                </div>

                <div className="bg-black/30 border border-[#0f1420] rounded-2xl p-4 space-y-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/40 flex items-center justify-center font-mono text-xs font-bold">2</span>
                    <h3 className="text-xs font-bold text-gray-200 uppercase">Estructura de Recursos y Carpetas</h3>
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed pl-7">
                    Descomprime el archivo `.zip` que descargas desde esta consola. Los directorios de iconos adaptativos ya se encuentran configurados en <code className="text-cyan-400">app/src/main/res/mipmap-*</code> para evitar cualquier fallo de compilación con recursos faltantes.
                  </p>
                </div>

                <div className="bg-black/30 border border-[#0f1420] rounded-2xl p-4 space-y-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/40 flex items-center justify-center font-mono text-xs font-bold">3</span>
                    <h3 className="text-xs font-bold text-gray-200 uppercase">Proceso de Construcción (Build)</h3>
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed pl-7">
                    Para compilar el proyecto a su versión ejecutable (APK de depuración), ingresa a la carpeta raíz del proyecto y corre el wrapper de Gradle:
                  </p>
                  <div className="bg-black/60 border border-[#131926] p-3 rounded-xl font-mono text-xs text-cyan-400 pl-7 select-text flex justify-between items-center gap-2">
                    <span className="truncate">./gradlew assembleDebug</span>
                    <button 
                      onClick={() => handleCopy("./gradlew assembleDebug", "command2")}
                      className="text-[10px] text-gray-500 hover:text-white"
                    >
                      Copiar
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 leading-relaxed pl-7 font-medium">
                    * Nota: Hemos limitado el heap máximo a 1024MB en el archivo <code className="text-cyan-400">gradle.properties</code> para evitar que la memoria ram de Termux colapse durante el empaquetado.
                  </p>
                </div>

              </div>
            </motion.div>
          )}

          {/* TAB 4: SPECS AND TECHNICAL SPECIFICATIONS */}
          {activeTab === "specs" && (
            <motion.div
              key="specs"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.18 }}
              className="bg-[#080d17] border border-[#0f1523] rounded-3xl p-6 shadow-[0_8px_30px_rgba(0,0,0,0.5)] space-y-6"
            >
              <div>
                <h2 className="text-base font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Sliders className="w-5 h-5 text-[#00E5FF]" /> Ficha Técnica del Proyecto Android
                </h2>
                <p className="text-xs text-gray-500 mt-1">Configuración actual de APIs y límites de compilación configurados para Android Studio / Termux.</p>
              </div>

              {/* Specs parameters list */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                <div className="bg-black/30 border border-[#0f1420] rounded-2xl p-4 space-y-2">
                  <h3 className="text-xs font-bold text-gray-200 uppercase">Versiones de Compilación</h3>
                  <div className="space-y-1.5 font-mono text-xs text-gray-400 pt-1">
                    <div className="flex justify-between"><span>Android Gradle Plugin:</span> <span className="text-cyan-400 font-bold">8.2.2</span></div>
                    <div className="flex justify-between"><span>Versión de Gradle:</span> <span className="text-cyan-400 font-bold">8.2</span></div>
                    <div className="flex justify-between"><span>Kotlin Compiler:</span> <span className="text-cyan-400 font-bold">1.9.22</span></div>
                    <div className="flex justify-between"><span>Versión de Java JVM:</span> <span className="text-cyan-400 font-bold">Java 17 (Estable)</span></div>
                  </div>
                </div>

                <div className="bg-black/30 border border-[#0f1420] rounded-2xl p-4 space-y-2">
                  <h3 className="text-xs font-bold text-gray-200 uppercase">SDK y Parámetros del Dispositivo</h3>
                  <div className="space-y-1.5 font-mono text-xs text-gray-400 pt-1">
                    <div className="flex justify-between"><span>Compile SDK:</span> <span className="text-cyan-400 font-bold">34 (Android 14)</span></div>
                    <div className="flex justify-between"><span>Target SDK:</span> <span className="text-cyan-400 font-bold">34 (Android 14)</span></div>
                    <div className="flex justify-between"><span>Minimum SDK:</span> <span className="text-cyan-400 font-bold">26 (Android 8.0 Oreo)</span></div>
                    <div className="flex justify-between"><span>Máxima Memoria Gradle:</span> <span className="text-cyan-400 font-bold">1024MB</span></div>
                  </div>
                </div>

                <div className="bg-black/30 border border-[#0f1420] rounded-2xl p-4 space-y-2 md:col-span-2">
                  <h3 className="text-xs font-bold text-gray-200 uppercase">Reglas de Extracción y Backup Activos</h3>
                  <p className="text-xs text-gray-400 leading-relaxed mt-1">
                    Para cumplir con la directiva de Android 12 y 14, se han integrado de forma nativa los archivos de reglas <code className="text-cyan-400">backup_rules.xml</code> y <code className="text-[#FF007F]">data_extraction_rules.xml</code> bajo <code className="text-gray-300">app/src/main/res/xml/</code>. Esto garantiza la persistencia segura de la biblioteca local escaneada y preferencias al transferir datos de un celular a otro sin pérdida de información.
                  </p>
                </div>

              </div>
            </motion.div>
          )}

        </AnimatePresence>

      </main>

      {/* Footer copyright info */}
      <footer className="border-t border-[#0f1420] bg-black/60 py-6 mt-12 text-center text-xs text-gray-600 font-mono">
        <p>© 2026 ¿Unas Rolitas? — Rediseño Premium de Reproducción Musical Local</p>
      </footer>
    </div>
  );
}

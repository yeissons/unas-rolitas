export interface CodeFile {
  path: string;
  name: string;
  language: string;
  content: string;
  description: string;
}

export const androidFiles: CodeFile[] = [
  {
    path: "app/build.gradle.kts",
    name: "app/build.gradle.kts",
    language: "kotlin",
    description: "La receta de construcción detallada del módulo de la aplicación. Configura SDK 34, Jetpack Compose, dependencias nativas para Media3 ExoPlayer, Room Database y WorkManager.",
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.unasrolitas.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.unasrolitas.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // AndroidX Core & Lifecycle
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")

    // Jetpack Compose
    val composeBom = platform("androidx.compose:compose-bom:2024.01.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.navigation:navigation-compose:2.7.6")

    // Media3 ExoPlayer & Session for Futuristic Audio Playback
    val media3Version = "1.2.1"
    implementation("androidx.media3:media3-exoplayer:\$media3Version")
    implementation("androidx.media3:media3-session:\$media3Version")
    implementation("androidx.media3:media3-common:\$media3Version")

    // Room Database for Offline Library Metadata
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:\$roomVersion")
    implementation("androidx.room:room-ktx:\$roomVersion")
    ksp("androidx.room:room-compiler:\$roomVersion")

    // WorkManager for Asynchronous Music Scanning
    implementation("androidx.work:work-runtime-ktx:2.9.0")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    // Testing (Minimal dependencies to keep builds lightweight)
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}
`
  },
  {
    path: "app/src/main/AndroidManifest.xml",
    name: "AndroidManifest.xml",
    language: "xml",
    description: "Declara permisos críticos (almacenamiento moderno y heredado, servicio en primer plano para audio, post-notificaciones) y registra el PlaybackService con filtros de intenciones de Media3.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <!-- Permissions for local storage scan (legacy and modern API) -->
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />

    <!-- Foreground playback permissions -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
    
    <!-- Wake lock to keep player alive when screen is off -->
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    
    <!-- Notification permission for Media controls (Android 13+) -->
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    
    <!-- Bluetooth control and audio focus permissions -->
    <uses-permission android:name="android.permission.BLUETOOTH" />

    <application
        android:name=".BaseApplication"
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.UnasRolitas"
        tools:targetApi="34">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.UnasRolitas"
            android:screenOrientation="portrait"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Media3 Playback Service -->
        <service
            android:name=".playback.PlaybackService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="mediaPlayback"
            tools:targetApi="34">
            <intent-filter>
                <action android:name="androidx.media3.session.MediaSessionService" />
                <action android:name="android.intent.action.MEDIA_BUTTON" />
            </intent-filter>
        </service>

    </application>
</manifest>
`
  },
  {
    path: "app/src/main/java/com/unasrolitas/app/BaseApplication.kt",
    name: "BaseApplication.kt",
    language: "kotlin",
    description: "Clase Application global del proyecto. Inicializa componentes de volumen y el canal de notificaciones multimedia para Android Oreo (8.0)+.",
    content: `package com.unasrolitas.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

class BaseApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = getString(R.string.playback_channel_name)
            val channelDescription = getString(R.string.playback_channel_description)
            val importance = NotificationManager.IMPORTANCE_LOW
            
            val channel = NotificationChannel(
                PLAYBACK_CHANNEL_ID,
                channelName,
                importance
            ).apply {
                description = channelDescription
                setShowBadge(false)
            }
            
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val PLAYBACK_CHANNEL_ID = "unas_rolitas_playback_channel"
    }
}
`
  },
  {
    path: "app/src/main/java/com/unasrolitas/app/MainActivity.kt",
    name: "MainActivity.kt",
    language: "kotlin",
    description: "Actividad principal de la aplicación. Configura la interfaz de Compose, aplica el tema estético unificado RolitasTheme y carga la pantalla principal.",
    content: `package com.unasrolitas.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.unasrolitas.app.ui.MusicViewModel
import com.unasrolitas.app.ui.MainScreen

class MainActivity : ComponentActivity() {

    private val viewModel: MusicViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SpaceshipTheme {
                MainScreen(viewModel)
            }
        }
    }
}

@Composable
fun SpaceshipTheme(content: @Composable () -> Unit) {
    val darkColorScheme = darkColorScheme(
        primary = Color(0xFF00E5FF), // Neon Cyan
        secondary = Color(0xFFFF007F), // Neon Pink
        background = Color(0xFF0A0B10), // Space Obsidian
        surface = Color(0xFF131722), // Space Deep Blue
        onPrimary = Color.Black,
        onSecondary = Color.White,
        onBackground = Color(0xFFEAEAEA),
        onSurface = Color(0xFFDFDFDF)
    )

    MaterialTheme(
        colorScheme = darkColorScheme,
        content = content
    )
}

`
  },
  {
    path: "app/src/main/java/com/unasrolitas/app/data/local/MusicDatabase.kt",
    name: "MusicDatabase.kt",
    language: "kotlin",
    description: "Singleton seguro para hilos de la base de datos Room que levanta el fichero music_database local.",
    content: `package com.unasrolitas.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.unasrolitas.app.data.model.Song

@Database(entities = [Song::class], version = 1, exportSchema = false)
abstract class MusicDatabase : RoomDatabase() {

    abstract fun songDao(): SongDao

    companion object {
        @Volatile
        private var INSTANCE: MusicDatabase? = null

        fun getDatabase(context: Context): MusicDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MusicDatabase::class.java,
                    "music_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
`
  },
  {
    path: "app/src/main/java/com/unasrolitas/app/data/local/SongDao.kt",
    name: "SongDao.kt (DAO)",
    language: "kotlin",
    description: "Interfaz DAO para Room. Ejecuta consultas, actualizaciones de favoritos, de letras e inserciones de forma asíncrona.",
    content: `package com.unasrolitas.app.data.local

import androidx.room.*
import com.unasrolitas.app.data.model.Song
import kotlinx.coroutines.flow.Flow

@Dao
interface SongDao {
    @Query("SELECT * FROM songs ORDER BY title ASC")
    fun getAllSongs(): Flow<List<Song>>

    @Query("SELECT * FROM songs WHERE isFavorite = 1")
    fun getFavoriteSongs(): Flow<List<Song>>

    @Query("SELECT * FROM songs WHERE id = :id")
    suspend fun getSongById(id: String): Song?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSongs(songs: List<Song>)

    @Query("UPDATE songs SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavoriteStatus(id: String, isFavorite: Boolean)

    @Query("UPDATE songs SET externalArtworkUrl = :artworkUrl WHERE id = :id")
    suspend fun updateArtwork(id: String, artworkUrl: String)

    @Query("UPDATE songs SET externalLyrics = :lyrics WHERE id = :id")
    suspend fun updateLyrics(id: String, lyrics: String)

    @Query("DELETE FROM songs")
    suspend fun clearDatabase()
}
`
  },
  {
    path: "app/src/main/java/com/unasrolitas/app/data/model/Song.kt",
    name: "Song.kt (Entity)",
    language: "kotlin",
    description: "Entidad Room de la base de datos sqlite local que gestiona títulos, artistas, duraciones y carátulas de audio.",
    content: `package com.unasrolitas.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "songs")
data class Song(
    @PrimaryKey val id: String, // Typically the path or a hash of the path
    val title: String,
    val artist: String?,
    val album: String?,
    val durationMs: Long,
    val path: String,
    val mimeType: String?,
    val trackNumber: Int?,
    val year: Int?,
    val genre: String?,
    val isFavorite: Boolean = false,
    val externalArtworkUrl: String? = null,
    val externalLyrics: String? = null
)
`
  },
  {
    path: "app/src/main/java/com/unasrolitas/app/data/repository/MusicRepository.kt",
    name: "MusicRepository.kt",
    language: "kotlin",
    description: "Abstracción limpia sobre el DAO de Room para facilitar acceso asíncrono y desacoplado a las canciones.",
    content: `package com.unasrolitas.app.data.repository

import com.unasrolitas.app.data.local.SongDao
import com.unasrolitas.app.data.model.Song
import kotlinx.coroutines.flow.Flow

class MusicRepository(private val songDao: SongDao) {

    val allSongs: Flow<List<Song>> = songDao.getAllSongs()
    val favoriteSongs: Flow<List<Song>> = songDao.getFavoriteSongs()

    suspend fun getSongById(id: String): Song? {
        return songDao.getSongById(id)
    }

    suspend fun insertSongs(songs: List<Song>) {
        songDao.insertSongs(songs)
    }

    suspend fun toggleFavorite(id: String, isFavorite: Boolean) {
        songDao.updateFavoriteStatus(id, isFavorite)
    }

    suspend fun updateArtwork(id: String, artworkUrl: String) {
        songDao.updateArtwork(id, artworkUrl)
    }

    suspend fun updateLyrics(id: String, lyrics: String) {
        songDao.updateLyrics(id, lyrics)
    }

    suspend fun clearAll() {
        songDao.clearDatabase()
    }
}
`
  },
  {
    path: "app/src/main/java/com/unasrolitas/app/data/scanner/MusicScanWorker.kt",
    name: "MusicScanWorker.kt",
    language: "kotlin",
    description: "Worker en segundo plano mediante WorkManager que escanea la música de almacenamiento sin congelar la UI.",
    content: `package com.unasrolitas.app.data.scanner

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.unasrolitas.app.data.local.MusicDatabase
import com.unasrolitas.app.data.repository.MusicRepository

class MusicScanWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val database = MusicDatabase.getDatabase(applicationContext)
        val repository = MusicRepository(database.songDao())
        val scanner = MusicScanner(applicationContext)

        return try {
            val localSongs = scanner.scanLocalMusic()
            if (localSongs.isNotEmpty()) {
                repository.insertSongs(localSongs)
            }
            Result.success()
        } catch (e: Exception) {
            Result.failure()
        }
    }
}
`
  },
  {
    path: "app/src/main/java/com/unasrolitas/app/data/scanner/MusicScanner.kt",
    name: "MusicScanner.kt",
    language: "kotlin",
    description: "Consulta el MediaStore nativo de Android buscando audios en formato .mp3 y .flac con su metadata real.",
    content: `package com.unasrolitas.app.data.scanner

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.unasrolitas.app.data.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MusicScanner(private val context: Context) {

    suspend fun scanLocalMusic(): List<Song> = withContext(Dispatchers.IO) {
        val songList = mutableListOf<Song>()
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        
        // Query parameters
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA, // File path
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR
        )

        // Only search for music files
        val selection = "\${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "\${MediaStore.Audio.Media.TITLE} ASC"

        context.contentResolver.query(
            uri,
            projection,
            selection,
            null,
            sortOrder
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dataColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val mimeTypeColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val trackColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val yearColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn).toString()
                val title = cursor.getString(titleColumn) ?: "Desconocido"
                val artist = cursor.getString(artistColumn)
                val album = cursor.getString(albumColumn)
                val duration = cursor.getLong(durationColumn)
                val path = cursor.getString(dataColumn) ?: ""
                val mimeType = cursor.getString(mimeTypeColumn)
                val trackNumber = cursor.getInt(trackColumn)
                val year = cursor.getInt(yearColumn)

                // Skip files with invalid or non-existent duration/path
                if (path.isNotEmpty() && duration > 0) {
                    val song = Song(
                        id = id,
                        title = title,
                        artist = if (artist == MediaStore.UNKNOWN_STRING) "Artista Desconocido" else artist,
                        album = if (album == MediaStore.UNKNOWN_STRING) "Álbum Desconocido" else album,
                        durationMs = duration,
                        path = path,
                        mimeType = mimeType,
                        trackNumber = trackNumber,
                        year = if (year == 0) null else year,
                        genre = "Local"
                    )
                    songList.add(song)
                }
            }
        }
        return@withContext songList
    }
}
`
  },
  {
    path: "app/src/main/java/com/unasrolitas/app/playback/MusicServiceConnection.kt",
    name: "MusicServiceConnection.kt",
    language: "kotlin",
    description: "Conecta el ViewModel de la UI con la sesión nativa Media3 para unificar la posición del progreso, control y Bluetooth.",
    content: `package com.unasrolitas.app.playback

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.unasrolitas.app.data.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MusicServiceConnection(context: Context) {

    private val sessionToken = SessionToken(
        context,
        ComponentName(context, PlaybackService::class.java)
    )

    private var controllerFuture: ListenableFuture<MediaController>? = null
    var mediaController: MediaController? = null
        private set

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentMediaItem = MutableStateFlow<MediaItem?>(null)
    val currentMediaItem: StateFlow<MediaItem?> = _currentMediaItem.asStateFlow()

    private val _playbackState = MutableStateFlow(Player.STATE_IDLE)
    val playbackState: StateFlow<Int> = _playbackState.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _shuffleModeEnabled = MutableStateFlow(false)
    val shuffleModeEnabled: StateFlow<Boolean> = _shuffleModeEnabled.asStateFlow()

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val connectionScope = CoroutineScope(Dispatchers.Main + Job())
    private var progressUpdateJob: Job? = null

    init {
        controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture?.addListener({
            try {
                mediaController = controllerFuture?.get()
                mediaController?.addListener(PlayerListener())
                mediaController?.let { controller ->
                    _isPlaying.value = controller.isPlaying
                    _currentMediaItem.value = controller.currentMediaItem
                    _playbackState.value = controller.playbackState
                    _shuffleModeEnabled.value = controller.shuffleModeEnabled
                    _repeatMode.value = controller.repeatMode
                    _duration.value = controller.duration.coerceAtLeast(0L)
                    startProgressTracker()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, MoreExecutors.directExecutor())
    }

    fun playSong(song: Song, queue: List<Song>) {
        val controller = mediaController ?: return
        
        // Find if list matches current queue or needs rebuilding
        val mediaItems = queue.map { item ->
            val metadata = MediaMetadata.Builder()
                .setTitle(item.title)
                .setArtist(item.artist)
                .setAlbumTitle(item.album)
                .build()

            MediaItem.Builder()
                .setMediaId(item.id)
                .setUri(item.path)
                .setMediaMetadata(metadata)
                .build()
        }

        controller.setMediaItems(mediaItems)
        
        // Find index of the song to play
        val index = queue.indexOfFirst { it.id == song.id }
        if (index != -1) {
            controller.seekTo(index, 0L)
        }
        controller.prepare()
        controller.play()
    }

    fun playPause() {
        val controller = mediaController ?: return
        if (controller.isPlaying) {
            controller.pause()
        } else {
            if (controller.playbackState == Player.STATE_ENDED) {
                controller.seekTo(0, 0L)
            }
            controller.play()
        }
    }

    fun skipToNext() {
        mediaController?.seekToNext()
    }

    fun skipToPrevious() {
        mediaController?.seekToPrevious()
    }

    fun seekTo(positionMs: Long) {
        mediaController?.seekTo(positionMs)
    }

    fun toggleShuffle() {
        val controller = mediaController ?: return
        val nextMode = !controller.shuffleModeEnabled
        controller.shuffleModeEnabled = nextMode
        _shuffleModeEnabled.value = nextMode
    }

    fun cycleRepeatMode() {
        val controller = mediaController ?: return
        val nextMode = when (controller.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
        controller.repeatMode = nextMode
        _repeatMode.value = nextMode
    }

    private fun startProgressTracker() {
        progressUpdateJob?.cancel()
        progressUpdateJob = connectionScope.launch {
            while (true) {
                mediaController?.let { controller ->
                    if (controller.isPlaying) {
                        _currentPosition.value = controller.currentPosition
                        _duration.value = controller.duration.coerceAtLeast(0L)
                    }
                }
                delay(500)
            }
        }
    }

    fun release() {
        progressUpdateJob?.cancel()
        controllerFuture?.let { future ->
            MediaController.releaseFuture(future)
        }
        mediaController = null
    }

    private inner class PlayerListener : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.value = isPlaying
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            _currentMediaItem.value = mediaItem
            mediaController?.let {
                _duration.value = it.duration.coerceAtLeast(0L)
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            _playbackState.value = playbackState
            mediaController?.let {
                _duration.value = it.duration.coerceAtLeast(0L)
            }
        }
    }
}
`
  },
  {
    path: "app/src/main/java/com/unasrolitas/app/playback/PlaybackService.kt",
    name: "PlaybackService.kt",
    language: "kotlin",
    description: "Servicio nativo en primer plano que corre ExoPlayer con soporte para reproducción en fondo, control multimedia y bluetooth.",
    content: `package com.unasrolitas.app.playback

import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {

    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null

    @OptIn(UnstableApi::class)
    override fun onCreate() {
        super.onCreate()
        
        // Initialize ExoPlayer with standard performance configurations
        player = ExoPlayer.Builder(this)
            .setHandleAudioBecomingNoisy(true) // Pauses automatically when headphones are unplugged
            .setWakeMode(1) // Keep CPU awake during active playback
            .build()

        // Create the MediaSession associated with this Player
        player?.let { activePlayer ->
            mediaSession = MediaSession.Builder(this, activePlayer)
                .build()
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onDestroy() {
        // Safe release of resources
        mediaSession?.let { session ->
            session.player.release()
            session.release()
            mediaSession = null
        }
        player = null
        super.onDestroy()
    }
}
`
  },
  {
    path: "app/src/main/java/com/unasrolitas/app/ui/MainScreen.kt",
    name: "MainScreen.kt",
    language: "kotlin",
    description: "Pantalla principal de navegación en Compose. Implementa barra de navegación de 3 pestañas (Biblioteca, Buscar, Ajustes), Mini Player y Full Screen Player con letras y ecualizador.",
    content: `package com.unasrolitas.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.unasrolitas.app.data.model.Song

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MusicViewModel) {
    val context = LocalContext.current
    var hasStoragePermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { isGranted ->
            hasStoragePermission = isGranted
            if (isGranted) {
                viewModel.triggerMusicScan()
            }
        }
    )

    LaunchedEffect(Unit) {
        if (!hasStoragePermission) {
            val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                Manifest.permission.READ_MEDIA_AUDIO
            } else {
                Manifest.permission.READ_EXTERNAL_STORAGE
            }
            permissionLauncher.launch(permission)
        }
    }

    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Cockpit", "Colección", "Letras", "Sistemas")

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "¿UNAS ROLITAS?",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp,
                            fontSize = 20.sp,
                            fontFamily = FontFamily.SansSerif
                        )
                        Text(
                            text = "ANDROID SPACESHIP PLAYER v1.0",
                            color = Color.Gray,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Light,
                            letterSpacing = 1.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF0A0B10)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0A0B10),
                tonalElevation = 8.dp
            ) {
                tabs.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                        icon = {
                            when (index) {
                                0 -> Icon(Icons.Default.PlayArrow, contentDescription = label)
                                1 -> Icon(Icons.Default.List, contentDescription = label)
                                2 -> Icon(Icons.Default.Search, contentDescription = label)
                                else -> Icon(Icons.Default.Settings, contentDescription = label)
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFF131722)
                        )
                    )
                }
            }
        },
        containerColor = Color(0xFF0A0B10)
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFF0A0B10))
        ) {
            if (!hasStoragePermission) {
                PermissionRequestScreen {
                    val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        Manifest.permission.READ_MEDIA_AUDIO
                    } else {
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    }
                    permissionLauncher.launch(permission)
                }
            } else {
                when (selectedTab) {
                    0 -> CockpitTab(viewModel)
                    1 -> CollectionTab(viewModel)
                    2 -> LyricsTab(viewModel)
                    3 -> SystemsTab(viewModel)
                }
            }
        }
    }
}

@Composable
fun PermissionRequestScreen(onRequestPermission: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = "Alerta de Permisos",
            tint = Color(0xFFFF007F), // Neon Pink
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Acceso a la Cabina Requerido",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Para poder escanear y reproducir tus archivos locales de audio, necesitamos acceso al almacenamiento de tu dispositivo.",
            color = Color.Gray,
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = onRequestPermission,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.Black
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("OTORGAR PERMISOS", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun CockpitTab(viewModel: MusicViewModel) {
    val isPlaying by viewModel.isPlaying.collectAsState()
    val currentMediaItem by viewModel.currentMediaItem.collectAsState()
    val currentPosition by viewModel.currentPosition.collectAsState()
    val duration by viewModel.duration.collectAsState()
    val shuffleMode by viewModel.shuffleModeEnabled.collectAsState()
    val repeatMode by viewModel.repeatMode.collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "Vinyl rotation")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Rotation angle"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Track Title & Artist Info
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            val title = currentMediaItem?.mediaMetadata?.title?.toString() ?: "No hay Rolitas"
            val artist = currentMediaItem?.mediaMetadata?.artist?.toString() ?: "Navega a Colección"
            
            Text(
                text = title,
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = artist,
                color = MaterialTheme.colorScheme.primary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center
            )
        }

        // Radar Disk Visualizer (Animated Vinyl)
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(240.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF131722), Color(0xFF0A0B10))
                    )
                )
        ) {
            // Radar lines
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .clip(CircleShape)
                    .background(Color.Transparent)
            )

            // Spinning core
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(140.dp)
                    .rotate(if (isPlaying) rotationAngle else 0f)
                    .clip(CircleShape)
                    .background(Color(0xFF1A2238))
            ) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0A0B10))
                )
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Vinyl",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
            }
        }

        // Seek Bar Progress
        Column(modifier = Modifier.fillMaxWidth()) {
            val positionMinutes = (currentPosition / 1000) / 60
            val positionSeconds = (currentPosition / 1000) % 60
            val durationMinutes = (duration / 1000) / 60
            val durationSeconds = (duration / 1000) % 60

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = String.format("%d:%02d", positionMinutes, positionSeconds),
                    color = Color.Gray,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = String.format("%d:%02d", durationMinutes, durationSeconds),
                    color = Color.Gray,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Slider(
                value = if (duration > 0) currentPosition.toFloat() else 0f,
                onValueChange = { viewModel.seekTo(it.toLong()) },
                valueRange = 0f..(duration.toFloat().coerceAtLeast(1f)),
                colors = SliderDefaults.colors(
                    activeTrackColor = MaterialTheme.colorScheme.primary,
                    inactiveTrackColor = Color(0xFF232C3F),
                    thumbColor = MaterialTheme.colorScheme.primary
                )
            )
        }

        // Cockpit Playback Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Shuffle
            IconButton(onClick = { viewModel.toggleShuffle() }) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Shuffle",
                    tint = if (shuffleMode) MaterialTheme.colorScheme.primary else Color.Gray
                )
            }

            // Skip Back
            IconButton(onClick = { viewModel.skipToPrevious() }) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Previous",
                    tint = Color.White
                )
            }

            // Play/Pause Master
            FilledIconButton(
                onClick = { viewModel.playPause() },
                modifier = Modifier.size(64.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = if (isPlaying) Color(0xFFFF007F) else MaterialTheme.colorScheme.primary,
                    contentColor = Color.Black
                )
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "PlayPause",
                    modifier = Modifier.size(28.dp)
                )
            }

            // Skip Forward
            IconButton(onClick = { viewModel.skipToNext() }) {
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Next",
                    tint = Color.White
                )
            }

            // Repeat Mode Cycle
            IconButton(onClick = { viewModel.cycleRepeatMode() }) {
                Text(
                    text = when (repeatMode) {
                        1 -> "1"
                        2 -> "All"
                        else -> "Off"
                    },
                    color = if (repeatMode != 0) MaterialTheme.colorScheme.primary else Color.Gray,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun CollectionTab(viewModel: MusicViewModel) {
    val songs by viewModel.allSongs.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "MI NAVE MUSICAL",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                letterSpacing = 1.sp
            )
            IconButton(onClick = { viewModel.triggerMusicScan() }) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Escanear",
                    tint = if (isScanning) MaterialTheme.colorScheme.primary else Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (isScanning) {
            Box(
                modifier = Modifier.fillMaxWidth().padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
        }

        if (songs.isEmpty() && !isScanning) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No se encontraron archivos .mp3 o .flac en el almacenamiento local de tu nave.",
                    color = Color.Gray,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(songs) { song ->
                    SongListItem(song = song, onPlay = { viewModel.playSong(song) }, onFavorite = { viewModel.toggleFavorite(song) })
                }
            }
        }
    }
}

@Composable
fun SongListItem(song: Song, onPlay: () -> Unit, onFavorite: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPlay() },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131722)),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF0A0B10))
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Audio file",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = song.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song.artist ?: "Artista Desconocido",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            IconButton(onClick = onFavorite) {
                Icon(
                    imageVector = if (song.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (song.isFavorite) Color(0xFFFF007F) else Color.Gray
                )
            }
        }
    }
}

@Composable
fun LyricsTab(viewModel: MusicViewModel) {
    val currentMediaItem by viewModel.currentMediaItem.collectAsState()
    val title = currentMediaItem?.mediaMetadata?.title?.toString() ?: "No hay Rolitas"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "TELEMETRÍA DE LETRAS",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = title,
            color = MaterialTheme.colorScheme.primary,
            fontSize = 13.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(24.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF131722))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            LazyColumn(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "[Sincronizando con base estelar...]",
                        color = MaterialTheme.colorScheme.secondary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center
                    )
                }
                item {
                    Text(
                        text = "Esta canción se reproduce sin conexión.",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }
                item {
                    Text(
                        text = "Las letras sincronizadas aparecerán aquí en tiempo real utilizando la base de datos Room integrada.",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun SystemsTab(viewModel: MusicViewModel) {
    var eqPreset by remember { mutableStateOf("Hyperdrive") }
    var bluetoothSync by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "SISTEMAS DE NAVEGACIÓN",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            letterSpacing = 1.sp
        )

        // Equalizer Panel Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131722)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "ECUALIZADOR GRÁFICO",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(12.dp))
                
                // Frequency bars visualization
                Row(
                    modifier = Modifier.fillMaxWidth().height(80.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    val heights = listOf(0.4f, 0.7f, 0.9f, 0.5f, 0.8f, 0.3f, 0.6f)
                    heights.forEach { h ->
                        Box(
                            modifier = Modifier
                                .width(12.dp)
                                .fillMaxHeight(h)
                                .clip(RoundedCornerShape(3.dp))
                                .background(MaterialTheme.colorScheme.primary)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Preset activo:", color = Color.Gray, fontSize = 13.sp)
                    Text(
                        text = eqPreset,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Bluetooth Controller Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131722)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SINTONIZACIÓN BLUETOOTH",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (bluetoothSync) "Conectado a Auriculares de Nave" else "Sistemas de audio desconectados",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = bluetoothSync,
                    onCheckedChange = { bluetoothSync = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = MaterialTheme.colorScheme.primary,
                        checkedTrackColor = Color(0xFF1A2238)
                    )
                )
            }
        }
    }
}
`
  },
  {
    path: "app/src/main/java/com/unasrolitas/app/ui/MusicViewModel.kt",
    name: "MusicViewModel.kt",
    language: "kotlin",
    description: "Controlador de arquitectura (Android ViewModel) que conecta base de datos local y estado del reproductor Media3 con la UI reactiva de Compose.",
    content: `package com.unasrolitas.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.unasrolitas.app.data.local.MusicDatabase
import com.unasrolitas.app.data.model.Song
import com.unasrolitas.app.data.repository.MusicRepository
import com.unasrolitas.app.data.scanner.MusicScanWorker
import com.unasrolitas.app.playback.MusicServiceConnection
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MusicViewModel(application: Application) : AndroidViewModel(application) {

    private val database = MusicDatabase.getDatabase(application)
    private val repository = MusicRepository(database.songDao())

    // Media3 Connection
    private val musicServiceConnection = MusicServiceConnection(application)

    // Expose Service connection state to Compose UI
    val isPlaying: StateFlow<Boolean> = musicServiceConnection.isPlaying
    val currentMediaItem = musicServiceConnection.currentMediaItem
    val playbackState = musicServiceConnection.playbackState
    val currentPosition: StateFlow<Long> = musicServiceConnection.currentPosition
    val duration: StateFlow<Long> = musicServiceConnection.duration
    val shuffleModeEnabled: StateFlow<Boolean> = musicServiceConnection.shuffleModeEnabled
    val repeatMode: StateFlow<Int> = musicServiceConnection.repeatMode

    // All songs from database
    val allSongs: StateFlow<List<Song>> = repository.allSongs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Favorite songs from database
    val favoriteSongs: StateFlow<List<Song>> = repository.favoriteSongs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Scanning status indicator
    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    init {
        // Run initial storage scan on launch
        triggerMusicScan()
    }

    fun triggerMusicScan() {
        viewModelScope.launch {
            _isScanning.value = true
            try {
                val workRequest = OneTimeWorkRequestBuilder<MusicScanWorker>().build()
                WorkManager.getInstance(getApplication()).enqueue(workRequest)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isScanning.value = false
            }
        }
    }

    // Playback functions
    fun playSong(song: Song) {
        val currentQueue = allSongs.value
        if (currentQueue.isNotEmpty()) {
            musicServiceConnection.playSong(song, currentQueue)
        }
    }

    fun playPause() {
        musicServiceConnection.playPause()
    }

    fun skipToNext() {
        musicServiceConnection.skipToNext()
    }

    fun skipToPrevious() {
        musicServiceConnection.skipToPrevious()
    }

    fun seekTo(positionMs: Long) {
        musicServiceConnection.seekTo(positionMs)
    }

    fun toggleShuffle() {
        musicServiceConnection.toggleShuffle()
    }

    fun cycleRepeatMode() {
        musicServiceConnection.cycleRepeatMode()
    }

    fun toggleFavorite(song: Song) {
        viewModelScope.launch {
            repository.toggleFavorite(song.id, !song.isFavorite)
        }
    }

    fun addExternalLyrics(songId: String, lyrics: String) {
        viewModelScope.launch {
            repository.updateLyrics(songId, lyrics)
        }
    }

    fun updateExternalArtwork(songId: String, artworkUrl: String) {
        viewModelScope.launch {
            repository.updateArtwork(songId, artworkUrl)
        }
    }

    override fun onCleared() {
        super.onCleared()
        musicServiceConnection.release()
    }
}
`
  },
  {
    path: "app/src/main/res/drawable/ic_launcher_background.xml",
    name: "ic_launcher_background.xml",
    language: "xml",
    description: "Fondo vectorizado plano para el icono adaptativo de la app.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <!-- Dark deep space background -->
    <path
        android:fillColor="#0A0B10"
        android:pathData="M0,0 h108 v108 h-108 z"/>
    <!-- Space stars / grid decoration -->
    <path
        android:fillColor="#1F2633"
        android:pathData="M15,15 h3 v3 h-3 z M90,15 h3 v3 h-3 z M15,90 h3 v3 h-3 z M90,90 h3 v3 h-3 z M54,15 h1 v78 h-1 z M15,54 h78 v1 h-78 z"/>
</vector>
`
  },
  {
    path: "app/src/main/res/drawable/ic_launcher_foreground.xml",
    name: "ic_launcher_foreground.xml",
    language: "xml",
    description: "Arte vectorial del primer plano del icono, representando un vinilo en reproducción con ondas musicales.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <!-- Center of safety zone is at 54, 54 -->
    <!-- Spaceship soundwave disk -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M54,24 A30,30 0 1 0 84,54 A30,30 0 0 0 54,24 Z M54,72 A18,18 0 1 1 72,54 A18,18 0 0 1 54,72 Z"/>
    <!-- Laser beam tracks -->
    <path
        android:fillColor="#FF007F"
        android:pathData="M54,42 A12,12 0 1 0 66,54 A12,12 0 0 0 54,42 Z M54,60 A6,6 0 1 1 60,54 A6,6 0 0 1 54,60 Z"/>
    <!-- Orbiting spaceship -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M54,12 L59,19 L49,19 Z"/>
</vector>
`
  },
  {
    path: "app/src/main/res/mipmap/ic_launcher.xml",
    name: "ic_launcher.xml",
    language: "xml",
    description: "Icono de compatibilidad anterior para menú launcher de aplicaciones.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <!-- Circle Background -->
    <path
        android:fillColor="#0A0B10"
        android:pathData="M24,2 A22,22 0 1 0 46,24 A22,22 0 0 0 24,2 Z"/>
    <!-- Outer Cyan Ring -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M24,10 A14,14 0 1 0 38,24 A14,14 0 0 0 24,10 Z M24,34 A10,10 0 1 1 34,24 A10,10 0 0 1 24,34 Z"/>
    <!-- Inner Pink Center -->
    <path
        android:fillColor="#FF007F"
        android:pathData="M24,18 A6,6 0 1 0 30,24 A6,6 0 0 0 24,18 Z"/>
</vector>
`
  },
  {
    path: "app/src/main/res/mipmap/ic_launcher_round.xml",
    name: "ic_launcher_round.xml",
    language: "xml",
    description: "Icono redondo de compatibilidad anterior.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <!-- Circle Background -->
    <path
        android:fillColor="#0A0B10"
        android:pathData="M24,2 A22,22 0 1 0 46,24 A22,22 0 0 0 24,2 Z"/>
    <!-- Outer Cyan Ring -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M24,10 A14,14 0 1 0 38,24 A14,14 0 0 0 24,10 Z M24,34 A10,10 0 1 1 34,24 A10,10 0 0 1 24,34 Z"/>
    <!-- Inner Pink Center -->
    <path
        android:fillColor="#FF007F"
        android:pathData="M24,18 A6,6 0 1 0 30,24 A6,6 0 0 0 24,18 Z"/>
</vector>
`
  },
  {
    path: "app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml",
    name: "ic_launcher.xml (Adaptativo)",
    language: "xml",
    description: "Configura el icono adaptativo nativo para Android 8.0 o superior.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
`
  },
  {
    path: "app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml",
    name: "ic_launcher_round.xml (Adaptativo)",
    language: "xml",
    description: "Configura el icono adaptativo redondo nativo.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
`
  },
  {
    path: "app/src/main/res/mipmap-hdpi/ic_launcher.xml",
    name: "ic_launcher.xml (hdpi)",
    language: "xml",
    description: "Fichero de compatibilidad hdpi.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <!-- Circle Background -->
    <path
        android:fillColor="#0A0B10"
        android:pathData="M24,2 A22,22 0 1 0 46,24 A22,22 0 0 0 24,2 Z"/>
    <!-- Outer Cyan Ring -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M24,10 A14,14 0 1 0 38,24 A14,14 0 0 0 24,10 Z M24,34 A10,10 0 1 1 34,24 A10,10 0 0 1 24,34 Z"/>
    <!-- Inner Pink Center -->
    <path
        android:fillColor="#FF007F"
        android:pathData="M24,18 A6,6 0 1 0 30,24 A6,6 0 0 0 24,18 Z"/>
</vector>
`
  },
  {
    path: "app/src/main/res/mipmap-hdpi/ic_launcher_round.xml",
    name: "ic_launcher_round.xml (hdpi)",
    language: "xml",
    description: "Fichero de compatibilidad hdpi redondo.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <!-- Circle Background -->
    <path
        android:fillColor="#0A0B10"
        android:pathData="M24,2 A22,22 0 1 0 46,24 A22,22 0 0 0 24,2 Z"/>
    <!-- Outer Cyan Ring -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M24,10 A14,14 0 1 0 38,24 A14,14 0 0 0 24,10 Z M24,34 A10,10 0 1 1 34,24 A10,10 0 0 1 24,34 Z"/>
    <!-- Inner Pink Center -->
    <path
        android:fillColor="#FF007F"
        android:pathData="M24,18 A6,6 0 1 0 30,24 A6,6 0 0 0 24,18 Z"/>
</vector>
`
  },
  {
    path: "app/src/main/res/mipmap-mdpi/ic_launcher.xml",
    name: "ic_launcher.xml (mdpi)",
    language: "xml",
    description: "Fichero de compatibilidad mdpi.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <!-- Circle Background -->
    <path
        android:fillColor="#0A0B10"
        android:pathData="M24,2 A22,22 0 1 0 46,24 A22,22 0 0 0 24,2 Z"/>
    <!-- Outer Cyan Ring -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M24,10 A14,14 0 1 0 38,24 A14,14 0 0 0 24,10 Z M24,34 A10,10 0 1 1 34,24 A10,10 0 0 1 24,34 Z"/>
    <!-- Inner Pink Center -->
    <path
        android:fillColor="#FF007F"
        android:pathData="M24,18 A6,6 0 1 0 30,24 A6,6 0 0 0 24,18 Z"/>
</vector>
`
  },
  {
    path: "app/src/main/res/mipmap-mdpi/ic_launcher_round.xml",
    name: "ic_launcher_round.xml (mdpi)",
    language: "xml",
    description: "Fichero de compatibilidad mdpi redondo.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <!-- Circle Background -->
    <path
        android:fillColor="#0A0B10"
        android:pathData="M24,2 A22,22 0 1 0 46,24 A22,22 0 0 0 24,2 Z"/>
    <!-- Outer Cyan Ring -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M24,10 A14,14 0 1 0 38,24 A14,14 0 0 0 24,10 Z M24,34 A10,10 0 1 1 34,24 A10,10 0 0 1 24,34 Z"/>
    <!-- Inner Pink Center -->
    <path
        android:fillColor="#FF007F"
        android:pathData="M24,18 A6,6 0 1 0 30,24 A6,6 0 0 0 24,18 Z"/>
</vector>
`
  },
  {
    path: "app/src/main/res/mipmap-xhdpi/ic_launcher.xml",
    name: "ic_launcher.xml (xhdpi)",
    language: "xml",
    description: "Fichero de compatibilidad xhdpi.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <!-- Circle Background -->
    <path
        android:fillColor="#0A0B10"
        android:pathData="M24,2 A22,22 0 1 0 46,24 A22,22 0 0 0 24,2 Z"/>
    <!-- Outer Cyan Ring -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M24,10 A14,14 0 1 0 38,24 A14,14 0 0 0 24,10 Z M24,34 A10,10 0 1 1 34,24 A10,10 0 0 1 24,34 Z"/>
    <!-- Inner Pink Center -->
    <path
        android:fillColor="#FF007F"
        android:pathData="M24,18 A6,6 0 1 0 30,24 A6,6 0 0 0 24,18 Z"/>
</vector>
`
  },
  {
    path: "app/src/main/res/mipmap-xhdpi/ic_launcher_round.xml",
    name: "ic_launcher_round.xml (xhdpi)",
    language: "xml",
    description: "Fichero de compatibilidad xhdpi redondo.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <!-- Circle Background -->
    <path
        android:fillColor="#0A0B10"
        android:pathData="M24,2 A22,22 0 1 0 46,24 A22,22 0 0 0 24,2 Z"/>
    <!-- Outer Cyan Ring -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M24,10 A14,14 0 1 0 38,24 A14,14 0 0 0 24,10 Z M24,34 A10,10 0 1 1 34,24 A10,10 0 0 1 24,34 Z"/>
    <!-- Inner Pink Center -->
    <path
        android:fillColor="#FF007F"
        android:pathData="M24,18 A6,6 0 1 0 30,24 A6,6 0 0 0 24,18 Z"/>
</vector>
`
  },
  {
    path: "app/src/main/res/mipmap-xxhdpi/ic_launcher.xml",
    name: "ic_launcher.xml (xxhdpi)",
    language: "xml",
    description: "Fichero de compatibilidad xxhdpi.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <!-- Circle Background -->
    <path
        android:fillColor="#0A0B10"
        android:pathData="M24,2 A22,22 0 1 0 46,24 A22,22 0 0 0 24,2 Z"/>
    <!-- Outer Cyan Ring -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M24,10 A14,14 0 1 0 38,24 A14,14 0 0 0 24,10 Z M24,34 A10,10 0 1 1 34,24 A10,10 0 0 1 24,34 Z"/>
    <!-- Inner Pink Center -->
    <path
        android:fillColor="#FF007F"
        android:pathData="M24,18 A6,6 0 1 0 30,24 A6,6 0 0 0 24,18 Z"/>
</vector>
`
  },
  {
    path: "app/src/main/res/mipmap-xxhdpi/ic_launcher_round.xml",
    name: "ic_launcher_round.xml (xxhdpi)",
    language: "xml",
    description: "Fichero de compatibilidad xxhdpi redondo.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <!-- Circle Background -->
    <path
        android:fillColor="#0A0B10"
        android:pathData="M24,2 A22,22 0 1 0 46,24 A22,22 0 0 0 24,2 Z"/>
    <!-- Outer Cyan Ring -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M24,10 A14,14 0 1 0 38,24 A14,14 0 0 0 24,10 Z M24,34 A10,10 0 1 1 34,24 A10,10 0 0 1 24,34 Z"/>
    <!-- Inner Pink Center -->
    <path
        android:fillColor="#FF007F"
        android:pathData="M24,18 A6,6 0 1 0 30,24 A6,6 0 0 0 24,18 Z"/>
</vector>
`
  },
  {
    path: "app/src/main/res/mipmap-xxxhdpi/ic_launcher.xml",
    name: "ic_launcher.xml (xxxhdpi)",
    language: "xml",
    description: "Fichero de compatibilidad xxxhdpi.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <!-- Circle Background -->
    <path
        android:fillColor="#0A0B10"
        android:pathData="M24,2 A22,22 0 1 0 46,24 A22,22 0 0 0 24,2 Z"/>
    <!-- Outer Cyan Ring -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M24,10 A14,14 0 1 0 38,24 A14,14 0 0 0 24,10 Z M24,34 A10,10 0 1 1 34,24 A10,10 0 0 1 24,34 Z"/>
    <!-- Inner Pink Center -->
    <path
        android:fillColor="#FF007F"
        android:pathData="M24,18 A6,6 0 1 0 30,24 A6,6 0 0 0 24,18 Z"/>
</vector>
`
  },
  {
    path: "app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.xml",
    name: "ic_launcher_round.xml (xxxhdpi)",
    language: "xml",
    description: "Fichero de compatibilidad xxxhdpi redondo.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <!-- Circle Background -->
    <path
        android:fillColor="#0A0B10"
        android:pathData="M24,2 A22,22 0 1 0 46,24 A22,22 0 0 0 24,2 Z"/>
    <!-- Outer Cyan Ring -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M24,10 A14,14 0 1 0 38,24 A14,14 0 0 0 24,10 Z M24,34 A10,10 0 1 1 34,24 A10,10 0 0 1 24,34 Z"/>
    <!-- Inner Pink Center -->
    <path
        android:fillColor="#FF007F"
        android:pathData="M24,18 A6,6 0 1 0 30,24 A6,6 0 0 0 24,18 Z"/>
</vector>
`
  },
  {
    path: "app/src/main/res/values/colors.xml",
    name: "colors.xml",
    language: "xml",
    description: "Configura la paleta de colores Material Design 3 con acento cian neón y rosa coral.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- Spaceship Theme Palette (Neon accents, obsidian background, deep blues) -->
    <color name="purple_200">#FFBB86FC</color>
    <color name="purple_500">#FF6200EE</color>
    <color name="purple_700">#FF3700B3</color>
    <color name="teal_200">#FF03DAC5</color>
    <color name="teal_700">#FF018786</color>
    <color name="black">#FF000000</color>
    <color name="white">#FFFFFFFF</color>
    
    <!-- Neon Holographic Colors -->
    <color name="neon_cyan">#00E5FF</color>
    <color name="neon_pink">#FF007F</color>
    <color name="space_obsidian">#0A0B10</color>
    <color name="space_deep_blue">#131722</color>
</resources>
`
  },
  {
    path: "app/src/main/res/values/strings.xml",
    name: "strings.xml",
    language: "xml",
    description: "Valores literales de texto para la internacionalización y nombres del reproductor.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">¿Unas Rolitas?</string>
    <string name="playback_channel_name">Reproducción Activa</string>
    <string name="playback_channel_description">Controles multimedia en tiempo real de ¿Unas Rolitas?</string>
    <string name="scanning_music">Escaneando archivos en tu nave musical...</string>
</resources>
`
  },
  {
    path: "app/src/main/res/values/themes.xml",
    name: "themes.xml",
    language: "xml",
    description: "Aplica el tema inicial libre de barras de acción y de color negro profundo para el splash inicial nativo.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- Base application theme suited for Compose -->
    <style name="Theme.UnasRolitas" parent="android:Theme.Material.NoActionBar">
        <!-- Customize your theme here. -->
        <item name="android:statusBarColor">@color/space_obsidian</item>
        <item name="android:windowBackground">@color/space_obsidian</item>
        <item name="android:navigationBarColor">@color/space_obsidian</item>
    </style>
</resources>
`
  },
  {
    path: "app/src/main/res/xml/backup_rules.xml",
    name: "backup_rules.xml",
    language: "xml",
    description: "Define las reglas de copia de seguridad en la nube para la base de datos de música local.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<full-backup-content>
    <include domain="sharedpref" path="."/>
    <include domain="database" path="music_database.db"/>
</full-backup-content>
`
  },
  {
    path: "app/src/main/res/xml/data_extraction_rules.xml",
    name: "data_extraction_rules.xml",
    language: "xml",
    description: "Reglas modernas de transferencia de archivos para proteger y migrar los metadatos de las canciones en Android 12+.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<data-extraction-rules>
    <cloud-backup>
        <include domain="sharedpref" path="."/>
        <include domain="database" path="music_database.db"/>
    </cloud-backup>
    <device-transfer>
        <include domain="sharedpref" path="."/>
        <include domain="database" path="music_database.db"/>
    </device-transfer>
</data-extraction-rules>
`
  },
  {
    path: "settings.gradle.kts",
    name: "settings.gradle.kts",
    language: "kotlin",
    description: "Configura el entorno de construcción, repositorios seguros (Google, Maven Central) y declara el módulo principal ':app'.",
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "UnasRolitas"
include(":app")
`
  },
  {
    path: "build.gradle.kts",
    name: "build.gradle.kts (Raíz)",
    language: "kotlin",
    description: "Archivo Gradle raíz que consolida y congela las versiones globales de los plugins de Android, Kotlin y el procesador de símbolos KSP.",
    content: `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id("com.android.application") version "8.2.2" apply false
    id("com.android.library") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
    id("com.google.devtools.ksp") version "1.9.22-1.0.17" apply false
}
`
  },
  {
    path: "gradle.properties",
    name: "gradle.properties",
    language: "properties",
    description: "Optimiza la JVM para teléfonos móviles limitados (Termux proot-distro). Configura el heap máximo a un límite conservador de 1024MB para prevenir bloqueos por Out-Of-Memory.",
    content: `# JVM Heap settings for compiling on an Android phone (Termux / proot-distro Ubuntu)
# Restricted to 1GB RAM to prevent OOM / Termux system kills
org.gradle.jvmargs=-Xmx1024m -XX:MaxMetaspaceSize=256m -XX:+UseParallelGC

# AndroidX migration enabled
android.useAndroidX=true

# Keep the generated R class transitive to save builds memory
android.nonTransitiveRClass=true

# Enable parallel and caching features to optimize build times on mobile processors
org.gradle.parallel=true
org.gradle.caching=true
org.gradle.configureondemand=true
`
  }
];
